<?php
session_start();
require_once 'config/db.php';
$page_title = "My Orders | KridaArena";
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$orders = [];
try {
    $stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $orders = $result->fetch_all(MYSQLI_ASSOC);
    $all_order_items = [];
    if (!empty($orders)) {
        $order_ids = array_column($orders, 'order_id');
        $placeholders = implode(',', array_fill(0, count($order_ids), '?'));
        $stmt_items = $conn->prepare("SELECT oi.order_id, oi.quantity, p.name AS product_name, p.price AS product_price, p.image AS product_image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id IN ($placeholders)");
        $types = str_repeat('i', count($order_ids));
        $stmt_items->bind_param($types, ...$order_ids);
        $stmt_items->execute();
        $items_result = $stmt_items->get_result();
        while ($row = $items_result->fetch_assoc()) {
            $all_order_items[$row['order_id']][] = $row;
        }
    }
} catch (Exception $e) {
    die("Error fetching orders: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>    
    <style>
        .hero.short {
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            text-align: center;
            padding: 80px 0;
            margin-bottom: 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            color: #fff;
        }
        .order-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .order-card:hover {
            transform: translateY(-5px);
        }
        .order-header {
            background-color: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
            border-top-left-radius: 15px;
            border-top-right-radius: 15px;
        }
        .order-total {
            color: #ec7c20ff;
        }
        .status-badge {
            font-size: 0.9em;
            padding: 0.5em 1em;
        }
        .btn-danger {
            background-color: #dc3545;
            border-color: #dc3545;
            transition: all 0.3s ease;
        }
        .btn-danger:hover {
            background-color: #c82333;
            border-color: #bd2130;
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <?php include 'includes/navbar.php'; ?>
    <header class="hero short">
        <div class="container text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown">My Orders</h1>
        </div>
    </header>
    <main class="container my-5 flex-grow-1">
        <section class="my-orders-section">
            <?php if (empty($orders)): ?>
                <div class="alert alert-info text-center" role="alert">
                    You have not placed any orders yet. <a href="store.php" class="alert-link">Shop now!</a>
                </div>
            <?php else: ?>
                <?php foreach ($orders as $order): ?>
                    <div class="card order-card mb-4 animate__animated animate__fadeInUp">
                        <div class="card-header order-header d-flex justify-content-between align-items-center">
                            <div>
                                <h5 class="mb-0">Order #<?= htmlspecialchars($order['order_id']) ?></h5>
                                <small class="text-muted">Placed on: <?= date("M d, Y", strtotime($order['created_at'])) ?></small><br>
                                <small class="text-muted">Estimated Delivery: <?= htmlspecialchars($order['delivery_date']) ?></small>
                            </div>
                            <?php
                                $status_class = '';
                                $display_status = htmlspecialchars($order['status']);
                                switch ($order['status']) {
                                    case 'Processing':
                                        $status_class = 'bg-primary';
                                        break;
                                    case 'Shipped':
                                        $status_class = 'bg-info text-dark';
                                        break;
                                    case 'Delivered':
                                        $status_class = 'bg-success';
                                        break;
                                    case 'Cancelled':
                                        $status_class = 'bg-danger';
                                        $display_status = 'You cancelled this order';
                                        break;
                                    case 'Pending':
                                        $status_class = 'bg-warning text-dark';
                                        break;
                                    default:
                                        $status_class = 'bg-secondary';
                                }
                            ?>
                            <span class="badge <?= $status_class ?> status-badge"><?= $display_status ?></span>
                        </div>
                        <div class="card-body">
                            <ul class="list-group list-group-flush">
                                <?php
                                $order_items = $all_order_items[$order['order_id']] ?? [];
                                foreach ($order_items as $item): ?>
                                    <li class="list-group-item d-flex justify-content-between">
                                        <div>
                                            <h6 class="my-0"><?= htmlspecialchars($item['product_name']) ?></h6>
                                            <small class="text-muted">Quantity: <?= $item['quantity'] ?></small>
                                        </div>
                                        <span class="text-muted">₹<?= number_format($item['product_price'] * $item['quantity'], 2) ?></span>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <div class="card-footer d-flex justify-content-between align-items-center">
                            <div>
                                <h5 class="mb-2 order-total">Total: ₹<?= number_format($order['total_amount'], 2) ?></h5>
                                <a href="bill.php?order_id=<?= htmlspecialchars($order['order_id']) ?>" target="_blank" class="btn btn-sm btn-outline-dark">
                                    <i class="bi bi-file-earmark-text"></i> View Invoice
                                </a>
                            </div>
                            <?php
                                $cancellation_window_seconds = 3 * 24 * 60 * 60; 
                                $order_timestamp = strtotime($order['created_at']);
                                $now_timestamp = time();
                                if (($order['status'] == 'Processing' || $order['status'] == 'Pending') && ($now_timestamp - $order_timestamp) < $cancellation_window_seconds):
                            ?>
                                <button class="btn btn-sm btn-danger cancel-order-btn" data-order-id="<?= htmlspecialchars($order['order_id']) ?>">
                                    <i class="bi bi-x-circle"></i> Cancel My Order
                                </button>
                            <?php else: ?>
                                <span class="text-muted fw-bold">Cancellation window closed</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
    </main>
    <?php include 'includes/footer.php'; ?>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const cancelButtons = document.querySelectorAll('.cancel-order-btn');
            cancelButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const orderId = button.getAttribute('data-order-id');
                    Swal.fire({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, cancel it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            fetch('cancel_order.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded',
                                },
                                body: `order_id=${orderId}`
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.status === 'success') {
                                    Swal.fire(
                                        'Cancelled!',
                                        data.message,
                                        'success'
                                    ).then(() => {
                                        location.reload();
                                    });
                                } else {
                                    Swal.fire(
                                        'Error!',
                                        data.message,
                                        'error'
                                    );
                                }
                            })
                            .catch(error => {
                                Swal.fire(
                                    'Error!',
                                    'An unexpected error occurred. Please try again.',
                                    'error'
                                );
                            });
                        }
                    });
                });
            });
        });
    </script>
</body>
</html>