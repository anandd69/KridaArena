<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$page_title = "Manage Tournaments | KridaArena";
$msg = "";
$tournament = null;
$action = $_GET['action'] ?? 'list';
$tournament_id = $_GET['id'] ?? null;

if (isset($_SESSION['success_message'])) {
    $msg = "<div class='alert alert-success'>" . $_SESSION['success_message'] . "</div>";
    unset($_SESSION['success_message']);
}
if (isset($_SESSION['error_message'])) {
    $msg = "<div class='alert alert-danger'>" . $_SESSION['error_message'] . "</div>";
    unset($_SESSION['error_message']);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['delete_tournament'])) {
        $tournament_id_to_delete = (int)$_POST['tournament_id'];
        if ($tournament_id_to_delete > 0) {
            $delete_stmt = $conn->prepare("DELETE FROM tournaments WHERE tournament_id = ?");
            if ($delete_stmt) {
                $delete_stmt->bind_param("i", $tournament_id_to_delete);
                if ($delete_stmt->execute()) {
                    $_SESSION['success_message'] = "Tournament deleted successfully!";
                } else {
                    $_SESSION['error_message'] = "Error deleting tournament: " . $delete_stmt->error;
                }
                $delete_stmt->close();
            } else {
                $_SESSION['error_message'] = "Database error: Could not prepare delete statement.";
            }
        } else {
            $_SESSION['error_message'] = "Invalid tournament ID for deletion.";
        }
        header("Location: manage_tournaments.php");
        exit();
    } elseif (isset($_POST['update_tournament'])) {
        $id                 = (int)$_POST['tournament_id'];
        $name               = trim($_POST['name']);
        $sport              = trim($_POST['sport']);
        $venue              = trim($_POST['venue']);
        $fees_input         = trim($_POST['fees']);
        $tournament_type    = trim($_POST['type']);
        $team_limit_input   = trim($_POST['team_limit']);
        $description        = trim($_POST['description']);
        $status             = trim($_POST['status']);
        $players_per_team_input = trim($_POST['players_per_team']);
        $prizes             = trim($_POST['prizes'] ?? '');
        $reg_start_date     = trim($_POST['registration_start_date']);
        $reg_end_date       = trim($_POST['registration_end_date']);

        if (empty($name) || empty($sport) || empty($venue) || empty($description) || empty($status) || empty($fees_input) || empty($players_per_team_input) || empty($reg_start_date) || empty($reg_end_date) || empty($team_limit_input) || empty($tournament_type) || $id <= 0) {
            $_SESSION['error_message'] = "All fields are required and must have valid values for update.";
        } else {
            $fees = floatval($fees_input);
            $players_per_team = intval($players_per_team_input);
            $team_limit = intval($team_limit_input);
            
            if ($fees < 0 || $players_per_team <= 0 || $team_limit <= 0) {
                $_SESSION['error_message'] = "Fees must be non-negative, and Players Per Team and Team Limit must be positive integers.";
            } elseif (strtotime($reg_start_date) > strtotime($reg_end_date)) {
                $_SESSION['error_message'] = "Registration end date cannot be before the start date.";
            } else {
                
                $update_stmt = $conn->prepare("UPDATE tournaments SET name = ?, sport = ?, type = ?, description = ?, status = ?, venue = ?, fees = ?, prizes = ?, registration_start_date = ?, registration_end_date = ?, players_per_team = ?, team_limit = ? WHERE tournament_id = ?");

                if ($update_stmt) {
                  
                    $update_stmt->bind_param(
                        "ssssssdsssiii",
                        $name, 
                        $sport, 
                        $tournament_type, 
                        $description, 
                        $status, 
                        $venue, 
                        $fees, 
                        $prizes, 
                        $reg_start_date, 
                        $reg_end_date, 
                        $players_per_team, 
                        $team_limit, 
                        $id
                    );

                    if ($update_stmt->execute()) {
                        $_SESSION['success_message'] = "Tournament updated successfully!";
                    } else {
                        $_SESSION['error_message'] = "Error updating tournament: " . $update_stmt->error;
                    }
                    $update_stmt->close();
                } else {
                    $_SESSION['error_message'] = "Database error: Could not prepare update statement.";
                }
            }
        }
        header("Location: manage_tournaments.php");
        exit();
    }
}

$tournaments = [];
$tournament_query = "SELECT * FROM tournaments ORDER BY tournament_id DESC";
$result = $conn->query($tournament_query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $tournaments[] = $row;
    }
}

if ($action == 'edit' && $tournament_id) {
    $stmt = $conn->prepare("SELECT * FROM tournaments WHERE tournament_id = ?");
    $stmt->bind_param("i", $tournament_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 1) {
        $tournament = $result->fetch_assoc();
    } else {
        $msg = "<div class='alert alert-danger'>Tournament not found.</div>";
        $action = 'list';
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <link rel="stylesheet" href="admin_style.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #1d2b64, #f8cdda);
            --sidebar-bg: rgba(255, 255, 255, 0.1);
            --card-bg: rgba(255, 255, 255, 0.2);
            --divider-color: rgba(255, 255, 255, 0.3);
            --text-color: #fff;
            --highlight-color: #FFD700;
        }
        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
        }
        .admin-content-wrapper {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            margin: 20px;
            padding: 30px;
            color: var(--text-color);
        }
        .admin-content-wrapper h1 {
            color: var(--text-color);
        }
        .card-recent {
            background: rgba(0, 0, 0, 0.5); 
            border: none;
            border-radius: 15px;
        }
        .card-recent .card-title,
        .card-recent .card-text {
            color: var(--text-color) !important;
        }
        .table {
            --bs-table-bg: transparent;
            --bs-table-color: var(--text-color);
            color: var(--text-color);
        }
        .table th {
            border-bottom: 1px solid var(--divider-color);
            color: var(--highlight-color);
        }
        .table tbody tr {
            background-color: rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s ease;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        .form-label {
            color: #fff;
        }
        .form-control {
            background-color: rgba(255, 255, 255, 0.1);
            color: #fff;
            border: 1px solid var(--divider-color);
        }
        .form-control:focus {
            background-color: rgba(255, 255, 255, 0.2);
            color: #fff;
        }
        .btn-warning img,
        .btn-danger img,
        .btn-success img,
        .btn-secondary img { 
            width: 16px; 
            height: 16px;
            margin-right: 5px; 
            vertical-align: sub;
        }
        .icon-white {
            filter: brightness(0) invert(1);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="d-flex w-100 flex-grow-1">
        <?php require_once '../admin/admin_sidebar.php'; ?>
        <div class="admin-content-wrapper container-fluid py-4 flex-grow-1">
            <h1 class="display-5 fw-bold mb-4 animate__animated animate__fadeInDown"><?= htmlspecialchars($page_title) ?></h1>
            
            <?= $msg ?>

            <?php if ($action == 'list'): ?>
                <div class="d-flex justify-content-end mb-3">
                    <a href="add_tournament.php" class="btn btn-primary animate__animated animate__fadeIn">
                        <img src="../png/mark.png" alt="Add Icon" class="me-2 icon-white" style="width: 16px; height: 16px;"> Add New Tournament
                    </a>
                </div>

                <div class="card card-recent animate__animated animate__fadeInUp">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">Tournaments List (<?= count($tournaments) ?>)</h5>
                        <p class="card-text">Manage all tournaments displayed on the client side.</p>
                        <div class="table-responsive">
                            <table class="table table-borderless table-hover align-middle">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Sport</th>
                                        <th>Venue</th>
                                        <th>Fees</th>
                                        <th>Status</th>
                                        <th>Reg. Dates</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!empty($tournaments)): ?>
                                        <?php foreach ($tournaments as $t): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($t['tournament_id']) ?></td>
                                        <td><?= htmlspecialchars($t['name']) ?></td>
                                        <td><?= htmlspecialchars($t['sport']) ?></td>
                                        <td><?= htmlspecialchars($t['venue']) ?></td>
                                        <td>₹<?= number_format($t['fees'], 2) ?></td>
                                        
                                        <td><span class="badge bg-<?= ($t['status'] == 'active') ? 'success' : (($t['status'] == 'upcoming') ? 'info' : 'secondary') ?>"><?= htmlspecialchars(ucfirst($t['status'])) ?></span></td>
                                        
                                        <td><?= date('M d, Y', strtotime($t['registration_start_date'])) ?> - <?= date('M d, Y', strtotime($t['registration_end_date'])) ?></td>
                                        <td>
                                            <a href="manage_tournaments.php?action=edit&id=<?= htmlspecialchars($t['tournament_id']) ?>" class="btn btn-warning btn-sm me-2">
                                                <img src="../png/2reg.png" alt="Edit Icon"> Edit
                                            </a>
                                            <form method="POST" action="manage_tournaments.php" class="d-inline">
                                                <input type="hidden" name="tournament_id" value="<?= htmlspecialchars($t['tournament_id']) ?>">
                                                <button type="submit" name="delete_tournament" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete the tournament: <?= htmlspecialchars($t['name']) ?>?');">
                                                    <img src="../png/trash.png" alt="Delete Icon"> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted">No tournaments found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            <?php elseif ($action == 'edit' && $tournament): ?>
                <div class="card card-recent animate__animated animate__fadeInUp">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">Edit Tournament: <?= htmlspecialchars($tournament['name']) ?></h5>
                        <form method="POST" action="manage_tournaments.php">
                            <input type="hidden" name="tournament_id" value="<?= htmlspecialchars($tournament['tournament_id']) ?>">
                            <div class="mb-3">
                                <label for="name" class="form-label">Tournament Name</label>
                                <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($tournament['name']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="sport" class="form-label">Sport Type</label>
                                <input type="text" class="form-control" id="sport" name="sport" value="<?= htmlspecialchars($tournament['sport']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="type" class="form-label">Tournament Type</label>
                                <select class="form-control" id="type" name="type" required>
                                    <option value="team" <?= ($tournament['type'] == 'team') ? 'selected' : '' ?>>Team Registration</option>
                                    <option value="solo" <?= ($tournament['type'] == 'solo') ? 'selected' : '' ?>>Solo/Per Player</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="venue" class="form-label">Venue</label>
                                <input type="text" class="form-control" id="venue" name="venue" value="<?= htmlspecialchars($tournament['venue']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="registration_start_date" class="form-label">Registration Start Date</label>
                                <input type="date" class="form-control" id="registration_start_date" name="registration_start_date" value="<?= htmlspecialchars($tournament['registration_start_date']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="registration_end_date" class="form-label">Registration End Date</label>
                                <input type="date" class="form-control" id="registration_end_date" name="registration_end_date" value="<?= htmlspecialchars($tournament['registration_end_date']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="fees" class="form-label">Fees (in ₹)</label>
                                <input type="number" class="form-control" id="fees" name="fees" step="0.01" value="<?= htmlspecialchars($tournament['fees']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="players_per_team" class="form-label">Players Per Team</label>
                                <input type="number" class="form-control" id="players_per_team" name="players_per_team" value="<?= htmlspecialchars($tournament['players_per_team']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="team_limit" class="form-label">Team/Slot Limit</label>
                                <input type="number" class="form-control" id="team_limit" name="team_limit" value="<?= htmlspecialchars($tournament['team_limit']) ?>" required>
                            </div>
                            <div class="mb-3">
                                <label for="prizes" class="form-label">Prizes</label>
                                <textarea class="form-control" id="prizes" name="prizes" rows="2"><?= htmlspecialchars($tournament['prizes']) ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="description" name="description" rows="3" required><?= htmlspecialchars($tournament['description']) ?></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="status" class="form-label">Status</label>
                                <select class="form-control" id="status" name="status" required>
                                    <option value="upcoming" <?= ($tournament['status'] == 'upcoming') ? 'selected' : '' ?>>Upcoming</option>
                                    <option value="active" <?= ($tournament['status'] == 'active') ? 'selected' : '' ?>>Active</option>
                                    <option value="completed" <?= ($tournament['status'] == 'completed') ? 'selected' : '' ?>>Completed</option>
                                </select>
                            </div>
                            <button type="submit" name="update_tournament" class="btn btn-success">
                                <img src="../png/2reg.png" alt="Update Icon"> Update Tournament
                            </button>
                            <a href="manage_tournaments.php" class="btn btn-secondary">
                                <img src="../png/trash.png" alt="Cancel Icon"> Cancel
                            </a>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>