<?php
session_start();
require_once '../config/db.php'; 
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$page_title = "Add Tournament | Admin Panel";
$msg = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name          = trim($_POST['name']);
    $sport         = trim($_POST['sport']);
    $venue         = trim($_POST['venue']);
    $fees          = floatval($_POST['fees']);
    $description   = trim($_POST['description']);
    $status        = trim($_POST['status']);
    $players_per_team = intval($_POST['players_per_team']);

    if (empty($name) || empty($sport) || empty($venue) || empty($description) || empty($status) || $fees < 0 || $players_per_team <= 0) {
        $msg = "<div class='alert alert-danger'>All fields are required and must have valid values.</div>";
    } else {
        $stmt = $conn->prepare("INSERT INTO tournaments (name, sport, venue, fees, description, status, players_per_team) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdssi", $name, $sport, $venue, $fees, $description, $status, $players_per_team);
        
        if ($stmt->execute()) {
            $msg = "<div class='alert alert-success'>Tournament added successfully!</div>";
        } else {
            $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f0f0f5, #e0e0e5);
            min-height: 100vh;
            display: flex;
        }
        .admin-sidebar {
            background-color: #2c3e50;
            color: #ecf0f1;
            padding: 20px;
            min-height: 100vh;
        }
        .admin-sidebar a {
            color: #ecf0f1;
            text-decoration: none;
            display: block;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 10px;
            transition: background-color 0.3s ease;
        }
        .admin-sidebar a:hover {
            background-color: #34495e;
        }
        .admin-content {
            flex-grow: 1;
            padding: 20px;
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <div class="admin-sidebar d-flex flex-column p-3 text-white" style="width: 280px;">
            <a href="admin_dashboard.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                <i class="bi bi-speedometer2 me-2"></i>
                <span class="fs-4">Admin Dashboard</span>
            </a>
            <hr>
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="admin_dashboard.php" class="nav-link text-white" aria-current="page">
                        <i class="bi bi-house-door-fill me-2"></i>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="manage_users.php" class="nav-link text-white">
                        <i class="bi bi-people-fill me-2"></i>
                        Users
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle active" href="#" id="tournamentsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-trophy-fill me-2"></i>
                        Tournaments
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="tournamentsDropdown">
                        <li><a class="dropdown-item" href="manage_tournaments.php">Manage Tournaments</a></li>
                        <li><a class="dropdown-item active" href="add_tournament.php">Add New Tournament</a></li>
                    </ul>
                </li>
                <li>
                    <a href="manage_products.php" class="nav-link text-white">
                        <i class="bi bi-bag-fill me-2"></i>
                        Products
                    </a>
                </li>
            </ul>
            <hr>
            <a href="admin_logout.php" class="d-flex align-items-center text-white text-decoration-none">
                <i class="bi bi-box-arrow-right me-2"></i>
                <span class="ms-auto">Logout</span>
            </a>
        </div>

        <div class="container-fluid py-4 flex-grow-1">
            <h1 class="display-5 fw-bold mb-4">Add New Tournament</h1>
            <?php if (isset($msg)): ?>
                <?= $msg ?>
            <?php endif; ?>
            
            <form method="POST">
                <div class="mb-3">
                    <label for="name" class="form-label">Tournament Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="sport" class="form-label">Sport</label>
                    <input type="text" class="form-control" id="sport" name="sport" required>
                </div>
                <div class="mb-3">
                    <label for="venue" class="form-label">Venue</label>
                    <input type="text" class="form-control" id="venue" name="venue" required>
                </div>
                <div class="mb-3">
                    <label for="fees" class="form-label">Fees (in ₹)</label>
                    <input type="number" class="form-control" id="fees" name="fees" step="0.01" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                </div>
                <div class="mb-3">
                    <label for="players_per_team" class="form-label">Players Per Team</label>
                    <input type="number" class="form-control" id="players_per_team" name="players_per_team" required>
                </div>
                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-control" id="status" name="status" required>
                        <option value="active">Active</option>
                        <option value="completed">Completed</option>
                        <option value="upcoming">Upcoming</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Add Tournament</button>
                <a href="manage_tournaments.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>