<?php
session_start();
require_once '../config/db.php'; 
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$page_title = "Add Tournament | Admin Panel";
$msg = "";

$name = $sport = $venue = $fees_input = $tournament_type = $description = $status = $prizes = '';
$players_per_team_input = $team_limit_input = '';
$reg_start_date = $reg_end_date = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name          = trim($_POST['name']);
    $sport         = trim($_POST['sport']);
    $venue         = trim($_POST['venue']);
    $fees_input    = trim($_POST['fees']);
    $tournament_type = trim($_POST['type']);
    $description   = trim($_POST['description']);
    $status        = trim($_POST['status']);
    $players_per_team_input = trim($_POST['players_per_team']);
    $team_limit_input = trim($_POST['team_limit']);
    $prizes        = trim($_POST['prizes'] ?? '');
    $reg_start_date = trim($_POST['registration_start_date']);
    $reg_end_date   = trim($_POST['registration_end_date']);
    
    if (empty($name) || empty($sport) || empty($venue) || empty($description) || empty($status) || empty($fees_input) || empty($players_per_team_input) || empty($team_limit_input) || empty($tournament_type) || empty($reg_start_date) || empty($reg_end_date)) {
        $msg = "<div class='alert alert-danger'>All fields are required and must have valid values.</div>";
    } else {
        $fees = floatval($fees_input);
        $players_per_team = intval($players_per_team_input);
        $team_limit = intval($team_limit_input);

        if ($fees < 0 || $players_per_team <= 0 || $team_limit <= 0) {
            $msg = "<div class='alert alert-danger'>Fees, Players Per Team, and Team Limit must be positive numbers.</div>";
        } elseif (strtotime($reg_start_date) > strtotime($reg_end_date)) {
            $msg = "<div class='alert alert-danger'>Registration end date cannot be before the start date.</div>";
        } else {
            $sql = "INSERT INTO tournaments (name, sport, venue, fees, type, description, status, players_per_team, team_limit, prizes, registration_start_date, registration_end_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            
            if ($stmt === false) { 
                $msg = "<div class='alert alert-danger'>SQL Prepare Error: " . $conn->error . "</div>";
            } else {
                $stmt->bind_param("sssdsississs", $name, $sport, $venue, $fees, $tournament_type, $description, $status, $players_per_team, $team_limit, $prizes, $reg_start_date, $reg_end_date);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Tournament added successfully!";
                    header("Location: manage_tournaments.php");
                    exit();
                } else {
                    $msg = "<div class='alert alert-danger'>Execution Error: " . $stmt->error . "</div>";
                }
                $stmt->close();
            }
        }
    }
}
$current_page = basename(__FILE__);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css"> 
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="admin_style.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #1d2b64, #f8cdda);
            --sidebar-bg: rgba(255, 255, 255, 0.1);
            --card-bg: rgba(255, 255, 255, 0.2);
            --divider-color: rgba(255, 255, 255, 0.3);
            --text-color: #fff;
            --highlight-color: #FFD700;
        }
        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
        }
        .admin-content-wrapper {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            margin: 20px;
            padding: 30px;
            color: var(--text-color);
            max-width: 900px;
        }
        .form-label {
            color: var(--highlight-color);
        }
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid var(--divider-color);
            color: var(--text-color);
        }
        .form-control:focus {
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 0 0 0.25rem rgba(255, 255, 255, 0.25);
            color: var(--text-color);
        }
        .form-text {
            color: rgba(255, 255, 255, 0.7) !important;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="d-flex w-100 flex-grow-1">
        <?php require_once '../admin/admin_sidebar.php'; ?>
        <div class="admin-content-wrapper container-fluid py-4 flex-grow-1">
            <h1 class="display-5 fw-bold mb-4 animate__animated animate__fadeInDown"><?= htmlspecialchars($page_title) ?></h1>
            
            <?php if (!empty($msg)): ?>
                <?= $msg ?>
            <?php endif; ?>
            
            <form method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="name" class="form-label">Tournament Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($name) ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="sport" class="form-label">Sport</label>
                        <input type="text" class="form-control" id="sport" name="sport" value="<?= htmlspecialchars($sport) ?>" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="venue" class="form-label">Venue</label>
                    <input type="text" class="form-control" id="venue" name="venue" value="<?= htmlspecialchars($venue) ?>" required>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="registration_start_date" class="form-label">Registration Start Date</label>
                        <input type="date" class="form-control" id="registration_start_date" name="registration_start_date" value="<?= htmlspecialchars($reg_start_date) ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="registration_end_date" class="form-label">Registration End Date</label>
                        <input type="date" class="form-control" id="registration_end_date" name="registration_end_date" value="<?= htmlspecialchars($reg_end_date) ?>" required>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <label for="fees" class="form-label">Fees (in ₹)</label>
                        <input type="number" class="form-control" id="fees" name="fees" step="0.01" value="<?= htmlspecialchars($fees_input) ?>" required>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="type" class="form-label">Tournament Type</label>
                        <select class="form-control" id="type" name="type" required>
                            <option value="team" <?= ($tournament_type == 'team') ? 'selected' : '' ?>>Team Registration</option>
                            <option value="solo" <?= ($tournament_type == 'solo') ? 'selected' : '' ?>>Solo/Per Player</option>
                        </select>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="players_per_team" class="form-label">Players Per Team</label>
                        <input type="number" class="form-control" id="players_per_team" name="players_per_team" value="<?= htmlspecialchars($players_per_team_input) ?>" required>
                    </div>
                    <div class="col-md-3 mb-3">
                        <label for="team_limit" class="form-label">Team/Slot Limit</label>
                        <input type="number" class="form-control" id="team_limit" name="team_limit" value="<?= htmlspecialchars($team_limit_input) ?>" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="prizes" class="form-label">Prizes (Optional)</label>
                    <textarea class="form-control" id="prizes" name="prizes" rows="2"><?= htmlspecialchars($prizes) ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3" required><?= htmlspecialchars($description) ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select class="form-control" id="status" name="status" required>
                        <option value="upcoming" <?= ($status == 'upcoming') ? 'selected' : '' ?>>Upcoming</option>
                        <option value="active" <?= ($status == 'active') ? 'selected' : '' ?>>Active</option>
                        <option value="completed" <?= ($status == 'completed') ? 'selected' : '' ?>>Completed</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Add Tournament</button>
                <a href="manage_tournaments.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>