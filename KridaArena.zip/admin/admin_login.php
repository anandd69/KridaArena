<?php
session_start();
require_once '../config/db.php'; 
$msg = "";
$welcomeText = "Admin Login";
$page_title = "Admin Login Panel";

if (isset($_SESSION['admin_id'])) {
    header("Location: admin_dashboard.php");
    exit();
}

function setupDefaultAdmins($conn) {
    $default_admins = [
        ['rajkumar@gmail.com', '1', 'Rajkumar'], 
        ['anand@gmail.com', '2', 'Anand'],
    ];
    
    foreach ($default_admins as $admin_data) {
        list($email, $password, $name) = $admin_data;
        
        $stmt_select = $conn->prepare("SELECT admin_id FROM admins WHERE email = ?");
        $stmt_select->bind_param("s", $email);
        $stmt_select->execute();
        $result = $stmt_select->get_result();

        if ($result->num_rows === 0) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt_insert = $conn->prepare("INSERT INTO admins (name, email, password) VALUES (?, ?, ?)");
            $stmt_insert->bind_param("sss", $name, $email, $hashed_password);
            $stmt_insert->execute();
            $stmt_insert->close();
        }
        $stmt_select->close();
    }
}
setupDefaultAdmins($conn);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $pass  = trim($_POST['password']);

    if (empty($email) || empty($pass)) {
        $msg = "<div class='alert alert-danger mt-2'>Email और पासवर्ड खाली नहीं हो सकते।</div>";
    } else {
        $stmt = $conn->prepare("SELECT admin_id, name, password, login_attempts, lockout_until FROM admins WHERE email = ?");
        
        if ($stmt === false) {
            $msg = "<div class='alert alert-danger mt-2'>Database error: " . $conn->error . "</div>";
        } else {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $admin = $result->fetch_assoc();
            $stmt->close();

            if ($admin) {
                if ($admin['lockout_until'] !== NULL && strtotime($admin['lockout_until']) > time()) {
                    $remaining_time = strtotime($admin['lockout_until']) - time();
                    $minutes = ceil($remaining_time / 60);
                    $msg = "<div class='alert alert-warning mt-2'>यह अकाउंट अस्थायी रूप से लॉक है। कृपया " . $minutes . " मिनट बाद फिर से कोशिश करें।</div>";
                } elseif (password_verify($pass, $admin['password'])) {
                    $_SESSION['admin_id'] = $admin['admin_id'];
                    $_SESSION['admin_name'] = $admin['name'];
                    
                    $stmt_update = $conn->prepare("UPDATE admins SET login_attempts = 0, last_login_at = NOW() WHERE admin_id = ?");
                    $stmt_update->bind_param("i", $admin['admin_id']);
                    $stmt_update->execute();
                    $stmt_update->close();
                    
                    header("Location: admin_dashboard.php");
                    exit();
                } else {
                    $new_attempts = $admin['login_attempts'] + 1;
                    $lockout_until = NULL;
                    $lockout_msg = "";
                    
                    if ($new_attempts >= 3) {
                        $lockout_until = date('Y-m-d H:i:s', strtotime('+5 minutes'));
                        $lockout_msg = " आपके 3 प्रयास असफल हुए हैं। अकाउंट 5 मिनट के लिए लॉक कर दिया गया है।";
                    }
                    
                    $stmt_update = $conn->prepare("UPDATE admins SET login_attempts = ?, lockout_until = ? WHERE admin_id = ?");
                    $stmt_update->bind_param("isi", $new_attempts, $lockout_until, $admin['admin_id']);
                    $stmt_update->execute();
                    $stmt_update->close();
                    
                    $msg = "<div class='alert alert-danger mt-2'>गलत ईमेल या पासवर्ड। शेष प्रयास: " . (3 - $new_attempts) . "." . $lockout_msg . "</div>";
                }
            } else {
                $msg = "<div class='alert alert-danger mt-2'>गलत ईमेल या पासवर्ड।</div>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #1d2b64, #f8cdda);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .login-container {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.18);
            width: 100%;
            max-width: 400px;
        }
        .login-container h1 {
            text-align: center;
            margin-bottom: 25px;
            font-weight: 700;
            color: #fff;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        .form-label {
            font-weight: 600;
            color: #fff;
        }
        .form-control {
            background: rgba(255, 255, 255, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: #fff;
            transition: all 0.3s ease-in-out;
            border-radius: 10px;
        }
        .form-control:focus {
            background: rgba(255, 255, 255, 0.4);
            border-color: rgba(255, 255, 255, 0.5);
            box-shadow: 0 0 0 0.25rem rgba(255, 255, 255, 0.25);
        }
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        .btn-glow {
            background: linear-gradient(45deg, #ff0844, #ffb199);
            color: #fff;
            font-weight: bold;
            border: none;
            border-radius: 10px;
            padding: 12px 20px;
            transition: all 0.3s ease-in-out;
            box-shadow: 0 4px 15px rgba(255, 8, 68, 0.4);
        }
        .btn-glow:hover {
            box-shadow: 0 6px 20px rgba(255, 8, 68, 0.6);
            transform: translateY(-2px);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="login-container animate__animated animate__fadeIn">
        <h1 class="animate__animated animate__fadeInDown"><?= $welcomeText ?></h1>
        <?= $msg ?>
        <form id="loginForm" method="POST" autocomplete="off" class="animate__animated animate__fadeInUp">
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" id="email" class="form-control" placeholder="Enter your admin email" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Enter your password" required>
            </div>
            <button type="submit" class="btn btn-glow w-100 mt-3">Login</button>
        </form>
    </div>
    <script>
        document.getElementById('loginForm').addEventListener('submit', function(event) {
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');
            if (emailInput.value.trim() === '' || passwordInput.value.trim() === '') {
                event.preventDefault(); 
            }
        });
    </script>
</body>
</html>