<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
$total_users = 0;
$total_tournaments = 0;
$total_products = 0;
$total_orders = 0;

$stmt_users = $conn->prepare("SELECT COUNT(*) AS total_users FROM users");
if ($stmt_users) {
    $stmt_users->execute();
    $result_users = $stmt_users->get_result();
    if ($result_users) {
        $row_users = $result_users->fetch_assoc();
        $total_users = $row_users['total_users'];
    }
    $stmt_users->close();
}

$stmt_tournaments = $conn->prepare("SELECT COUNT(*) AS total_tournaments FROM tournaments");
if ($stmt_tournaments) {
    $stmt_tournaments->execute();
    $result_tournaments = $stmt_tournaments->get_result();
    if ($result_tournaments) {
        $row_tournaments = $result_tournaments->fetch_assoc();
        $total_tournaments = $row_tournaments['total_tournaments'];
    }
    $stmt_tournaments->close();
}

$stmt_products = $conn->prepare("SELECT COUNT(*) AS total_products FROM products");
if ($stmt_products) {
    $stmt_products->execute();
    $result_products = $stmt_products->get_result();
    if ($result_products) {
        $row_products = $result_products->fetch_assoc();
        $total_products = $row_products['total_products'];
    }
    $stmt_products->close();
}

$stmt_orders = $conn->prepare("SELECT COUNT(*) AS total_orders FROM orders");
if ($stmt_orders) {
    $stmt_orders->execute();
    $result_orders = $stmt_orders->get_result();
    if ($result_orders) {
        $row_orders = $result_orders->fetch_assoc();
        $total_orders = $row_orders['total_orders'];
    }
    $stmt_orders->close();
}

$admin_id = $_SESSION['admin_id'] ?? null;
$admin_name = 'Admin';
$last_login = 'N/A';
if ($admin_id !== null) {
    $stmt = $conn->prepare("SELECT name, last_login_at FROM admins WHERE admin_id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();
    $stmt->close();
    $admin_name = isset($admin['name']) ? htmlspecialchars($admin['name']) : 'Admin';
    $last_login = isset($admin['last_login_at']) ? htmlspecialchars($admin['last_login_at']) : 'N/A';
}

$current_page = basename(__FILE__);
$page_title = "Manage FAQs | KridaArena";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add_faq'])) {
        $question = $_POST['question'];
        $answer = $_POST['answer'];
        $add_stmt = $conn->prepare("INSERT INTO faqs (question, answer) VALUES (?, ?)");
        $add_stmt->bind_param("ss", $question, $answer);
        if ($add_stmt->execute()) {
            $_SESSION['success_message'] = "FAQ added successfully!";
        } else {
            $_SESSION['error_message'] = "Error adding FAQ: " . $conn->error;
        }
        $add_stmt->close();
    } elseif (isset($_POST['edit_faq'])) {
        $faq_id = $_POST['faq_id'];
        $question = $_POST['question'];
        $answer = $_POST['answer'];
        $edit_stmt = $conn->prepare("UPDATE faqs SET question = ?, answer = ? WHERE id = ?");
        $edit_stmt->bind_param("ssi", $question, $answer, $faq_id);
        if ($edit_stmt->execute()) {
            $_SESSION['success_message'] = "FAQ updated successfully!";
        } else {
            $_SESSION['error_message'] = "Error updating FAQ: " . $conn->error;
        }
        $edit_stmt->close();
    } elseif (isset($_POST['delete_faq'])) {
        $faq_id_to_delete = $_POST['faq_id'];
        $delete_stmt = $conn->prepare("DELETE FROM faqs WHERE id = ?");
        $delete_stmt->bind_param("i", $faq_id_to_delete);
        if ($delete_stmt->execute()) {
            $_SESSION['success_message'] = "FAQ deleted successfully!";
        } else {
            $_SESSION['error_message'] = "Error deleting FAQ: " . $conn->error;
        }
        $delete_stmt->close();
    }
    header("Location: manage_faqs.php");
    exit();
}
$faqs = [];
$faqs_query = "SELECT id, question, answer, created_at FROM faqs ORDER BY created_at ASC";
$result = $conn->query($faqs_query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $faqs[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="admin_style.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #1d2b64, #f8cdda);
            --sidebar-bg: rgba(255, 255, 255, 0.1);
            --card-bg: rgba(255, 255, 255, 0.2);
            --divider-color: rgba(255, 255, 255, 0.3);
            --text-color: #fff;
            --highlight-color: #FFD700;
        }
        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
        }
        .krida-sidebar {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255, 255, 255, 0.18);
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px 0;
        }
        .krida-logo-area {
            padding-bottom: 20px;
        }
        .sidebar-divider {
            border-color: var(--divider-color);
        }
        .krida-nav-menu .nav-link {
            color: rgba(255, 255, 255, 0.8);
            font-weight: 500;
            padding: 12px 20px;
            border-radius: 10px;
            margin: 5px 15px;
            transition: all 0.3s ease;
        }
        .krida-nav-menu .nav-link:hover {
            background: var(--card-bg);
            color: var(--text-color);
            transform: translateX(5px);
        }
        .krida-nav-menu .nav-link.active-link {
            background: rgba(255, 255, 255, 0.3);
            color: var(--text-color);
            box-shadow: 0 4px 15px rgba(255, 255, 255, 0.1);
        }
        .krida-profile-area {
            padding: 15px 20px;
            border-top: 1px solid var(--divider-color);
            margin-top: auto;
        }
        .krida-icon {
            font-size: 1.5rem;
            color: #ffb199;
        }
        .admin-content-wrapper {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            margin: 20px;
            padding: 30px;
            color: var(--text-color);
        }
        .table {
            --bs-table-bg: transparent;
            --bs-table-color: var(--text-color);
            color: var(--text-color);
        }
        .table th {
            border-bottom: 1px solid var(--divider-color);
            color: var(--highlight-color);
        }
        .table tbody tr {
            background-color: rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s ease;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="d-flex w-100 flex-grow-1">
        <div class="col-md-3 col-lg-2 krida-sidebar d-none d-md-block">
            <div class="d-flex flex-column h-100">
                <div class="text-center py-4 krida-logo-area">
                    <h2 class="text-white">
                        <i class="bi bi-trophy-fill me-2 krida-icon"></i> KridaArena
                    </h2>
                </div>
                <hr class="sidebar-divider">
                <ul class="nav flex-column mb-auto krida-nav-menu">
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'admin_dashboard.php') ? 'active-link' : '' ?>" href="admin_dashboard.php">
                            <i class="bi bi-house-door me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_users.php') ? 'active-link' : '' ?>" href="manage_users.php">
                            <i class="bi bi-people me-2"></i> Manage Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_tournaments.php') ? 'active-link' : '' ?>" href="manage_tournaments.php">
                            <i class="bi bi-trophy me-2"></i> Manage Tournaments
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_products.php') ? 'active-link' : '' ?>" href="manage_products.php">
                            <i class="bi bi-bag-fill me-2"></i> Manage Products
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_orders.php') ? 'active-link' : '' ?>" href="manage_orders.php">
                            <i class="bi bi-truck-flatbed me-2"></i> Manage Orders
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_admins.php') ? 'active-link' : '' ?>" href="manage_admins.php">
                            <i class="bi bi-person-gear me-2"></i> Manage Admins
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_feedback.php') ? 'active-link' : '' ?>" href="manage_feedback.php">
                            <i class="bi bi-chat-left-text me-2"></i> Manage Feedback
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_faqs.php') ? 'active-link' : '' ?>" href="manage_faqs.php">
                            <i class="bi bi-question-circle me-2"></i> Manage FAQs
                        </a>
                    </li>
                </ul>
                <hr class="sidebar-divider">
                <div class="krida-profile-area dropup">
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle me-2 krida-icon"></i> <strong><?= $admin_name ?></strong>
                    </a>
                    <p class="text-white-50 mt-2 mb-0" style="font-size: 0.8rem;">
                        Last Login: <?= ($last_login != 'N/A') ? date('d M Y, h:i A', strtotime($last_login)) : 'N/A' ?>
                    </p>
                    <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                        <li><a class="dropdown-item" href="admin_logout.php"><i class="bi bi-box-arrow-right"></i> Sign out</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="admin-content-wrapper container-fluid py-4 flex-grow-1">
            <h1 class="display-5 fw-bold mb-4 animate__animated animate__fadeInDown"><?= htmlspecialchars($page_title) ?></h1>
            
            <div class="mb-4 p-4 rounded bg-dark bg-opacity-50 animate__animated animate__fadeInUp">
                <h5 class="fw-bold text-white mb-3">Add New FAQ</h5>
                <form method="POST" action="manage_faqs.php">
                    <div class="mb-3">
                        <label for="question" class="form-label">Question</label>
                        <input type="text" class="form-control" id="question" name="question" required>
                    </div>
                    <div class="mb-3">
                        <label for="answer" class="form-label">Answer</label>
                        <textarea class="form-control" id="answer" name="answer" rows="3" required></textarea>
                    </div>
                    <button type="submit" name="add_faq" class="btn btn-primary"><i class="bi bi-plus-circle me-2"></i>Add FAQ</button>
                </form>
            </div>
            
            <div class="table-responsive animate__animated animate__fadeInUp">
                <table class="table table-borderless table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Question</th>
                            <th>Answer</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($faqs) > 0): ?>
                            <?php foreach ($faqs as $faq): ?>
                                <tr>
                                    <td><?= htmlspecialchars($faq['id']) ?></td>
                                    <td><?= htmlspecialchars($faq['question']) ?></td>
                                    <td><?= htmlspecialchars($faq['answer']) ?></td>
                                    <td><?= date('M d, Y', strtotime(htmlspecialchars($faq['created_at']))) ?></td>
                                    <td>
                                        <button type="button" class="btn btn-warning btn-sm me-2" data-bs-toggle="modal" data-bs-target="#editModal<?= htmlspecialchars($faq['id']) ?>">
                                            <i class="bi bi-pencil"></i> Edit
                                        </button>
                                        <form method="POST" action="manage_faqs.php" class="d-inline">
                                            <input type="hidden" name="faq_id" value="<?= htmlspecialchars($faq['id']) ?>">
                                            <button type="submit" name="delete_faq" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this FAQ?');">
                                                <i class="bi bi-trash"></i> Delete
                                            </button>
                                        </form>

                                        <div class="modal fade" id="editModal<?= htmlspecialchars($faq['id']) ?>" tabindex="-1" aria-labelledby="editModalLabel<?= htmlspecialchars($faq['id']) ?>" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title text-dark" id="editModalLabel<?= htmlspecialchars($faq['id']) ?>">Edit FAQ</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form method="POST" action="manage_faqs.php">
                                                            <input type="hidden" name="faq_id" value="<?= htmlspecialchars($faq['id']) ?>">
                                                            <div class="mb-3">
                                                                <label for="edit_question" class="form-label text-dark">Question</label>
                                                                <input type="text" class="form-control" id="edit_question" name="question" value="<?= htmlspecialchars($faq['question']) ?>" required>
                                                            </div>
                                                            <div class="mb-3">
                                                                <label for="edit_answer" class="form-label text-dark">Answer</label>
                                                                <textarea class="form-control" id="edit_answer" name="answer" rows="3" required><?= htmlspecialchars($faq['answer']) ?></textarea>
                                                            </div>
                                                            <div class="d-flex justify-content-end">
                                                                <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Close</button>
                                                                <button type="submit" name="edit_faq" class="btn btn-primary">Save changes</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">No FAQs found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>