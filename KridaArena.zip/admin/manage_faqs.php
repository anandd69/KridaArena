<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$total_users = 0;
$total_tournaments = 0;
$total_products = 0;
$total_orders = 0;

$stmt_users = $conn->prepare("SELECT COUNT(*) AS total_users FROM users");
if ($stmt_users) {
    $stmt_users->execute();
    $result_users = $stmt_users->get_result();
    if ($result_users) {
        $row_users = $result_users->fetch_assoc();
        $total_users = $row_users['total_users'];
    }
    $stmt_users->close();
}

$stmt_tournaments = $conn->prepare("SELECT COUNT(*) AS total_tournaments FROM tournaments");
if ($stmt_tournaments) {
    $stmt_tournaments->execute();
    $result_tournaments = $stmt_tournaments->get_result();
    if ($result_tournaments) {
        $row_tournaments = $result_tournaments->fetch_assoc();
        $total_tournaments = $row_tournaments['total_tournaments'];
    }
    $stmt_tournaments->close();
}

$stmt_products = $conn->prepare("SELECT COUNT(*) AS total_products FROM products");
if ($stmt_products) {
    $stmt_products->execute();
    $result_products = $stmt_products->get_result();
    if ($result_products) {
        $row_products = $result_products->fetch_assoc();
        $total_products = $row_products['total_products'];
    }
    $stmt_products->close();
}

$stmt_orders = $conn->prepare("SELECT COUNT(*) AS total_orders FROM orders");
if ($stmt_orders) {
    $stmt_orders->execute();
    $result_orders = $stmt_orders->get_result();
    if ($result_orders) {
        $row_orders = $result_orders->fetch_assoc();
        $total_orders = $row_orders['total_orders'];
    }
    $stmt_orders->close();
}

$admin_id = $_SESSION['admin_id'] ?? null;
$admin_name = 'Admin';
$last_login = 'N/A';
if ($admin_id !== null) {
    $stmt = $conn->prepare("SELECT name, last_login_at FROM admins WHERE admin_id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();
    $stmt->close();
    $admin_name = isset($admin['name']) ? htmlspecialchars($admin['name']) : 'Admin';
    $last_login = isset($admin['last_login_at']) ? htmlspecialchars($admin['last_login_at']) : 'N/A';
}

$current_page = basename(__FILE__);
$page_title = "Manage FAQs | KridaArena";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add_faq'])) {
        $question = trim($_POST['question'] ?? '');
        $answer = trim($_POST['answer'] ?? '');
        if (!empty($question) && !empty($answer)) {
            $insert_stmt = $conn->prepare("INSERT INTO faqs (question, answer) VALUES (?, ?)");
            if ($insert_stmt) {
                $insert_stmt->bind_param("ss", $question, $answer);
                if ($insert_stmt->execute()) {
                    $_SESSION['alert'] = ['type' => 'success', 'title' => 'Success!', 'text' => 'FAQ added successfully.'];
                } else {
                    $_SESSION['alert'] = ['type' => 'error', 'title' => 'Error', 'text' => 'Database error: ' . $insert_stmt->error];
                }
                $insert_stmt->close();
            } else {
                 $_SESSION['alert'] = ['type' => 'error', 'title' => 'System Error', 'text' => 'Failed to prepare query: ' . $conn->error];
            }
        } else {
            $_SESSION['alert'] = ['type' => 'error', 'title' => 'Validation Error', 'text' => 'Question and Answer fields cannot be empty.'];
        }
    } elseif (isset($_POST['edit_faq'])) {
        $id = (int)$_POST['id'];
        $question = trim($_POST['question'] ?? '');
        $answer = trim($_POST['answer'] ?? '');
        if (!empty($question) && !empty($answer) && $id > 0) {
            $update_stmt = $conn->prepare("UPDATE faqs SET question = ?, answer = ? WHERE id = ?");
            if ($update_stmt) {
                $update_stmt->bind_param("ssi", $question, $answer, $id);
                if ($update_stmt->execute()) {
                    $_SESSION['alert'] = ['type' => 'success', 'title' => 'Success!', 'text' => 'FAQ updated successfully.'];
                } else {
                    $_SESSION['alert'] = ['type' => 'error', 'title' => 'Error', 'text' => 'Database error: ' . $update_stmt->error];
                }
                $update_stmt->close();
            } else {
                 $_SESSION['alert'] = ['type' => 'error', 'title' => 'System Error', 'text' => 'Failed to prepare query: ' . $conn->error];
            }
        } else {
            $_SESSION['alert'] = ['type' => 'error', 'title' => 'Validation Error', 'text' => 'Invalid data provided for update.'];
        }
    } elseif (isset($_POST['delete_faq'])) {
        $id = (int)$_POST['id'];
        if ($id > 0) {
            $delete_stmt = $conn->prepare("DELETE FROM faqs WHERE id = ?");
            if ($delete_stmt) {
                $delete_stmt->bind_param("i", $id);
                if ($delete_stmt->execute()) {
                    $_SESSION['alert'] = ['type' => 'success', 'title' => 'Success!', 'text' => 'FAQ deleted successfully.'];
                } else {
                    $_SESSION['alert'] = ['type' => 'error', 'title' => 'Error', 'text' => 'Database error: ' . $delete_stmt->error];
                }
                $delete_stmt->close();
            } else {
                 $_SESSION['alert'] = ['type' => 'error', 'title' => 'System Error', 'text' => 'Failed to prepare query: ' . $conn->error];
            }
        }
    }
    header("Location: manage_faqs.php");
    exit();
}

$faqs_list = [];
$faqs_query = "SELECT id, question, answer, created_at FROM faqs ORDER BY id ASC";
$result = $conn->query($faqs_query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $faqs_list[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <script src="../js/sweetalert2@11.js"></script>
    <link rel="stylesheet" href="admin_style.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #1d2b64, #f8cdda);
            --sidebar-bg: rgba(255, 255, 255, 0.1);
            --card-bg: rgba(255, 255, 255, 0.2);
            --divider-color: rgba(255, 255, 255, 0.3);
            --text-color: #fff;
            --highlight-color: #FFD700;
        }
        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
        }
        .admin-content-wrapper {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            margin: 20px;
            padding: 30px;
            color: var(--text-color);
        }
        .admin-content-wrapper h1 {
            color: var(--text-color);
        }
        .card-recent {
            background: rgba(0, 0, 0, 0.5); 
            border: none;
            border-radius: 15px;
        }
        .card-recent .card-title,
        .card-recent .card-text {
            color: var(--text-color) !important;
        }
        .table {
            --bs-table-bg: transparent;
            --bs-table-color: var(--text-color);
            color: var(--text-color);
        }
        .table th {
            border-bottom: 1px solid var(--divider-color);
            color: var(--highlight-color);
        }
        .table tbody tr {
            background-color: rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s ease;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        .modal-content {
            background: #2c3e50;
            color: #fff;
        }
        .modal-header {
            border-bottom-color: #3e5367;
        }
        .form-label {
            color: #fff;
        }
        .btn-warning img,
        .btn-danger img {
            width: 16px; 
            height: 16px;
            margin-right: 5px; 
            vertical-align: sub;
        }
        .icon-white {
            filter: brightness(0) invert(1);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="d-flex w-100 flex-grow-1">
        <?php 
        require_once '../admin/admin_sidebar.php';
        ?>
        <div class="admin-content-wrapper container-fluid py-4 flex-grow-1">
            <h1 class="display-5 fw-bold mb-4 animate__animated animate__fadeInDown"><?= htmlspecialchars($page_title) ?></h1>
            
            <div class="d-flex justify-content-end mb-3">
                <button type="button" class="btn btn-primary animate__animated animate__fadeIn" data-bs-toggle="modal" data-bs-target="#addFaqModal">
                    <img src="../png/mark.png" alt="Add FAQ Icon" class="me-2 icon-white" style="width: 16px; height: 16px;"> Add New FAQ
                </button>
            </div>

            <div class="card card-recent animate__animated animate__fadeInUp">
                <div class="card-body">
                    <h5 class="card-title fw-bold">FAQs List (<?= count($faqs_list) ?>)</h5>
                    <p class="card-text">Manage all frequently asked questions displayed on the client side.</p>
                    <div class="table-responsive">
                        <table class="table table-borderless table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Question</th>
                                    <th>Answer</th>
                                    <th>Created At</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($faqs_list)): ?>
                                    <?php foreach ($faqs_list as $faq): ?>
                                <tr>
                                    <td><?= htmlspecialchars($faq['id']) ?></td>
                                    <td><?= htmlspecialchars($faq['question']) ?></td>
                                    <td><?= substr(htmlspecialchars($faq['answer']), 0, 100) . (strlen($faq['answer']) > 100 ? '...' : '') ?></td>
                                    <td><?= date('M d, Y', strtotime(htmlspecialchars($faq['created_at']))) ?></td>
                                    <td>
                                        <div class="d-flex">
                                            <button type="button" class="btn btn-warning btn-sm me-2 edit-btn" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editFaqModal" 
                                                data-id="<?= htmlspecialchars($faq['id']) ?>" 
                                                data-question="<?= htmlspecialchars($faq['question']) ?>" 
                                                data-answer="<?= htmlspecialchars($faq['answer']) ?>">
                                                <img src="../png/2reg.png" alt="Edit Icon"> 
                                            </button>
                                            <form method="POST" action="manage_faqs.php" class="d-inline">
                                                <input type="hidden" name="id" value="<?= htmlspecialchars($faq['id']) ?>">
                                                <button type="submit" name="delete_faq" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this FAQ?');">
                                                    <img src="../png/trash.png" alt="Delete Icon"> 
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">No FAQs found. Click "Add New FAQ" to create one.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addFaqModal" tabindex="-1" aria-labelledby="addFaqModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addFaqModalLabel">Add New FAQ</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="manage_faqs.php">
                        <div class="mb-3">
                            <label for="add_question" class="form-label">Question</label>
                            <input type="text" class="form-control" id="add_question" name="question" required>
                        </div>
                        <div class="mb-3">
                            <label for="add_answer" class="form-label">Answer</label>
                            <textarea class="form-control" id="add_answer" name="answer" rows="3" required></textarea>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Close</button>
                            <button type="submit" name="add_faq" class="btn btn-primary">Add FAQ</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="editFaqModal" tabindex="-1" aria-labelledby="editFaqModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editFaqModalLabel">Edit FAQ</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="manage_faqs.php" id="edit-faq-form">
                        <input type="hidden" name="id" id="edit_id">
                        <div class="mb-3">
                            <label for="edit_question" class="form-label">Question</label>
                            <input type="text" class="form-control" id="edit_question" name="question" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_answer" class="form-label">Answer</label>
                            <textarea class="form-control" id="edit_answer" name="answer" rows="3" required></textarea>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Close</button>
                            <button type="submit" name="edit_faq" class="btn btn-primary">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var editModal = document.getElementById('editFaqModal');
            editModal.addEventListener('show.bs.modal', function (event) {
                var button = event.relatedTarget;
                var id = button.getAttribute('data-id');
                var question = button.getAttribute('data-question');
                var answer = button.getAttribute('data-answer');

                var modalId = editModal.querySelector('#edit_id');
                var modalQuestion = editModal.querySelector('#edit_question');
                var modalAnswer = editModal.querySelector('#edit_answer');

                modalId.value = id;
                modalQuestion.value = question;
                modalAnswer.value = answer;
            });

            <?php if (isset($_SESSION['alert'])): 
                $alert = $_SESSION['alert'];
            ?>
                Swal.fire({
                    icon: '<?= htmlspecialchars($alert['type']) ?>',
                    title: '<?= htmlspecialchars($alert['title']) ?>',
                    text: '<?= htmlspecialchars($alert['text']) ?>',
                });
            <?php unset($_SESSION['alert']); endif; ?>
        });
    </script>
</body>
</html>