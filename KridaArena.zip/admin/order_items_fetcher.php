<?php
require_once '../config/db.php'; 

header('Content-Type: application/json');

if (!isset($_GET['order_id']) || empty($_GET['order_id'])) {
    http_response_code(400);
    echo json_encode(["error" => "Order ID is required."]);
    exit();
}

$order_id = intval($_GET['order_id']);
$items = [];

$query = "
    SELECT
        oi.quantity,
        oi.price_at_purchase,
        p.name AS product_name
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $items[] = $row;
    }
}

$stmt->close();
$conn->close();

echo json_encode($items);

exit();
?>