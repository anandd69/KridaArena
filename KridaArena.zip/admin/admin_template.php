<?php
function is_admin_online($last_login_at) {
    if (!$last_login_at) {
        return false;
    }
    $current_time = new DateTime();
    $last_login_time = new DateTime($last_login_at);
    $interval = $current_time->diff($last_login_time);
    $minutes = $interval->i;
    $hours = $interval->h;
    $days = $interval->d;
    return ($days == 0 && $hours == 0 && $minutes <= 5);
}
if (basename(__FILE__) == basename($_SERVER['PHP_SELF'])) {
    // If accessed directly, redirect to dashboard or show an error
    header("Location: admin_dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="admin_style.css">
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="d-flex w-100 flex-grow-1">
        <div class="col-md-3 col-lg-2 krida-sidebar d-none d-md-block">
            <div class="d-flex flex-column h-100">
                <div class="text-center py-4 krida-logo-area">
                    <h2 class="text-white">
                        <i class="bi bi-trophy-fill me-2 krida-icon"></i> KridaArena
                    </h2>
                </div>
                <hr class="sidebar-divider">
                <ul class="nav flex-column mb-auto krida-nav-menu">
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'admin_dashboard.php') ? 'active-link' : '' ?>" href="admin_dashboard.php">
                            <i class="bi bi-house-door me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_users.php') ? 'active-link' : '' ?>" href="manage_users.php">
                            <i class="bi bi-people me-2"></i> Manage Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_tournaments.php') ? 'active-link' : '' ?>" href="manage_tournaments.php">
                            <i class="bi bi-trophy me-2"></i> Manage Tournaments
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_products.php') ? 'active-link' : '' ?>" href="manage_products.php">
                            <i class="bi bi-bag-fill me-2"></i> Manage Products
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_orders.php') ? 'active-link' : '' ?>" href="manage_orders.php">
                            <i class="bi bi-truck-flatbed me-2"></i> Manage Orders
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_admins.php') ? 'active-link' : '' ?>" href="manage_admins.php">
                            <i class="bi bi-person-gear me-2"></i> Manage Admins
                        </a>
                    </li>
                </ul>
                <hr class="sidebar-divider">
                <div class="krida-profile-area dropup">
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle me-2 krida-icon"></i> <strong><?= $admin_name ?></strong>
                    </a>
                    <p class="text-white-50 mt-2 mb-0" style="font-size: 0.8rem;">
                        Last Login: <?= ($last_login != 'N/A') ? date('d M Y, h:i A', strtotime($last_login)) : 'N/A' ?>
                    </p>
                    <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                        <li><a class="dropdown-item" href="admin_logout.php"><i class="bi bi-box-arrow-right"></i> Sign out</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="admin-content-wrapper container-fluid py-4 flex-grow-1">
            <h1 class="display-5 fw-bold mb-4 animate__animated animate__fadeInDown"><?= htmlspecialchars($page_title) ?></h1>
<?php
session_start();
require_once '../config/db.php'; 
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
$total_users = 0;
$total_tournaments = 0;
$total_products = 0;
$total_orders = 0;
$stmt_users = $conn->prepare("SELECT COUNT(*) AS total_users FROM users");
if ($stmt_users) {
    $stmt_users->execute();
    $result_users = $stmt_users->get_result();
    if ($result_users) {
        $row_users = $result_users->fetch_assoc();
        $total_users = $row_users['total_users'];
    }
    $stmt_users->close();
}
$stmt_tournaments = $conn->prepare("SELECT COUNT(*) AS total_tournaments FROM tournaments");
if ($stmt_tournaments) {
    $stmt_tournaments->execute();
    $result_tournaments = $stmt_tournaments->get_result();
    if ($result_tournaments) {
        $row_tournaments = $result_tournaments->fetch_assoc();
        $total_tournaments = $row_tournaments['total_tournaments'];
    }
    $stmt_tournaments->close();
}
$stmt_products = $conn->prepare("SELECT COUNT(*) AS total_products FROM products");
if ($stmt_products) {
    $stmt_products->execute();
    $result_products = $stmt_products->get_result();
    if ($result_products) {
        $row_products = $result_products->fetch_assoc();
        $total_products = $row_products['total_products'];
    }
    $stmt_products->close();
}
$stmt_orders = $conn->prepare("SELECT COUNT(*) AS total_orders FROM orders");
if ($stmt_orders) {
    $stmt_orders->execute();
    $result_orders = $stmt_orders->get_result();
    if ($result_orders) {
        $row_orders = $result_orders->fetch_assoc();
        $total_orders = $row_orders['total_orders'];
    }
    $stmt_orders->close();
}
$admin_id = $_SESSION['admin_id'] ?? null;
$admin_name = 'Admin';
$last_login = 'N/A';
if ($admin_id !== null) {
    $stmt = $conn->prepare("SELECT name, last_login_at FROM admins WHERE admin_id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();
    $stmt->close();
    $admin_name = isset($admin['name']) ? htmlspecialchars($admin['name']) : 'Admin';
    $last_login = isset($admin['last_login_at']) ? htmlspecialchars($admin['last_login_at']) : 'N/A';
}

$current_page = basename(__FILE__);
$page_title = "Admin Dashboard | KridaArena";
?>

<?php include 'admin_template.php'; ?>

<div class="row g-4">
    <div class="col-md-3">
        <div class="card card-stats h-100 animate__animated animate__fadeInUp">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="icon-box bg-users">
                        <i class="bi bi-people-fill"></i>
                    </div>
                    <div class="text-end">
                        <h5 class="text-muted fw-normal mb-2">Total Users</h5>
                        <h3 class="stat-number mb-0"><?= $total_users ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card card-stats h-100 animate__animated animate__fadeInUp animate__delay-1s">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="icon-box bg-tournaments">
                        <i class="bi bi-trophy-fill"></i>
                    </div>
                    <div class="text-end">
                        <h5 class="text-muted fw-normal mb-2">Total Tournaments</h5>
                        <h3 class="stat-number mb-0"><?= $total_tournaments ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card card-stats h-100 animate__animated animate__fadeInUp animate__delay-2s">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="icon-box bg-products">
                        <i class="bi bi-bag-fill"></i>
                    </div>
                    <div class="text-end">
                        <h5 class="text-muted fw-normal mb-2">Total Products</h5>
                        <h3 class="stat-number mb-0"><?= $total_products ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card card-stats h-100 animate__animated animate__fadeInUp animate__delay-3s">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="icon-box bg-orders">
                        <i class="bi bi-box-seam-fill"></i>
                    </div>
                    <div class="text-end">
                        <h5 class="text-muted fw-normal mb-2">Total Orders</h5>
                        <h3 class="stat-number mb-0"><?= $total_orders ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="mt-5">
    <div class="row g-4">
        <div class="col-md-6">
            <div class="card card-recent animate__animated animate__fadeInLeft">
                <div class="card-body">
                    <h5 class="card-title fw-bold">Recent Registrations</h5>
                    <p class="card-text text-muted">Latest tournament sign-ups.</p>
                    <div class="table-responsive">
                        <table class="table table-borderless table-hover">
                            <thead>
                                <tr>
                                    <th>Team Name</th>
                                    <th>Sport</th>
                                    <th>Registered On</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $recent_regs_query = "SELECT r.team_name, r.sport_type, r.registration_date FROM registrations r ORDER BY r.registration_date DESC LIMIT 5";
                                $recent_regs_stmt = $conn->prepare($recent_regs_query);
                                $recent_regs_stmt->execute();
                                $recent_regs_result = $recent_regs_stmt->get_result();
                                if ($recent_regs_result->num_rows > 0) {
                                    while ($row = $recent_regs_result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . htmlspecialchars($row['team_name']) . "</td>";
                                        echo "<td>" . htmlspecialchars($row['sport_type']) . "</td>";
                                        echo "<td>" . date('M d, Y', strtotime($row['registration_date'])) . "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='3' class='text-center text-muted'>No recent registrations.</td></tr>";
                                }
                                $recent_regs_stmt->close();
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card card-recent animate__animated animate__fadeInRight">
                <div class="card-body">
                    <h5 class="card-title fw-bold">Recent Orders</h5>
                    <p class="card-text text-muted">Latest product purchases.</p>
                    <div class="table-responsive">
                        <table class="table table-borderless table-hover">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Total Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $recent_orders_query = "SELECT order_id, total_amount, status FROM orders ORDER BY created_at DESC LIMIT 5";
                                $recent_orders_stmt = $conn->prepare($recent_orders_query);
                                $recent_orders_stmt->execute();
                                $recent_orders_result = $recent_orders_stmt->get_result();
                                if ($recent_orders_result->num_rows > 0) {
                                    while ($row = $recent_orders_result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . htmlspecialchars($row['order_id']) . "</td>";
                                        echo "<td>Rs. " . number_format($row['total_amount'], 2) . "</td>";
                                        echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='3' class='text-center text-muted'>No recent orders.</td></tr>";
                                }
                                $recent_orders_stmt->close();
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

        </div> </div> 
</body>
</html>