<?php
session_start();
require_once '../config/db.php'; 
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
if (isset($_GET['action']) && $_GET['action'] === 'fetch_items' && isset($_GET['order_id'])) {
    $order_id = intval($_GET['order_id']);
    header('Content-Type: application/json');
    
    $items = [];
    $query = "
        SELECT 
            oi.quantity, 
            oi.price_at_purchase AS price, 
            p.name AS product_name
        FROM order_items oi
        JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id = ?
    ";
    
    $stmt = $conn->prepare($query);
    
    if ($stmt === false) {
        echo json_encode(['error' => 'Database error: Failed to prepare statement.']);
        exit();
    }
    
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $row['price'] = number_format($row['price'], 2, '.', '');
            $items[] = $row;
        }
    }
    $stmt->close();
    echo json_encode($items);
    exit();
}

$page_title = "Manage Orders | Admin Panel";
$msg = '';
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    if ($delete_id > 0) {
        $delete_query = "DELETE FROM orders WHERE order_id = ?";
        $stmt = $conn->prepare($delete_query);
        $stmt->bind_param("i", $delete_id);
        if ($stmt->execute()) {
            $msg = "<div class='alert alert-success'>Order (ID: #{$delete_id}) deleted successfully.</div>";
        } else {
            $msg = "<div class='alert alert-danger'>Error deleting order: " . $conn->error . "</div>";
        }
        $stmt->close();
        header("Location: manage_orders.php?msg=" . urlencode(strip_tags($msg)));
        exit();
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $order_id = intval($_POST['order_id']);
    $new_status = trim($_POST['status']);

    if ($order_id > 0) {
        $update_query = "UPDATE orders SET status=? WHERE order_id=?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param("si", $new_status, $order_id);
        if ($stmt->execute()) {
            $msg = "<div class='alert alert-success'>Order #{$order_id} status updated to " . htmlspecialchars(ucfirst($new_status)) . ".</div>";
        } else {
            $msg = "<div class='alert alert-danger'>Error updating status: " . $conn->error . "</div>";
        }
        $stmt->close();
        if (strpos($msg, 'Error') === false) {
            header("Location: manage_orders.php?msg=" . urlencode(strip_tags($msg)));
            exit();
        }
    }
}
$orders = [];
$query = "
    SELECT 
        o.order_id, 
        o.total_amount, 
        o.created_at AS order_date, 
        o.status,
        u.name AS user_name,
        u.email AS user_email,
        sa.address,
        sa.city,
        sa.state,
        sa.zip
    FROM orders o
    JOIN users u ON o.user_id = u.id
    LEFT JOIN saved_addresses sa ON o.shipping_address_id = sa.id
    ORDER BY o.created_at DESC
";
$result = $conn->query($query);
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }
}
if (isset($_GET['msg'])) {
    $msg = "<div class='alert alert-success'>" . htmlspecialchars($_GET['msg']) . "</div>";
}
$admin_id = $_SESSION['admin_id'] ?? null;
$admin_name = 'Admin';
$last_login = 'N/A';
if ($admin_id !== null) {
    $stmt = $conn->prepare("SELECT name, last_login_at FROM admins WHERE admin_id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();
    $stmt->close();
    $admin_name = isset($admin['name']) ? htmlspecialchars($admin['name']) : 'Admin';
    $last_login = isset($admin['last_login_at']) ? htmlspecialchars($admin['last_login_at']) : 'N/A';
}
$sidebar_sections = [
    'admin_dashboard.php' => ['name' => 'Dashboard', 'icon' => 'bi-house-door'],
    'manage_users.php' => ['name' => 'Manage Users', 'icon' => 'bi-people'],
    'manage_tournaments.php' => ['name' => 'Manage Tournaments', 'icon' => 'bi-trophy'],
    'manage_products.php' => ['name' => 'Manage Products', 'icon' => 'bi-bag-fill'],
    'manage_orders.php' => ['name' => 'Manage Orders', 'icon' => 'bi-truck-flatbed'],
    'manage_admins.php' => ['name' => 'Manage Admins', 'icon' => 'bi-person-gear'],
    'manage_feedback.php' => ['name' => 'Manage Feedback', 'icon' => 'bi-chat-left-text'],
    'manage_faqs.php' => ['name' => 'Manage FAQs', 'icon' => 'bi-question-circle'],
];
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="admin_style.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #1d2b64, #f8cdda);
            --sidebar-bg: rgba(255, 255, 255, 0.1);
            --card-bg: rgba(255, 255, 255, 0.2);
            --divider-color: rgba(255, 255, 255, 0.3);
            --text-color: #fff;
            --highlight-color: #FFD700; 
        }
        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
        }
        .admin-content-wrapper {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            margin: 20px;
            padding: 30px;
            color: var(--text-color);
        }
        .card-recent {
            background: rgba(0, 0, 0, 0.5); 
            border: none;
            border-radius: 15px;
        }
        .card-recent .card-title,
        .card-recent .card-text {
            color: var(--text-color);
        }
        .table {
            --bs-table-bg: transparent; 
            --bs-table-color: var(--text-color);
            color: var(--text-color);
        }
        .table th {
            border-bottom: 1px solid var(--divider-color);
            color: var(--highlight-color);
        }
        .table tbody tr {
            background-color: rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s ease;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        .modal-content {
            background-color: var(--card-bg);
            border-radius: 15px;
            border: none;
            backdrop-filter: blur(10px);
        }
        .modal-header, .modal-footer {
            border-color: var(--divider-color);
        }
        .btn-primary img,
        .btn-danger img {
            width: 16px; 
            height: 16px;
            margin-right: 5px; 
            vertical-align: sub;
        }
        .icon-white {
            filter: brightness(0) invert(1);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="d-flex w-100 flex-grow-1">
        <?php 
        require_once '../admin/admin_sidebar.php';
        ?>
        <div class="admin-content-wrapper container-fluid py-4 flex-grow-1">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="display-5 fw-bold animate__animated animate__fadeInDown">Manage Orders</h1>
            </div>
            <?php if (isset($msg)): ?>
                <div class="animate__animated animate__fadeInUp">
                    <?= $msg ?>
                </div>
            <?php endif; ?>
            <div class="table-responsive mt-4">
                <div class="card card-recent animate__animated animate__fadeInUp">
                    <div class="card-body">
                        <h5 class="card-title fw-bold">Order List</h5>
                        <p class="card-text">All customer orders.</p>
                        <table class="table table-borderless table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">Order ID</th>
                                    <th scope="col">Customer</th>
                                    <th scope="col">Date</th>
                                    <th scope="col">Total</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($orders) > 0): ?>
                                    <?php foreach ($orders as $order): ?>
                                        <tr>
                                            <th scope="row">#<span style="color: var(--highlight-color);"><?= htmlspecialchars($order['order_id']) ?></span></th>
                                            <td><?= htmlspecialchars($order['user_name']) ?></td>
                                            <td><?= date("d M Y", strtotime($order['order_date'])) ?></td>
                                            <td>₹<?= number_format(htmlspecialchars($order['total_amount']), 2) ?></td>
                                            <td>
                                                <span class="badge 
                                                    <?php
                                                        $status = strtolower($order['status']);
                                                        if ($status == 'delivered') echo 'bg-success';
                                                        elseif ($status == 'shipped') echo 'bg-info';
                                                        elseif ($status == 'processing') echo 'bg-warning text-dark';
                                                        elseif ($status == 'cancelled') echo 'bg-danger';
                                                        else echo 'bg-secondary';
                                                    ?>">
                                                    <?= htmlspecialchars(ucfirst($order['status'])) ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-primary btn-sm view-details-btn" 
                                                        data-bs-toggle="modal" data-bs-target="#orderDetailsModal"
                                                        data-id="<?= htmlspecialchars($order['order_id']) ?>"
                                                        data-total="<?= number_format(htmlspecialchars($order['total_amount']), 2) ?>"
                                                        data-user="<?= htmlspecialchars($order['user_name']) ?>"
                                                        data-date="<?= date("d M Y", strtotime(htmlspecialchars($order['order_date']))) ?>"
                                                        data-status="<?= htmlspecialchars($order['status']) ?>"
                                                        data-address="<?= htmlspecialchars($order['address'] . ', ' . $order['city'] . ', ' . $order['state'] . ' - ' . $order['zip']) ?>">
                                                    <img src="../png/view.png" alt="View Icon" class="icon-white" style="width: 16px; height: 16px; margin-right: 5px; vertical-align: sub;"> View
                                                </button>
                                                <a href="manage_orders.php?delete_id=<?= htmlspecialchars($order['order_id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this order? This action cannot be undone.');"> 
                                                    <img src="../png/trash.png" alt="Delete Icon" class="icon-white" style="width: 16px; height: 16px; margin-right: 5px; vertical-align: sub;"> Delete 
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">No orders found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="orderDetailsModal" tabindex="-1" aria-labelledby="orderDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content bg-dark text-white">
                <div class="modal-header">
                    <h5 class="modal-title" id="orderDetailsModalLabel">Order Details: <span id="order_title"></span></h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <p><strong>Customer:</strong> <span id="modal_user"></span></p>
                            <p><strong>Order Date:</strong> <span id="modal_date"></span></p>
                            <p><strong>Total Amount:</strong> <span id="modal_total" style="color: var(--highlight-color);"></span></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Shipping Address:</strong> <span id="modal_address"></span></p>
                        </div>
                    </div>
                    <form method="POST" action="manage_orders.php" class="mb-4">
                        <input type="hidden" name="action" value="update_status">
                        <input type="hidden" name="order_id" id="modal_order_id">
                        <div class="row align-items-end">
                            <div class="col-md-6 mb-3">
                                <label for="modal_status" class="form-label">Update Status</label>
                                <select class="form-select" id="modal_status" name="status" required>
                                    <option value="processing">Processing</option>
                                    <option value="shipped">Shipped</option>
                                    <option value="delivered">Delivered</option>
                                    <option value="cancelled">Cancelled</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <button type="submit" class="btn btn-success w-100">Update Status</button>
                            </div>
                        </div>
                    </form>
                    <h6 class="mt-4 mb-2">Order Items</h6>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody id="order_items_table_body">
                                <tr><td colspan="4" class="text-center text-muted">Loading items...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            function fetchOrderItems(orderId) {
                const tableBody = document.getElementById('order_items_table_body');
                tableBody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">Loading items...</td></tr>';
                fetch(`manage_orders.php?action=fetch_items&order_id=${orderId}`) 
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok. Status: ' + response.status);
                        }
                        return response.json();
                    })
                    .then(items => {
                        let html = '';
                        if (items.length > 0) {
                            items.forEach(item => {
                                const subtotal = (parseFloat(item.price) * parseInt(item.quantity)).toFixed(2);
                                html += `
                                    <tr>
                                        <td>${item.product_name}</td>
                                        <td>₹${item.price}</td>
                                        <td>${item.quantity}</td>
                                        <td>₹${subtotal}</td>
                                    </tr>
                                `;
                            });
                        } else {
                            html = '<tr><td colspan="4" class="text-center text-muted">No items found for this order.</td></tr>';
                        }
                        tableBody.innerHTML = html;
                    })
                    .catch(error => {
                        console.error('Error fetching order items:', error);
                        tableBody.innerHTML = '<tr><td colspan="4" class="text-center text-danger">Failed to load items. Check PHP error log and database connection/schema.</td></tr>';
                    });
            }
            document.querySelectorAll('.view-details-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const id = this.getAttribute('data-id');
                    const total = this.getAttribute('data-total');
                    const user = this.getAttribute('data-user');
                    const date = this.getAttribute('data-date');
                    const status = this.getAttribute('data-status');
                    const address = this.getAttribute('data-address');

                    document.getElementById('order_title').textContent = `Order #` + id;
                    document.getElementById('modal_order_id').value = id;
                    document.getElementById('modal_user').textContent = user;
                    document.getElementById('modal_date').textContent = date;
                    document.getElementById('modal_total').textContent = `₹${total}`;
                    document.getElementById('modal_address').textContent = address;
                    document.getElementById('modal_status').value = status.toLowerCase();
                    fetchOrderItems(id); 
                });
            });
        });
    </script>
</body>
</html>