<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
$total_users = 0;
$total_tournaments = 0;
$total_products = 0;
$total_orders = 0;

$stmt_users = $conn->prepare("SELECT COUNT(*) AS total_users FROM users");
if ($stmt_users) {
    $stmt_users->execute();
    $result_users = $stmt_users->get_result();
    if ($result_users) {
        $row_users = $result_users->fetch_assoc();
        $total_users = $row_users['total_users'];
    }
    $stmt_users->close();
}

$stmt_tournaments = $conn->prepare("SELECT COUNT(*) AS total_tournaments FROM tournaments");
if ($stmt_tournaments) {
    $stmt_tournaments->execute();
    $result_tournaments = $stmt_tournaments->get_result();
    if ($result_tournaments) {
        $row_tournaments = $result_tournaments->fetch_assoc();
        $total_tournaments = $row_tournaments['total_tournaments'];
    }
    $stmt_tournaments->close();
}

$stmt_products = $conn->prepare("SELECT COUNT(*) AS total_products FROM products");
if ($stmt_products) {
    $stmt_products->execute();
    $result_products = $stmt_products->get_result();
    if ($result_products) {
        $row_products = $result_products->fetch_assoc();
        $total_products = $row_products['total_products'];
    }
    $stmt_products->close();
}

$stmt_orders = $conn->prepare("SELECT COUNT(*) AS total_orders FROM orders");
if ($stmt_orders) {
    $stmt_orders->execute();
    $result_orders = $stmt_orders->get_result();
    if ($result_orders) {
        $row_orders = $result_orders->fetch_assoc();
        $total_orders = $row_orders['total_orders'];
    }
    $stmt_orders->close();
}
$admin_id = $_SESSION['admin_id'] ?? null;
$admin_name = 'Admin';
$last_login = 'N/A';
if ($admin_id !== null) {
    $stmt = $conn->prepare("SELECT name, last_login_at FROM admins WHERE admin_id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();
    $stmt->close();
    $admin_name = isset($admin['name']) ? htmlspecialchars($admin['name']) : 'Admin';
    $last_login = isset($admin['last_login_at']) ? htmlspecialchars($admin['last_login_at']) : 'N/A';
}

$current_page = basename(__FILE__);
$page_title = "Manage Feedback | KridaArena";
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_feedback'])) {
    $feedback_id_to_delete = $_POST['feedback_id'];
    $delete_stmt = $conn->prepare("DELETE FROM feedbacks WHERE id = ?");
    $delete_stmt->bind_param("i", $feedback_id_to_delete);
    if ($delete_stmt->execute()) {
        $_SESSION['success_message'] = "Feedback deleted successfully!";
    } else {
        $_SESSION['error_message'] = "Error deleting feedback: " . $conn->error;
    }
    $delete_stmt->close();
    header("Location: manage_feedback.php");
    exit();
}
if (isset($_SESSION['success_message'])) {
    echo "<script>alert('" . htmlspecialchars($_SESSION['success_message']) . "');</script>";
    unset($_SESSION['success_message']);
}
if (isset($_SESSION['error_message'])) {
    echo "<script>alert('" . htmlspecialchars($_SESSION['error_message']) . "');</script>";
    unset($_SESSION['error_message']);
}
$feedbacks = [];
$feedbacks_query = "SELECT id, name, email, subject, message, rating, created_at FROM feedbacks ORDER BY created_at DESC";
$result = $conn->query($feedbacks_query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $feedbacks[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="admin_style.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #1d2b64, #f8cdda);
            --sidebar-bg: rgba(255, 255, 255, 0.1);
            --card-bg: rgba(255, 255, 255, 0.2);
            --divider-color: rgba(255, 255, 255, 0.3);
            --text-color: #fff;
            --highlight-color: #FFD700;
        }
        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
        }
        .krida-sidebar {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-right: 1px solid rgba(255, 255, 255, 0.18);
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px 0;
        }
        .krida-logo-area {
            padding-bottom: 20px;
        }
        .sidebar-divider {
            border-color: var(--divider-color);
        }
        .krida-nav-menu .nav-link {
            color: rgba(255, 255, 255, 0.8);
            font-weight: 500;
            padding: 12px 20px;
            border-radius: 10px;
            margin: 5px 15px;
            transition: all 0.3s ease;
        }
        .krida-nav-menu .nav-link:hover {
            background: var(--card-bg);
            color: var(--text-color);
            transform: translateX(5px);
        }
        .krida-nav-menu .nav-link.active-link {
            background: rgba(255, 255, 255, 0.3);
            color: var(--text-color);
            box-shadow: 0 4px 15px rgba(255, 255, 255, 0.1);
        }
        .krida-profile-area {
            padding: 15px 20px;
            border-top: 1px solid var(--divider-color);
            margin-top: auto;
        }
        .krida-icon {
            font-size: 1.5rem;
            color: #ffb199;
        }
        .admin-content-wrapper {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            margin: 20px;
            padding: 30px;
            color: var(--text-color);
        }
        .table {
            --bs-table-bg: transparent;
            --bs-table-color: var(--text-color);
            color: var(--text-color);
        }
        .table th {
            border-bottom: 1px solid var(--divider-color);
            color: var(--highlight-color);
        }
        .table tbody tr {
            background-color: rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s ease;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="d-flex w-100 flex-grow-1">
        <div class="col-md-3 col-lg-2 krida-sidebar d-none d-md-block">
            <div class="d-flex flex-column h-100">
                <div class="text-center py-4 krida-logo-area">
                    <h2 class="text-white">
                        <i class="bi bi-trophy-fill me-2 krida-icon"></i> KridaArena
                    </h2>
                </div>
                <hr class="sidebar-divider">
                <ul class="nav flex-column mb-auto krida-nav-menu">
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'admin_dashboard.php') ? 'active-link' : '' ?>" href="admin_dashboard.php">
                            <i class="bi bi-house-door me-2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_users.php') ? 'active-link' : '' ?>" href="manage_users.php">
                            <i class="bi bi-people me-2"></i> Manage Users
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_tournaments.php') ? 'active-link' : '' ?>" href="manage_tournaments.php">
                            <i class="bi bi-trophy me-2"></i> Manage Tournaments
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_products.php') ? 'active-link' : '' ?>" href="manage_products.php">
                            <i class="bi bi-bag-fill me-2"></i> Manage Products
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_orders.php') ? 'active-link' : '' ?>" href="manage_orders.php">
                            <i class="bi bi-truck-flatbed me-2"></i> Manage Orders
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_admins.php') ? 'active-link' : '' ?>" href="manage_admins.php">
                            <i class="bi bi-person-gear me-2"></i> Manage Admins
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_feedback.php') ? 'active-link' : '' ?>" href="manage_feedback.php">
                            <i class="bi bi-chat-left-text me-2"></i> Manage Feedback
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($current_page == 'manage_faqs.php') ? 'active-link' : '' ?>" href="manage_faqs.php">
                            <i class="bi bi-question-circle me-2"></i> Manage FAQs
                        </a>
                    </li>
                </ul>
                <hr class="sidebar-divider">
                <div class="krida-profile-area dropup">
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle me-2 krida-icon"></i> <strong><?= $admin_name ?></strong>
                    </a>
                    <p class="text-white-50 mt-2 mb-0" style="font-size: 0.8rem;">
                        Last Login: <?= ($last_login != 'N/A') ? date('d M Y, h:i A', strtotime($last_login)) : 'N/A' ?>
                    </p>
                    <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                        <li><a class="dropdown-item" href="admin_logout.php"><i class="bi bi-box-arrow-right"></i> Sign out</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="admin-content-wrapper container-fluid py-4 flex-grow-1">
            <h1 class="display-5 fw-bold mb-4 animate__animated animate__fadeInDown"><?= htmlspecialchars($page_title) ?></h1>

            <div class="table-responsive animate__animated animate__fadeInUp">
                <table class="table table-borderless table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Rating</th><th>Message</th>
                            <th>Submitted At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($feedbacks) > 0): ?>
                            <?php foreach ($feedbacks as $feedback): ?>
                                <tr>
                                    <td><?= htmlspecialchars($feedback['id']) ?></td>
                                    <td><?= htmlspecialchars($feedback['name']) ?></td>
                                    <td><?= htmlspecialchars($feedback['email']) ?></td>
                                    <td><?= htmlspecialchars($feedback['subject']) ?></td>
                                    <td>
                                        <?php 
                                            $rating = (int)$feedback['rating'];
                                            for ($i = 0; $i < $rating; $i++): 
                                        ?>
                                            <i class="bi bi-star-fill" style="color: var(--highlight-color);"></i>
                                        <?php endfor; ?>
                                        (<?= htmlspecialchars($rating) ?>/5)
                                    </td>
                                    <td><?= htmlspecialchars($feedback['message']) ?></td>
                                    <td><?= date('M d, Y', strtotime(htmlspecialchars($feedback['created_at']))) ?></td>
                                    <td>
                                        <form method="POST" action="manage_feedback.php" class="d-inline">
                                            <input type="hidden" name="feedback_id" value="<?= htmlspecialchars($feedback['id']) ?>">
                                            <button type="submit" name="delete_feedback" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this feedback?');">
                                                <i class="bi bi-trash"></i> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted">No feedback found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>