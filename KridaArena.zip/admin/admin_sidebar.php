<?php
$sidebar_sections = [
    'admin_dashboard.php' => ['name' => 'Dashboard', 'icon' => 'home'],
    'manage_users.php' => ['name' => 'Manage Users', 'icon' => 'people'],
    'manage_tournaments.php' => ['name' => 'Manage Tournaments', 'icon' => '2trophy'],
    'manage_products.php' => ['name' => 'Manage Products', 'icon' => 'products'],
    'manage_orders.php' => ['name' => 'Manage Orders', 'icon' => 'truck'],
    'manage_admins.php' => ['name' => 'Manage Admins', 'icon' => 'admin'],
    'manage_feedback.php' => ['name' => 'Manage Feedback', 'icon' => 'chat'],
    'manage_faqs.php' => ['name' => 'Manage FAQs', 'icon' => 'question'],
];
?>
<style>
.krida-sidebar {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border-right: 1px solid rgba(255, 255, 255, 0.18);
    box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
    padding: 20px 0;
}
.krida-logo-area {
    padding-bottom: 20px;
}
.sidebar-divider {
    border-color: var(--divider-color);
}
.krida-nav-menu .nav-link {
    color: rgba(255, 255, 255, 0.8);
    font-weight: 500;
    padding: 12px 20px;
    border-radius: 10px;
    margin: 5px 15px;
    transition: all 0.3s ease;
}
.krida-nav-menu .nav-link:hover {
    background: var(--card-bg);
    color: var(--text-color);
    transform: translateX(5px);
}
.krida-nav-menu .nav-link.active-link {
    background: rgba(255, 255, 255, 0.3);
    color: var(--text-color);
    box-shadow: 0 4px 15px rgba(255, 255, 255, 0.1);
}
.krida-profile-area {
    padding: 15px 20px;
    border-top: 1px solid var(--divider-color);
    margin-top: auto;
}
.krida-icon {
    font-size: 1.5rem;
    color: #ffb199;
}
.krida-nav-menu .nav-link img {
    width: <?= isset($icon_size_px) ? $icon_size_px : 24 ?>px;
    height: <?= isset($icon_size_px) ? $icon_size_px : 24 ?>px;
    margin-right: 8px;
    vertical-align: middle;
}

.krida-nav-menu .nav-link img,
.krida-logo-area img,
.krida-profile-area img {
    filter: brightness(0) invert(1);
}
</style>

<div class="col-md-3 col-lg-2 krida-sidebar d-none d-md-block">
    <div class="d-flex flex-column h-100">
        <div class="text-center py-4 krida-logo-area">
            <h2 class="text-white">
                <a href="admin_dashboard.php" class="text-white text-decoration-none">
                    <img src="../png/cup.png" alt="KridaArena" width="40" height="40" class="me-2">
                    KridaArena
                </a>
            </h2>
        </div>
        <hr class="sidebar-divider">
        <ul class="nav flex-column mb-auto krida-nav-menu">
            <?php foreach ($sidebar_sections as $filename => $section): ?>
                <li class="nav-item">
                    <a class="nav-link <?= (isset($current_page) && $current_page == $filename) ? 'active-link' : '' ?>" href="<?= htmlspecialchars($filename) ?>">
                        <img src="../png/<?= htmlspecialchars($section['icon']) ?>.png" alt="<?= htmlspecialchars($section['name']) ?> Icon">
                        <?= htmlspecialchars($section['name']) ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
        <hr class="sidebar-divider">
        <div class="krida-profile-area dropup">
            <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                <img src="../png/profile.png" alt="Profile" width="24" height="24" class="me-2 rounded-circle" style="object-fit: cover;">
                <strong><?= isset($admin_name) ? $admin_name : 'Admin' ?></strong>
            </a>
            <p class="text-white-50 mt-2 mb-0" style="font-size: 0.8rem;">
                Last Login: <?= isset($last_login) ? ( ($last_login != 'N/A') ? date('d M Y, h:i A', strtotime($last_login)) : 'N/A' ) : 'N/A' ?>
            </p>
            <ul class="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                <li><a class="dropdown-item" href="admin_logout.php">
                        <img src="../png/logout.png" alt="Sign out" width="18" height="18" class="me-2" style="filter: invert(1);">
                        Sign out
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
