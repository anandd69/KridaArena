<?php
session_start();
require_once '../config/db.php';
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
$total_users = 0;
$total_tournaments = 0;
$total_products = 0;
$total_orders = 0;

$stmt_users = $conn->prepare("SELECT COUNT(*) AS total_users FROM users");
if ($stmt_users) {
    $stmt_users->execute();
    $result_users = $stmt_users->get_result();
    if ($result_users) {
        $row_users = $result_users->fetch_assoc();
        $total_users = $row_users['total_users'];
    }
    $stmt_users->close();
}

$stmt_tournaments = $conn->prepare("SELECT COUNT(*) AS total_tournaments FROM tournaments");
if ($stmt_tournaments) {
    $stmt_tournaments->execute();
    $result_tournaments = $stmt_tournaments->get_result();
    if ($result_tournaments) {
        $row_tournaments = $result_tournaments->fetch_assoc();
        $total_tournaments = $row_tournaments['total_tournaments'];
    }
    $stmt_tournaments->close();
}

$stmt_products = $conn->prepare("SELECT COUNT(*) AS total_products FROM products");
if ($stmt_products) {
    $stmt_products->execute();
    $result_products = $stmt_products->get_result();
    if ($result_products) {
        $row_products = $result_products->fetch_assoc();
        $total_products = $row_products['total_products'];
    }
    $stmt_products->close();
}

$stmt_orders = $conn->prepare("SELECT COUNT(*) AS total_orders FROM orders");
if ($stmt_orders) {
    $stmt_orders->execute();
    $result_orders = $stmt_orders->get_result();
    if ($result_orders) {
        $row_orders = $result_orders->fetch_assoc();
        $total_orders = $row_orders['total_orders'];
    }
    $stmt_orders->close();
}

$admin_id = $_SESSION['admin_id'] ?? null;
$admin_name = 'Admin';
$last_login = 'N/A';
if ($admin_id !== null) {
    $stmt = $conn->prepare("SELECT name, last_login_at FROM admins WHERE admin_id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();
    $stmt->close();
    $admin_name = isset($admin['name']) ? htmlspecialchars($admin['name']) : 'Admin';
    $last_login = isset($admin['last_login_at']) ? htmlspecialchars($admin['last_login_at']) : 'N/A';
}

$current_page = basename(__FILE__);
$page_title = "Manage Users | KridaArena";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_user'])) {
    $user_id_to_delete = $_POST['user_id'];
    $delete_stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $delete_stmt->bind_param("i", $user_id_to_delete);
    if ($delete_stmt->execute()) {
        $_SESSION['success_message'] = "User deleted successfully!";
    } else {
        $_SESSION['error_message'] = "Error deleting user: " . $conn->error;
    }
    $delete_stmt->close();
    header("Location: manage_users.php");
    exit();
}
$users = [];
$users_query = "SELECT id, name, email, created_at FROM users ORDER BY created_at DESC";
$result = $conn->query($users_query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="admin_style.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #1d2b64, #f8cdda);
            --sidebar-bg: rgba(255, 255, 255, 0.1);
            --card-bg: rgba(255, 255, 255, 0.2);
            --divider-color: rgba(255, 255, 255, 0.3);
            --text-color: #fff;
            --highlight-color: #FFD700;
        }
        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
        }
        .admin-content-wrapper {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            margin: 20px;
            padding: 30px;
            color: var(--text-color);
        }
        .card-stats {
            background: var(--card-bg);
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .card-stats:hover {
            transform: translateY(-5px);
        }
        .icon-box {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            color: var(--text-color);
        }
        .btn-danger img {
            filter: invert(1) grayscale(100%) brightness(200%); 
            width: 16px; 
            height: 16px;
            margin-right: 5px;
            vertical-align: sub;
        }

        .bg-users { background: linear-gradient(45deg, #1d2b64, #1846A6); }
        .bg-tournaments { background: linear-gradient(45deg, #ff0844, #ff5e62); }
        .bg-products { background: linear-gradient(45deg, #6a11cb, #2575fc); }
        .bg-orders { background: linear-gradient(45deg, #20bf55, #01ba76); }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--highlight-color);
        }
        .card-recent {
            background: rgba(0, 0, 0, 0.5); 
            border: none;
            border-radius: 15px;
        }
        .card-recent .card-title,
        .card-recent .card-text {
            color: var(--text-color);
        }
        .table {
            --bs-table-bg: transparent;
            --bs-table-color: var(--text-color);
            color: var(--text-color);
        }
        .table th {
            border-bottom: 1px solid var(--divider-color);
            color: var(--highlight-color);
        }
        .table tbody tr {
            background-color: rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s ease;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="d-flex w-100 flex-grow-1">
        <?php 
        require_once '../admin/admin_sidebar.php';
        ?>
        <div class="admin-content-wrapper container-fluid py-4 flex-grow-1">
            <h1 class="display-5 fw-bold mb-4 animate__animated animate__fadeInDown"><?= htmlspecialchars($page_title) ?></h1>

            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success alert-dismissible fade show animate__animated animate__fadeIn mb-4" role="alert">
                    <?= htmlspecialchars($_SESSION['success_message']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger alert-dismissible fade show animate__animated animate__fadeIn mb-4" role="alert">
                    <?= htmlspecialchars($_SESSION['error_message']) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php unset($_SESSION['error_message']); ?>
            <?php endif; ?>

            <div class="card card-recent animate__animated animate__fadeInUp">
                <div class="card-body">
                    <h5 class="card-title fw-bold">All Users (<?= $total_users ?>)</h5>
                    <p class="card-text">List of all registered users on the platform.</p>
                    <div class="table-responsive">
                        <table class="table table-borderless table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Registered On</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($users)): ?>
                                    <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?= htmlspecialchars($user['id']) ?></td>
                                    <td><?= htmlspecialchars($user['name']) ?></td>
                                    <td><?= htmlspecialchars($user['email']) ?></td>
                                    <td><?= date('M d, Y', strtotime(htmlspecialchars($user['created_at']))) ?></td>
                                    <td>
                                        <form method="POST" action="manage_users.php" class="d-inline">
                                            <input type="hidden" name="user_id" value="<?= htmlspecialchars($user['id']) ?>">
                                            <button type="submit" name="delete_user" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user? This action cannot be undone.');">
                                                <img src="../png/trash.png" alt="Delete Icon"> Delete
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">No users found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>