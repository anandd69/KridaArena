<?php
session_start();
require_once '../config/db.php'; 
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

$page_title = "Manage Products | Admin Panel";
$msg = '';
$target_dir = "../images/";

$total_users = 0;
$total_tournaments = 0;
$total_products = 0;
$total_orders = 0;
$admin_id = $_SESSION['admin_id'] ?? null;
$admin_name = 'Admin';
$last_login = 'N/A';
if ($admin_id !== null) {
    $stmt = $conn->prepare("SELECT name, last_login_at FROM admins WHERE admin_id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();
    $stmt->close();
    $admin_name = isset($admin['name']) ? htmlspecialchars($admin['name']) : 'Admin';
    $last_login = isset($admin['last_login_at']) ? htmlspecialchars($admin['last_login_at']) : 'N/A';
}

$current_page = basename(__FILE__);
$sidebar_sections = [
    'admin_dashboard.php' => ['name' => 'Dashboard', 'icon' => 'bi-house-door'],
    'manage_users.php' => ['name' => 'Manage Users', 'icon' => 'bi-people'],
    'manage_tournaments.php' => ['name' => 'Manage Tournaments', 'icon' => 'bi-trophy'],
    'manage_products.php' => ['name' => 'Manage Products', 'icon' => 'bi-bag-fill'],
    'manage_orders.php' => ['name' => 'Manage Orders', 'icon' => 'bi-truck-flatbed'],
    'manage_admins.php' => ['name' => 'Manage Admins', 'icon' => 'bi-person-gear'],
    'manage_feedback.php' => ['name' => 'Manage Feedback', 'icon' => 'bi-chat-left-text'],
    'manage_faqs.php' => ['name' => 'Manage FAQs', 'icon' => 'bi-question-circle'],
];
function uploadImage($file, $target_dir, $old_image = null) {
    if (empty($file) || $file['name'] == '') {
        return $old_image;
    }
    $file_name = basename($file["name"]);
    $unique_filename = uniqid('prod_', true) . '_' . $file_name;
    $target_file = $target_dir . $unique_filename;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    $check = getimagesize($file["tmp_name"]);
    if($check === false) {
        return "File is not an image.";
    }
    if ($file["size"] > 5000000) {
        return "Sorry, your file is too large (max 5MB).";
    }
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        return "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    }
    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        if ($old_image && $old_image !== $unique_filename && file_exists($target_dir . $old_image)) {
            unlink($target_dir . $old_image);
        }
        return $unique_filename;
    } else {
        return "Sorry, there was an error uploading your file.";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && (isset($_POST['add_product']) || isset($_POST['edit_product']))) {
    $is_edit = isset($_POST['edit_product']);
    $product_id = $is_edit ? intval($_POST['product_id']) : 0;
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    $current_image = $is_edit ? trim($_POST['current_image']) : null;
    $image_result = uploadImage($_FILES['image'], $target_dir, $current_image);
    if (strpos($image_result, 'Sorry') === 0 || strpos($image_result, 'File') === 0) {
        $msg = "<div class='alert alert-danger'>Image Error: " . htmlspecialchars($image_result) . "</div>";
    } else {
        $final_image_filename = $image_result;

        if ($is_edit) {
            $query = "UPDATE products SET name = ?, description = ?, price = ?, stock = ?, image = ? WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssdiss", $name, $description, $price, $stock, $final_image_filename, $product_id);
            if ($stmt->execute()) {
                $msg = "<div class='alert alert-success'>Product updated successfully!</div>";
            } else {
                $msg = "<div class='alert alert-danger'>Error updating product: " . $conn->error . "</div>";
            }
            $stmt->close();
        } else {
            $query = "INSERT INTO products (name, description, price, stock, image) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("ssdis", $name, $description, $price, $stock, $final_image_filename);
            if ($stmt->execute()) {
                $msg = "<div class='alert alert-success'>Product added successfully!</div>";
            } else {
                $msg = "<div class='alert alert-danger'>Error adding product: " . $conn->error . "</div>";
            }
            $stmt->close();
        }
    }
}

if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    if ($delete_id > 0) {
        $image_query = "SELECT image FROM products WHERE id = ?";
        $stmt_img = $conn->prepare($image_query);
        $stmt_img->bind_param("i", $delete_id);
        $stmt_img->execute();
        $result_img = $stmt_img->get_result();
        $product = $result_img->fetch_assoc();
        $stmt_img->close();

        $delete_query = "DELETE FROM products WHERE id = ?";
        $stmt = $conn->prepare($delete_query);
        $stmt->bind_param("i", $delete_id);
        if ($stmt->execute()) {
            if ($product && $product['image'] && file_exists($target_dir . $product['image'])) {
                unlink($target_dir . $product['image']);
            }
            $msg = "<div class='alert alert-success'>Product deleted successfully.</div>";
        } else {
            $msg = "<div class='alert alert-danger'>Error deleting product: " . $conn->error . "</div>";
        }
        $stmt->close();
        header("Location: manage_products.php?msg=" . urlencode(strip_tags($msg)));
        exit();
    }
}

if (isset($_GET['msg'])) {
    $msg = urldecode($_GET['msg']);
}
$products = [];
$products_query = "SELECT * FROM products ORDER BY id DESC";
$result = $conn->query($products_query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="admin_style.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #1d2b64, #f8cdda);
            --sidebar-bg: rgba(255, 255, 255, 0.1);
            --card-bg: rgba(255, 255, 255, 0.2);
            --divider-color: rgba(255, 255, 255, 0.3);
            --text-color: #fff;
            --highlight-color: #FFD700;
        }
        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
        }
        .admin-content-wrapper {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            margin: 20px;
            padding: 30px;
            color: var(--text-color);
        }
        .card-stats {
            background: var(--card-bg);
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .card-stats:hover {
            transform: translateY(-5px);
        }
        .icon-box {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            color: var(--text-color);
        }
        .btn-warning img,
        .btn-danger img {
            width: 16px; 
            height: 16px;
            margin-right: 5px; 
            vertical-align: sub;
        }

        .bg-users { background: linear-gradient(45deg, #1d2b64, #1846A6); }
        .bg-tournaments { background: linear-gradient(45deg, #ff0844, #ff5e62); }
        .bg-products { background: linear-gradient(45deg, #6a11cb, #2575fc); }
        .bg-orders { background: linear-gradient(45deg, #20bf55, #01ba76); }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--highlight-color);
        }
        .card-recent {
            background: rgba(0, 0, 0, 0.5); 
            border: none;
            border-radius: 15px;
        }
        .card-recent .card-title,
        .card-recent .card-text {
            color: var(--text-color);
        }
        .table {
            --bs-table-bg: transparent;
            --bs-table-color: var(--text-color);
            color: var(--text-color);
        }
        .table th {
            border-bottom: 1px solid var(--divider-color);
            color: var(--highlight-color);
        }
        .table tbody tr {
            background-color: rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s ease;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        .product-image {
            width: 50px; 
            height: 50px; 
            object-fit: cover; 
            border-radius: 8px;
        }
        .modal-content {
            background-color: var(--card-bg);
            border-radius: 15px;
            border: none;
            backdrop-filter: blur(10px);
        }
        .modal-header, .modal-footer {
            border-color: var(--divider-color);
        }
        .form-label {
            color: var(--highlight-color);
        }
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid var(--divider-color);
            color: var(--text-color);
        }
        .form-control:focus {
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 0 0 0.25rem rgba(255, 255, 255, 0.25);
            color: var(--text-color);
        }
        .icon-white {
            filter: brightness(0) invert(1);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="d-flex w-100 flex-grow-1">
        <?php 
        require_once '../admin/admin_sidebar.php';
        ?>
        <div class="admin-content-wrapper container-fluid py-4 flex-grow-1">
            <h1 class="display-5 fw-bold mb-4 animate__animated animate__fadeInDown"><?= htmlspecialchars($page_title) ?></h1>

            <?= $msg ?>
            
            <div class="d-flex justify-content-end mb-4 animate__animated animate__fadeIn">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#productModal" id="addProductBtn">
                    <img src="../png/mark.png" alt="Add Product Icon" class="me-2 icon-white" style="width: 16px; height: 16px;"> Add New Product
                </button>
            </div>

            <div class="table-responsive animate__animated animate__fadeInUp">
                <table class="table table-borderless table-hover">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($products) > 0): ?>
                            <?php foreach ($products as $product): ?>
                                <tr>
                                    <td>
                                        <img src="<?= htmlspecialchars($target_dir . $product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="product-image">
                                    </td>
                                    <td><?= htmlspecialchars($product['id']) ?></td>
                                    <td><?= htmlspecialchars($product['name']) ?></td>
                                    <td>Rs. <?= number_format(htmlspecialchars($product['price']), 2) ?></td>
                                    <td><?= htmlspecialchars($product['stock']) ?></td>
                                    <td>
                                        <button type="button" class="btn btn-warning btn-sm edit-btn" 
                                                data-bs-toggle="modal" data-bs-target="#productModal"
                                                data-id="<?= htmlspecialchars($product['id']) ?>"
                                                data-name="<?= htmlspecialchars($product['name']) ?>"
                                                data-description="<?= htmlspecialchars($product['description']) ?>"
                                                data-price="<?= htmlspecialchars($product['price']) ?>"
                                                data-stock="<?= htmlspecialchars($product['stock']) ?>"
                                                data-image="<?= htmlspecialchars($product['image']) ?>">
                                            <img src="../png/2reg.png" alt="Edit Icon"> Edit
                                        </button>
                                        <a href="manage_products.php?delete_id=<?= htmlspecialchars($product['id']) ?>" class="btn btn-danger btn-sm" 
                                            onclick="return confirm('Are you sure you want to delete this product? This action cannot be undone.');">
                                            <img src="../png/trash.png" alt="Delete Icon"> Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted">No products found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" id="productModal" tabindex="-1" aria-labelledby="productModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="productModalLabel">Add New Product</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="manage_products.php" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="product_id" id="productId">
                        <input type="hidden" name="current_image" id="currentImage">
                        <div class="mb-3">
                            <label for="name" class="form-label">Product Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="price" class="form-label">Price (Rs.)</label>
                                <input type="number" class="form-control" id="price" name="price" step="0.01" required min="0">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="stock" class="form-label">Stock Quantity</label>
                                <input type="number" class="form-control" id="stock" name="stock" required min="0">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="image" class="form-label">Product Image</label>
                            <input class="form-control" type="file" id="imageInput" name="image" accept="image/*" required>
                            <div id="imageInfo" class="form-text text-muted mt-2"></div>
                            <div id="imagePreviewDiv" class="mt-2" style="display:none;">
                                <img id="previewImg" src="" alt="Image Preview" class="product-image" style="width: 100px; height: 100px;">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" name="add_product" id="submitBtn">Add Product</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const modalLabel = document.getElementById('productModalLabel');
            const productIdField = document.getElementById('productId');
            const currentImageField = document.getElementById('currentImage');
            const nameField = document.getElementById('name');
            const descriptionField = document.getElementById('description');
            const priceField = document.getElementById('price');
            const stockField = document.getElementById('stock');
            const imageInput = document.getElementById('imageInput');
            const imageInfo = document.getElementById('imageInfo');
            const imagePreviewDiv = document.getElementById('imagePreviewDiv');
            const previewImg = document.getElementById('previewImg');
            const submitBtn = document.getElementById('submitBtn');
            const form = document.querySelector('#productModal form');

            document.getElementById('addProductBtn').addEventListener('click', function() {
                modalLabel.textContent = 'Add New Product';
                form.reset();
                productIdField.value = '';
                currentImageField.value = '';
                submitBtn.name = 'add_product';
                submitBtn.textContent = 'Add Product';
                imageInput.required = true;
                imageInfo.textContent = '';
                imagePreviewDiv.style.display = 'none';
            });

            document.querySelectorAll('.edit-btn').forEach(button => {
                button.addEventListener('click', function() {
                    modalLabel.textContent = 'Edit Product';
                    
                    const id = this.getAttribute('data-id');
                    const name = this.getAttribute('data-name');
                    const desc = this.getAttribute('data-description');
                    const price = this.getAttribute('data-price');
                    const stock = this.getAttribute('data-stock');
                    const image = this.getAttribute('data-image');

                    productIdField.value = id;
                    currentImageField.value = image;
                    nameField.value = name;
                    descriptionField.value = desc;
                    priceField.value = price;
                    stockField.value = stock;
                    submitBtn.name = 'edit_product';
                    submitBtn.textContent = 'Save Changes';

                    imageInfo.textContent = 'Upload a new image. Leaving this blank will keep the current image.';
                    imageInput.required = false; 
                    imageInput.value = '';

                    previewImg.src = image ? '../images/' + image : ''; 
                    imagePreviewDiv.style.display = image ? 'block' : 'none';
                });
            });

            imageInput.addEventListener('change', function(event) {
                const [file] = event.target.files;
                if (file) {
                    previewImg.src = URL.createObjectURL(file);
                    imagePreviewDiv.style.display = 'block';
                }
            });
        });
    </script>
</body>
</html>