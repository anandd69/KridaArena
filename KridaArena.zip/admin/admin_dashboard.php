<?php
session_start();
require_once '../config/db.php'; 
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
$icon_size_px = 24;
$total_users = 0;
$total_tournaments = 0;
$total_products = 0;
$total_orders = 0;
$stmt_users = $conn->prepare("SELECT COUNT(*) AS total_users FROM users");
if ($stmt_users) {
    $stmt_users->execute();
    $result_users = $stmt_users->get_result();
    if ($result_users) {
        $row_users = $result_users->fetch_assoc();
        $total_users = $row_users['total_users'];
    }
    $stmt_users->close();
}
$stmt_tournaments = $conn->prepare("SELECT COUNT(*) AS total_tournaments FROM tournaments");
if ($stmt_tournaments) {
    $stmt_tournaments->execute();
    $result_tournaments = $stmt_tournaments->get_result();
    if ($result_tournaments) {
        $row_tournaments = $result_tournaments->fetch_assoc();
        $total_tournaments = $row_tournaments['total_tournaments'];
    }
    $stmt_tournaments->close();
}
$stmt_products = $conn->prepare("SELECT COUNT(*) AS total_products FROM products");
if ($stmt_products) {
    $stmt_products->execute();
    $result_products = $stmt_products->get_result();
    if ($result_products) {
        $row_products = $result_products->fetch_assoc();
        $total_products = $row_products['total_products'];
    }
    $stmt_products->close();
}
$stmt_orders = $conn->prepare("SELECT COUNT(*) AS total_orders FROM orders");
if ($stmt_orders) {
    $stmt_orders->execute();
    $result_orders = $stmt_orders->get_result();
    if ($result_orders) {
        $row_orders = $result_orders->fetch_assoc();
        $total_orders = $row_orders['total_orders'];
    }
    $stmt_orders->close();
}
$admin_id = $_SESSION['admin_id'] ?? null;
$admin_name = 'Admin';
$last_login = 'N/A';
if ($admin_id !== null) {
    $stmt = $conn->prepare("SELECT name, last_login_at FROM admins WHERE admin_id = ?");
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();
    $stmt->close();
    $admin_name = isset($admin['name']) ? htmlspecialchars($admin['name']) : 'Admin';
    $last_login = isset($admin['last_login_at']) ? htmlspecialchars($admin['last_login_at']) : 'N/A';
}
$current_page = basename(__FILE__);
$page_title = "Admin Dashboard | KridaArena";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #1d2b64, #f8cdda);
            --sidebar-bg: rgba(255, 255, 255, 0.1);
            --card-bg: rgba(255, 255, 255, 0.2);
            --divider-color: rgba(255, 255, 255, 0.3);
            --text-color: #fff;
            --highlight-color: #FFD700;
        }
        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
        }
        .admin-content-wrapper {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            margin: 20px;
            padding: 30px;
            color: var(--text-color);
        }
        .card-stats {
            background: var(--card-bg);
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .card-stats:hover {
            transform: translateY(-5px);
        }
        .icon-box {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            color: var(--text-color);
        }
        .icon-box img {
            filter: invert(1) grayscale(100%) brightness(200%);
            width: 40px; 
            height: 40px;
        }
        .bg-users { background: linear-gradient(45deg, #1d2b64, #1846A6); }
        .bg-tournaments { background: linear-gradient(45deg, #ff0844, #ff5e62); }
        .bg-products { background: linear-gradient(45deg, #6a11cb, #2575fc); }
        .bg-orders { background: linear-gradient(45deg, #20bf55, #01ba76); }
        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--highlight-color);
        }
        .card-recent {
            background: rgba(0, 0, 0, 0.5);
            border: none;
            border-radius: 15px;
        }
        .card-recent .card-title,
        .card-recent .card-text {
            color: var(--text-color);
        }
        .table {
            --bs-table-bg: transparent;
            --bs-table-color: var(--text-color);
            color: var(--text-color);
        }
        .table th {
            border-bottom: 1px solid var(--divider-color);
            color: var(--highlight-color);
        }
        .table tbody tr {
            background-color: rgba(255, 255, 255, 0.05);
            transition: background-color 0.3s ease;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="d-flex w-100 flex-grow-1">
        <?php 
        require_once '../admin/admin_sidebar.php';
        ?>
        <div class="admin-content-wrapper container-fluid py-4 flex-grow-1">
            <h1 class="display-5 fw-bold mb-4 animate__animated animate__fadeInDown"><?= htmlspecialchars($page_title) ?></h1>
            <div class="row g-4">
                <div class="col-md-3">
                    <div class="card card-stats h-100 animate__animated animate__fadeInUp">
                        <a href="manage_users.php" style="text-decoration: none; color: inherit;">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="icon-box bg-users">
                                        <img src="../png/group.png" alt="Users Icon" style="filter: invert(1) grayscale(100%) brightness(200%); width: 40px; height: 40px;">
                                    </div>
                                    <div class="text-end">
                                        <h5 class="text-muted fw-normal mb-2">Total Users</h5>
                                        <h3 class="stat-number mb-0"><?= $total_users ?></h3>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card card-stats h-100 animate__animated animate__fadeInUp animate__delay-1s">
                        <a href="manage_tournaments.php" style="text-decoration: none; color: inherit;">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="icon-box bg-tournaments">
                                        <img src="../png/3trophy.png" alt="Tournaments Icon" style="filter: invert(1) grayscale(100%) brightness(200%); width: 40px; height: 40px;">
                                    </div>
                                    <div class="text-end">
                                        <h5 class="text-muted fw-normal mb-2">Total Tournaments</h5>
                                        <h3 class="stat-number mb-0"><?= $total_tournaments ?></h3>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card card-stats h-100 animate__animated animate__fadeInUp animate__delay-2s">
                        <a href="manage_products.php" style="text-decoration: none; color: inherit;">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="icon-box bg-products">
                                        <img src="../png/products.png" alt="Products Icon" style="filter: invert(1) grayscale(100%) brightness(200%); width: 40px; height: 40px;">
                                    </div>
                                    <div class="text-end">
                                        <h5 class="text-muted fw-normal mb-2">Total Products</h5>
                                        <h3 class="stat-number mb-0"><?= $total_products ?></h3>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card card-stats h-100 animate__animated animate__fadeInUp animate__delay-3s">
                        <a href="manage_orders.php" style="text-decoration: none; color: inherit;">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="icon-box bg-orders">
                                        <img src="../png/myorders.png" alt="Orders Icon" style="filter: invert(1) grayscale(100%) brightness(200%); width: 45px; height: 45px;">
                                    </div>
                                    <div class="text-end">
                                        <h5 class="text-muted fw-normal mb-2">Total Orders</h5>
                                        <h3 class="stat-number mb-0"><?= $total_orders ?></h3>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <div class="mt-5">
                <div class="row g-4">
                    <div class="col-md-6">
                        <div class="card card-recent animate__animated animate__fadeInLeft">
                            <div class="card-body">
                                <h5 class="card-title fw-bold">Recent Registrations</h5>
                                <p class="card-text">Latest tournament sign-ups.</p>
                                <div class="table-responsive">
                                    <table class="table table-borderless table-hover">
                                        <thead>
                                            <tr>
                                                <th>Team Name</th>
                                                <th>Sport</th>
                                                <th>Registered On</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $recent_regs_query = "SELECT r.team_name, r.sport_type, r.registration_date FROM registrations r ORDER BY r.registration_date DESC LIMIT 5";
                                            $recent_regs_stmt = $conn->prepare($recent_regs_query);
                                            $recent_regs_stmt->execute();
                                            $recent_regs_result = $recent_regs_stmt->get_result();
                                            if ($recent_regs_result->num_rows > 0) {
                                                while ($row = $recent_regs_result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . htmlspecialchars($row['team_name']) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['sport_type']) . "</td>";
                                                    echo "<td>" . date('M d, Y', strtotime($row['registration_date'])) . "</td>";
                                                    echo "</tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='3' class='text-center text-muted'>No recent registrations.</td></tr>";
                                            }
                                            $recent_regs_stmt->close();
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card card-recent animate__animated animate__fadeInRight">
                            <div class="card-body">
                                <h5 class="card-title fw-bold">Recent Orders</h5>
                                <p class="card-text">Latest product purchases.</p>
                                <div class="table-responsive">
                                    <table class="table table-borderless table-hover">
                                        <thead>
                                            <tr>
                                                <th>Order ID</th>
                                                <th>Total Amount</th>
                                                <th>Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $recent_orders_query = "SELECT order_id, total_amount, status FROM orders ORDER BY created_at DESC LIMIT 5";
                                            $recent_orders_stmt = $conn->prepare($recent_orders_query);
                                            $recent_orders_stmt->execute();
                                            $recent_orders_result = $recent_orders_stmt->get_result();
                                            if ($recent_orders_result->num_rows > 0) {
                                                while ($row = $recent_orders_result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . htmlspecialchars($row['order_id']) . "</td>";
                                                    echo "<td>Rs. " . number_format($row['total_amount'], 2) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                                                    echo "</tr>";
                                                }
                                            } else {
                                                echo "<tr><td colspan='3' class='text-center text-muted'>No recent orders.</td></tr>";
                                            }
                                            $recent_orders_stmt->close();
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>