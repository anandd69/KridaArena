<?php
session_start();
require_once '../config/db.php'; 
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
$page_title = "Add Product | Admin Panel";
$msg = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name        = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price       = floatval($_POST['price']);
    $image_name  = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "../images/";
        $image_name = basename($_FILES["image"]["name"]);
        $target_file = $target_dir . $image_name;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check === false) {
            $msg = "<div class='alert alert-danger'>File is not an image.</div>";
        } elseif ($_FILES["image"]["size"] > 500000) { // 500 KB limit
            $msg = "<div class='alert alert-danger'>Sorry, your file is too large.</div>";
        } elseif ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
            $msg = "<div class='alert alert-danger'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</div>";
        } elseif (file_exists($target_file)) {
            $msg = "<div class='alert alert-warning'>Sorry, file with this name already exists.</div>";
        } else {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                $stmt = $conn->prepare("INSERT INTO products (name, description, price, image) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssds", $name, $description, $price, $image_name);

                if ($stmt->execute()) {
                    $msg = "<div class='alert alert-success'>Product added successfully!</div>";
                    $name = $description = $price = $image_name = '';
                } else {
                    $msg = "<div class='alert alert-danger'>Error: " . $stmt->error . "</div>";
                }
                $stmt->close();
            } else {
                $msg = "<div class='alert alert-danger'>Sorry, there was an error uploading your file.</div>";
            }
        }
    } else {
        $msg = "<div class='alert alert-danger'>Please select an image file to upload.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f0f0f5, #e0e0e5);
            min-height: 100vh;
            display: flex;
        }
        .admin-sidebar {
            background-color: #2c3e50;
            color: #ecf0f1;
            padding: 20px;
            min-height: 100vh;
        }
        .admin-sidebar a {
            color: #ecf0f1;
            text-decoration: none;
            display: block;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 10px;
            transition: background-color 0.3s ease;
        }
        .admin-sidebar a:hover {
            background-color: #34495e;
        }
        .admin-content {
            flex-grow: 1;
            padding: 20px;
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <div class="admin-sidebar d-flex flex-column p-3 text-white" style="width: 280px;">
            <a href="admin_dashboard.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                <i class="bi bi-speedometer2 me-2"></i>
                <span class="fs-4">Admin Dashboard</span>
            </a>
            <hr>
            <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                    <a href="admin_dashboard.php" class="nav-link text-white" aria-current="page">
                        <i class="bi bi-house-door-fill me-2"></i>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="manage_users.php" class="nav-link text-white">
                        <i class="bi bi-people-fill me-2"></i>
                        Users
                    </a>
                </li>
                <li>
                    <a href="manage_tournaments.php" class="nav-link text-white">
                        <i class="bi bi-trophy-fill me-2"></i>
                        Tournaments
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle active" href="#" id="productsDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-bag-fill me-2"></i>
                        Products
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="productsDropdown">
                        <li><a class="dropdown-item" href="manage_products.php">Manage Products</a></li>
                        <li><a class="dropdown-item active" href="add_product.php">Add New Product</a></li>
                    </ul>
                </li>
            </ul>
            <hr>
            <a href="admin_logout.php" class="d-flex align-items-center text-white text-decoration-none">
                <i class="bi bi-box-arrow-right me-2"></i>
                <span class="ms-auto">Logout</span>
            </a>
        </div>

        <div class="container-fluid py-4 flex-grow-1">
            <h1 class="display-5 fw-bold mb-4">Add New Product</h1>
            <?php if (isset($msg)): ?>
                <?= $msg ?>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="name" class="form-label">Product Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Price (in ₹)</label>
                    <input type="number" class="form-control" id="price" name="price" step="0.01" required>
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Product Image</label>
                    <input type="file" class="form-control" id="image" name="image" required>
                    <div class="form-text">Allowed formats: JPG, JPEG, PNG, GIF. Max size: 500 KB.</div>
                </div>
                <button type="submit" class="btn btn-primary">Add Product</button>
                <a href="manage_products.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>

</body>
</html>