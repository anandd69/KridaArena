<?php
session_start();
require_once '../config/db.php'; 
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
$page_title = "Add Product | Admin Panel";
$msg = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name        = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price       = floatval($_POST['price']);
    $stock       = intval($_POST['stock']); 
    $image_name  = '';

    if (empty($name) || empty($description) || $price <= 0 || $stock < 0) {
        $msg = "<div class='alert alert-danger'>Please fill all fields correctly. Price must be greater than zero, and stock cannot be negative.</div>";
    } elseif (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target_dir = "../images/";
        $unique_filename = uniqid('prod_', true) . '_' . basename($_FILES["image"]["name"]);
        $target_file = $target_dir . $unique_filename;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check === false) {
            $msg = "<div class='alert alert-danger'>File is not an image.</div>";
        } elseif ($_FILES["image"]["size"] > 500000) {
            $msg = "<div class='alert alert-danger'>Sorry, your file is too large (max 500KB).</div>";
        } elseif ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
            $msg = "<div class='alert alert-danger'>Sorry, only JPG, JPEG, PNG & GIF files are allowed.</div>";
        } else {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                $image_name = $unique_filename; 
            } else {
                $msg = "<div class='alert alert-danger'>Sorry, there was an error uploading your file.</div>";
            }
        }
    } else {
        $msg = "<div class='alert alert-danger'>Please upload a product image.</div>";
    }

    if (empty($msg)) {
        $query = "INSERT INTO products (name, description, price, image, stock) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssdsi", $name, $description, $price, $image_name, $stock);
        
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Product added successfully!";
            header("Location: manage_products.php");
            exit();
        } else {
            $msg = "<div class='alert alert-danger'>Error adding product: " . $conn->error . "</div>";
        }
        $stmt->close();
    }
}

$current_page = basename(__FILE__);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="../css_admin/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css_admin/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css_admin/animate.min.css">
    <script src="../js_admin/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="admin_style.css">
    <style>
        :root {
            --primary-gradient: linear-gradient(135deg, #1d2b64, #f8cdda);
            --sidebar-bg: rgba(255, 255, 255, 0.1);
            --card-bg: rgba(255, 255, 255, 0.2);
            --divider-color: rgba(255, 255, 255, 0.3);
            --text-color: #fff;
            --highlight-color: #FFD700;
        }
        body {
            background: var(--primary-gradient);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            color: var(--text-color);
        }
        .admin-content-wrapper {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 20px;
            margin: 20px;
            padding: 30px;
            color: var(--text-color);
            max-width: 800px;
        }
        .form-label {
            color: var(--highlight-color);
        }
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid var(--divider-color);
            color: var(--text-color);
        }
        .form-control:focus {
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 0 0 0.25rem rgba(255, 255, 255, 0.25);
            color: var(--text-color);
        }
        .form-text {
            color: rgba(255, 255, 255, 0.7) !important;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="d-flex w-100 flex-grow-1">
        <?php 
        require_once '../admin/admin_sidebar.php';
        ?>
        <div class="admin-content-wrapper container-fluid py-4 flex-grow-1">
            <h1 class="display-5 fw-bold mb-4 animate__animated animate__fadeInDown"><?= htmlspecialchars($page_title) ?></h1>
            
            <?php if (isset($msg)): ?>
                <?= $msg ?>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="name" class="form-label">Product Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                </div>
                <div class="mb-3">
                    <label for="price" class="form-label">Price (in ₹)</label>
                    <input type="number" class="form-control" id="price" name="price" step="0.01" required>
                </div>
                <div class="mb-3">
                    <label for="stock" class="form-label">Stock Quantity</label>
                    <input type="number" class="form-control" id="stock" name="stock" required min="0">
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Product Image</label>
                    <input type="file" class="form-control" id="image" name="image" required>
                    <div class="form-text">Allowed formats: JPG, JPEG, PNG, GIF. Max size: 500 KB.</div>
                </div>
                <button type="submit" class="btn btn-primary">Add Product</button>
                <a href="manage_products.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>