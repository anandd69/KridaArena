<?php
session_start();
include 'config/db.php';

$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $gender   = trim($_POST['gender']);
    $state    = trim($_POST['state']);
    $city     = trim($_POST['city']);
    $sports   = isset($_POST['sports']) ? implode(", ", $_POST['sports']) : "";
    $created  = date("Y-m-d H:i:s");

    $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check_stmt->bind_param("s", $email);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        $msg = "<div class='alert alert-danger'>This email is already registered!</div>";
    } else {
        $insert_stmt = $conn->prepare("INSERT INTO users (name, email, password, gender, state, city, sports_interest, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $insert_stmt->bind_param("ssssssss", $name, $email, $password, $gender, $state, $city, $sports, $created);

        if ($insert_stmt->execute()) {
            $_SESSION['registration_success'] = true;
            header("Location: register.php");
            exit();
        } else {
            $msg = "<div class='alert alert-danger'>Error: " . $insert_stmt->error . "</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register | KridaArena</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            background: linear-gradient(120deg, #ec7c20ff, #f848d2ff); 
            min-height: 100vh; 
            display: flex; 
            flex-direction: column; 
            justify-content: center;
        }
        .register-box {
            background: #fff;
            padding: 35px;
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(248,72,210,0.5), 0 0 40px rgba(236,124,32,0.4);
        }
        .gender-radio-buttons .btn-check + .btn {
            border-radius: 12px;
            padding: 10px 20px;
            border: 2px solid #ccc;
            color: #666;
            background-color: #f9f9f9;
            transition: all 0.2s ease-in-out;
        }
        .gender-radio-buttons .btn-check:checked + .btn {
            background: linear-gradient(45deg, #ec7c20ff, #f848d2ff);
            color: white;
            border-color: #f848d2ff;
            box-shadow: 0 4px 10px rgba(248,72,210,0.3);
            transform: translateY(-2px);
        }
        .gender-radio-buttons .btn-check:focus + .btn {
            box-shadow: 0 0 0 0.25rem rgba(248,72,210,0.25);
        }
    </style>
</head>
<body class="d-flex flex-column justify-content-center">
    <div class="container my-5">
        <div class="register-box mx-auto" style="max-width: 700px;">
            <h2 class="text-center mb-4">
                <span>Welcome!</span> Create Your KridaArena Account
            </h2>
            <?= $msg ?>
            <form method="POST" autocomplete="off">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="name" class="form-control" placeholder="Enter your name" required />
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Email Address</label>
                        <input type="email" name="email" class="form-control" placeholder="you@example.com" required />
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" placeholder="Create password" required />
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Gender</label><br>
                        <div class="gender-radio-buttons d-flex gap-2">
                            <input type="radio" class="btn-check" name="gender" id="male-radio" value="Male" required>
                            <label class="btn btn-outline-primary" for="male-radio">Male</label>
                            <input type="radio" class="btn-check" name="gender" id="female-radio" value="Female">
                            <label class="btn btn-outline-primary" for="female-radio">Female</label>
                            <input type="radio" class="btn-check" name="gender" id="other-radio" value="Other">
                            <label class="btn btn-outline-primary" for="other-radio">Other</label>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label class="form-label">State</label>
                        <select id="stateDropdown" name="state" class="form-select" required>
                            <option value="">Select State</option>
                            <option value="Gujarat">Gujarat</option>
                            <option value="Rajasthan">Rajasthan</option>
                            <option value="Maharashtra">Maharashtra</option>
                            <option value="Uttar Pradesh">Uttar Pradesh</option>
                            <option value="Madhya Pradesh">Madhya Pradesh</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">City</label>
                        <select id="cityDropdown" name="city" class="form-select" required>
                            <option value="">Select City</option>
                        </select>
                    </div>
                </div>
                <button class="btn btn-animate w-100 mt-3" type="submit">Register Now</button>
                <div class="text-center mt-3">
                    Already have an account? <a href="login.php" class="login-link">Login here</a>
                </div>
            </form>
        </div>
    </div>
    
    <?php include("includes/footer.php"); ?>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/sweetalert2@11.js"></script>
    
    <script>
        const stateToCities = {
            Gujarat: ["Ahmedabad", "Rajkot", "Jamnagar", "Surat", "Junagadh"],
            Rajasthan: ["Jaipur", "Jodhpur", "Kota", "Ajmer", "Udaipur"],
            Maharashtra: ["Mumbai", "Pune", "Nagpur", "Nashik", "Aurangabad"],
            "Uttar Pradesh": ["Lucknow", "Kanpur", "Varanasi", "Agra", "Prayagraj"],
            "Madhya Pradesh": ["Bhopal", "Indore", "Jabalpur", "Gwalior", "Ujjain"]
        };
        const stateDropdown = document.getElementById("stateDropdown");
        const cityDropdown = document.getElementById("cityDropdown");
        stateDropdown.addEventListener("change", function () {
            const selectedState = this.value;
            const cities = stateToCities[selectedState] || [];
            cityDropdown.innerHTML = '<option value="">Select City</option>';
            cities.forEach(city => {
                const opt = document.createElement("option");
                opt.value = city;
                opt.textContent = city;
                cityDropdown.appendChild(opt);
            });
        });

        <?php if (isset($_SESSION['registration_success'])): ?>
            Swal.fire({
                title: 'Registration Successful!',
                text: 'Your registration was successful. You can now login.',
                icon: 'success',
                confirmButtonText: 'Login Here',
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'login.php';
                }
            });
            <?php unset($_SESSION['registration_success']); ?>
        <?php endif; ?>
    </script>
</body>
</html>