<?php
session_start();
require_once 'config/db.php';
$page_title = "Feedback | KridaArena";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>    
    <style>
        .section-title {
            position: relative;
            padding-bottom: 15px;
            margin-bottom: 30px;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            border-radius: 2px;
        }
        .feedback-card {
            background: #fff;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        .form-label {
            font-weight: bold;
            color: #333;
        }
        .rating-stars {
            direction: rtl;
            display: inline-block;
        }
        .rating-stars > input {
            display: none;
        }
        .rating-stars > label {
            color: #ccc;
            font-size: 2.5rem;
            padding: 0 5px;
            cursor: pointer;
            transition: color 0.2s;
        }
        .rating-stars > input:checked ~ label {
            color: #ffc107;
        }
        .rating-stars > label:hover,
        .rating-stars > label:hover ~ label {
            color: #ffda6a;
        }
    </style>
</head>
<body>
    <?php include 'includes/navbar.php'; ?>
    <header class="hero short">
        <div class="container text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown">Share Your Feedback</h1>
        </div>
    </header>
    <main class="container my-5 flex-grow-1">
        <section class="feedback-section">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="feedback-card animate__animated animate__fadeInUp">
                        <h2 class="section-title text-center">We Value Your Opinion</h2>
                        <form action="submit_feedback.php" method="POST">
                            <div class="mb-3">
                                <label for="name" class="form-label">Your Name</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email Address</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="feedback" class="form-label">Your Feedback</label>
                                <textarea class="form-control" id="feedback" name="feedback" rows="5" required></textarea>
                            </div>
                            <div class="mb-4 text-center">
                                <label class="form-label d-block mb-3">Your Rating</label>
                                <div class="rating-stars">
                                    <input type="radio" id="star5" name="rating" value="5" required>
                                    <label for="star5" title="Rate 5 stars">★</label>
                                    <input type="radio" id="star4" name="rating" value="4">
                                    <label for="star4" title="Rate 4 stars">★</label>
                                    <input type="radio" id="star3" name="rating" value="3">
                                    <label for="star3" title="Rate 3 stars">★</label>
                                    <input type="radio" id="star2" name="rating" value="2">
                                    <label for="star2" title="Rate 2 stars">★</label>
                                    <input type="radio" id="star1" name="rating" value="1">
                                    <label for="star1" title="Rate 1 star">★</label>
                                </div>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-glow btn-lg">Send Feedback</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php include 'includes/footer.php'; ?>
    <script src="js/bootstrap.bundle.min.js"></script>
    <?php
    if (isset($_SESSION['alert'])): 
        $alert = $_SESSION['alert'];
    ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: '<?= htmlspecialchars($alert['type']) ?>',
                    title: '<?= htmlspecialchars($alert['title']) ?>',
                    text: '<?= htmlspecialchars($alert['text']) ?>',
                });
            });
        </script>
    <?php 
        unset($_SESSION['alert']);
    endif; 
    ?>
</body>
</html>