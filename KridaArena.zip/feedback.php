<?php
session_start();
require_once 'config/db.php';
$page_title = "Feedback | KridaArena";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>    
    <style>
        .section-title {
            position: relative;
            padding-bottom: 15px;
            margin-bottom: 30px;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            border-radius: 2px;
        }
        .feedback-form-container {
            max-width: 800px;
            margin: 0 auto;
            background: #fff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
        }
        .btn-glow {
            transition: all 0.3s ease-in-out;
        }
        .btn-glow:hover {
            box-shadow: 0 5px 15px rgba(248, 72, 210, 0.4), 0 0 10px rgba(236, 124, 32, 0.3);
            transform: translateY(-3px);
        }
        .hero.short {
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            padding: 70px 0;
            text-align: center;
            color: #fff;
            border-bottom-left-radius: 40px;
            border-bottom-right-radius: 40px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
            margin-bottom: 50px;
        }
        .rating-stars {
            display: flex;
            justify-content: center;
            direction: rtl;
            gap: 5px;
        }
        .rating-stars input[type="radio"] {
            display: none;
        }
        .rating-stars label {
            cursor: pointer;
            font-size: 2rem;
            color: #ccc;
            transition: all 0.2s ease-in-out;
        }
        .rating-stars label:hover,
        .rating-stars label:hover ~ label,
        .rating-stars input[type="radio"]:checked ~ label {
            background: -webkit-linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body>
    <?php include 'includes/navbar.php'; ?>

    <header class="hero short">
        <div class="container text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown">We Value Your Feedback</h1>
            <p class="hero-subtitle animate__animated animate__fadeInUp">Help us improve KridaArena by sharing your thoughts and suggestions.</p>
        </div>
    </header>

    <main class="container my-5">
        <section class="my-5">
            <h2 class="section-title text-center animate__animated animate__fadeIn">Send us your feedback</h2>
            <div class="feedback-form-container animate__animated animate__fadeInUp">
                <form action="process_feedback.php" method="POST">
                    <div class="mb-3">
                        <label for="name" class="form-label">Your Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="subject" class="form-label">Subject</label>
                        <input type="text" class="form-control" id="subject" name="subject" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Your Feedback</label>
                        <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                    </div>
                    <div class="mb-4 text-center">
                        <label class="form-label d-block mb-3">Your Rating</label>
                        <div class="rating-stars">
                            <input type="radio" id="star5" name="rating" value="5" required>
                            <label for="star5" class="bi bi-star-fill"></label>
                            <input type="radio" id="star4" name="rating" value="4">
                            <label for="star4" class="bi bi-star-fill"></label>
                            <input type="radio" id="star3" name="rating" value="3">
                            <label for="star3" class="bi bi-star-fill"></label>
                            <input type="radio" id="star2" name="rating" value="2">
                            <label for="star2" class="bi bi-star-fill"></label>
                            <input type="radio" id="star1" name="rating" value="1">
                            <label for="star1" class="bi bi-star-fill"></label>
                        </div>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-glow btn-lg">Send Feedback</button>
                    </div>
                </form>
            </div>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>