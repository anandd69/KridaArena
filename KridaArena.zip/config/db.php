<?php
// Database credentials
$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "kridaarena";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    // Better to not expose sensitive info in production
    die("Database Connection Failed: " . $conn->connect_error);
}

// Set character set (to avoid issues with special characters/emojis)
if (!$conn->set_charset("utf8mb4")) {
    die("Error loading character set utf8mb4: " . $conn->error);
}
?>
