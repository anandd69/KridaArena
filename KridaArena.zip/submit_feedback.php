<?php
session_start();
require_once 'config/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $message = trim($_POST['feedback'] ?? '');
    $rating = (int)($_POST['rating'] ?? 0);
    $subject = "User Submission";

    if (empty($name) || empty($email) || empty($message) || $rating < 1 || $rating > 5) {
        $_SESSION['alert'] = [
            'type' => 'error',
            'title' => 'Oops...',
            'text' => 'Please fill out all fields correctly, including a valid rating.'
        ];
        header("Location: feedback.php");
        exit();
    }
    $user_id = null;
    $stmt_user = $conn->prepare("SELECT id FROM users WHERE email = ?");
    if ($stmt_user) {
        $stmt_user->bind_param("s", $email);
        $stmt_user->execute();
        $result_user = $stmt_user->get_result();
        if ($row_user = $result_user->fetch_assoc()) {
            $user_id = $row_user['id'];
        }
        $stmt_user->close();
    }
    $sql = "INSERT INTO feedbacks (user_id, name, email, subject, message, rating) VALUES (?, ?, ?, ?, ?, ?)";
    $param_types = "issssi";
    $params = [$user_id, $name, $email, $subject, $message, $rating];
    if ($user_id === null) {
        $insert_stmt = $conn->prepare($sql);

        if ($insert_stmt === false) {
             $_SESSION['alert'] = [
                'type' => 'error',
                'title' => 'Database Query Error',
                'text' => 'SQL prepare failed (NULL User): ' . $conn->error . '. Please check table/column names.'
            ];
        } else {
            $bind_params = [];
            $bind_params[] = &$param_types;
            foreach ($params as $key => $value) {
                $bind_params[] = &$params[$key];
            }
            call_user_func_array([$insert_stmt, 'bind_param'], $bind_params);
            
            if ($insert_stmt->execute()) {
                 $_SESSION['alert'] = [
                    'type' => 'success',
                    'title' => 'Thank You!',
                    'text' => 'Your feedback has been submitted successfully.'
                ];
            } else {
                 $_SESSION['alert'] = [
                    'type' => 'error',
                    'title' => 'Submission Failed',
                    'text' => 'An error occurred while saving your feedback: ' . $insert_stmt->error
                ];
            }
            $insert_stmt->close();
        }
    } else {
        $insert_stmt = $conn->prepare($sql);
        
        if ($insert_stmt === false) {
             $_SESSION['alert'] = [
                'type' => 'error',
                'title' => 'Database Query Error',
                'text' => 'SQL prepare failed (Found User): ' . $conn->error . '. Please check table/column names.'
            ];
        } else {
            $insert_stmt->bind_param("issssi", $user_id, $name, $email, $subject, $message, $rating);
            if ($insert_stmt->execute()) {
                 $_SESSION['alert'] = [
                    'type' => 'success',
                    'title' => 'Thank You!',
                    'text' => 'Your feedback has been submitted successfully.'
                ];
            } else {
                 $_SESSION['alert'] = [
                    'type' => 'error',
                    'title' => 'Submission Failed',
                    'text' => 'An error occurred while saving your feedback: ' . $insert_stmt->error
                ];
            }
            $insert_stmt->close();
        }
    }
    header("Location: feedback.php");
    exit();
} else {
    header("Location: feedback.php");
    exit();
}
?>