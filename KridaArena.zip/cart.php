<?php
session_start();
require_once 'config/db.php';
$page_title = "Shopping Cart | KridaArena";
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    $id = isset($_GET['id']) ? $_GET['id'] : null;
    switch ($action) {
        case 'add':
            if ($id && isset($_SESSION['cart'][$id])) {
                $_SESSION['cart'][$id]['quantity']++;
            } elseif ($id) {
                $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $result = $stmt->get_result();
                $product = $result->fetch_assoc();
                if ($product) {
                    $_SESSION['cart'][$id] = [
                        'quantity' => 1,
                        'name' => $product['name'],
                        'price' => $product['price']
                    ];
                }
            }
            $_SESSION['cart_msg'] = "Product added to cart successfully!";
            $_SESSION['cart_msg_type'] = "success";
            header("Location: cart.php");
            exit();
        case 'remove':
            if ($id && isset($_SESSION['cart'][$id])) {
                unset($_SESSION['cart'][$id]);
                $_SESSION['cart_msg'] = "Product removed from cart.";
                $_SESSION['cart_msg_type'] = "info";
            }
            break;
        case 'clear':
            $_SESSION['cart'] = [];
            $_SESSION['cart_msg'] = "Your cart has been cleared.";
            $_SESSION['cart_msg_type'] = "info";
            break;
        case 'update':
            if ($id && isset($_POST['quantity'])) {
                $new_quantity = intval($_POST['quantity']);
                if ($new_quantity > 0) {
                    $_SESSION['cart'][$id]['quantity'] = $new_quantity;
                    $_SESSION['cart_msg'] = "Cart updated successfully!";
                    $_SESSION['cart_msg_type'] = "success";
                } else {
                    unset($_SESSION['cart'][$id]);
                    $_SESSION['cart_msg'] = "Product removed from cart.";
                    $_SESSION['cart_msg_type'] = "info";
                }
            }
            break;
    }
    header("Location: cart.php");
    exit();
}
$cart_products = [];
if (!empty($_SESSION['cart'])) {
    $product_ids = array_map('intval', array_keys($_SESSION['cart']));
    $placeholders = implode(',', array_fill(0, count($product_ids), '?'));
    if (!empty($product_ids)) {
        $stmt = $conn->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
        $types = str_repeat('i', count($product_ids));
        $stmt->bind_param($types, ...$product_ids);
        $stmt->execute();
        $result = $stmt->get_result();
        $products_db = $result->fetch_all(MYSQLI_ASSOC);
        foreach ($products_db as $product_row) {
            $cart_products[$product_row['id']] = $product_row;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>
</head>
<body class="d-flex flex-column min-vh-100">
    <?php include 'includes/navbar.php'; ?>
    <header class="hero short">
        <div class="container text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown">Your Shopping Cart</h1>
        </div>
    </header>
    <main class="container my-5 flex-grow-1">
        <section class="cart-section">
            <?php if (empty($_SESSION['cart'])): ?>
                <div class="alert alert-info text-center" role="alert">
                    Your cart is empty. <a href="store.php" class="alert-link">Start shopping here!</a>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table cart-table">
                        <thead>
                            <tr>
                                <th scope="col">Product</th>
                                <th scope="col">Price</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Total</th>
                                <th scope="col"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $grand_total = 0;
                            foreach ($_SESSION['cart'] as $id => $item):
                                if (isset($cart_products[$id])):
                                    $product = $cart_products[$id];
                                    $item_total = $product['price'] * $item['quantity'];
                                    $grand_total += $item_total;
                            ?>
                                <tr>
                                    <td>
                                        <img src="images/<?= htmlspecialchars($product['image']) ?>" class="cart-img me-2" alt="<?= htmlspecialchars($product['name']) ?>">
                                        <?= htmlspecialchars($product['name']) ?>
                                    </td>
                                    <td>₹<?= number_format($product['price'], 2) ?></td>
                                    <td>
                                        <form action="cart.php?action=update&id=<?= $id ?>" method="post" class="d-flex align-items-center">
                                            <input type="number" name="quantity" value="<?= $item['quantity'] ?>" class="form-control quantity-input" min="1" onchange="this.form.submit()">
                                            <button type="submit" class="btn btn-sm btn-primary ms-2 d-none"><i class="bi bi-arrow-clockwise"></i></button>
                                        </form>
                                    </td>
                                    <td>₹<?= number_format($item_total, 2) ?></td>
                                    <td>
                                        <a href="cart.php?action=remove&id=<?= $id ?>" class="btn btn-danger btn-sm"><i class="bi bi-trash"></i></a>
                                    </td>
                                </tr>
                            <?php
                                endif;
                            endforeach;
                            ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="3" class="text-end"><strong>Grand Total:</strong></td>
                                <td colspan="2"><strong>₹<?= number_format($grand_total, 2) ?></strong></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="text-end mt-4">
                    <a href="cart.php?action=clear" class="btn btn-outline-danger me-2"><i class="bi bi-x-circle"></i> Clear Cart</a>
                    <a href="checkout.php" class="btn btn-success"><i class="bi bi-check-circle"></i> Checkout</a>
                </div>
            <?php endif; ?>
        </section>
    </main>
    <?php include 'includes/footer.php'; ?>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
    <script>
        <?php if (isset($_SESSION['cart_msg'])): ?>
            Swal.fire({
                icon: '<?= $_SESSION['cart_msg_type'] ?>',
                title: '<?= $_SESSION['cart_msg'] ?>',
                showConfirmButton: false,
                timer: 1500
            });
            <?php unset($_SESSION['cart_msg']); unset($_SESSION['cart_msg_type']); ?>
        <?php endif; ?>
    </script>
</body>
</html>