<?php
session_start();
require_once 'config/db.php';
$page_title = "Invoice | KridaArena";
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$order_id = $_GET['order_id'] ?? null;
if (!$order_id || !is_numeric($order_id)) {
    $_SESSION['error_msg'] = "Invalid order ID provided.";
    header("Location: order.php");
    exit();
}
$order = null;
$order_items = [];
$customer_details = [];
$company_info = [
    'name' => 'KridaArena E-Commerce',
    'address' => '123 Sport Street, Arena City, 10001',
    'email' => 'support@kridaarena.com',
    'phone' => '+91 98765 43210',
    'gstin' => 'GSTIN00112233'
];
try {
    $stmt_order = $conn->prepare("SELECT * FROM orders WHERE order_id = ? AND user_id = ?");
    if ($stmt_order === false) { die("MySQL prepare error: " . $conn->error); }
    $stmt_order->bind_param("ii", $order_id, $user_id);
    $stmt_order->execute();
    $result_order = $stmt_order->get_result();
    $order = $result_order->fetch_assoc();
    if (!$order) {
        $_SESSION['error_msg'] = "Order not found or does not belong to you.";
        header("Location: order.php");
        exit();
    }
    $shipping_address_id = $order['shipping_address_id'];
    $stmt_address = $conn->prepare("SELECT * FROM saved_addresses WHERE id = ?");
    $stmt_address->bind_param("i", $shipping_address_id);
    $stmt_address->execute();
    $result_address = $stmt_address->get_result();
    $address_row = $result_address->fetch_assoc();
    if (!$address_row) {
        $customer_details = [
            'name' => 'N/A', 'email' => 'N/A', 'address' => 'Shipping address not found.', 
            'city' => 'N/A', 'state' => 'N/A', 'zip' => 'N/A'
        ];
    } else {
        $customer_details = [
            'name' => $address_row['name'],
            'email' => $address_row['email'],
            'address' => $address_row['address'],
            'city' => $address_row['city'],
            'state' => $address_row['state'],
            'zip' => $address_row['zip'],
        ];
    }
    $stmt_items = $conn->prepare("
        SELECT oi.quantity, oi.price_at_purchase AS unit_price, p.name AS product_name, p.image AS product_image 
        FROM order_items oi 
        JOIN products p ON oi.product_id = p.id 
        WHERE oi.order_id = ?
    ");
    $stmt_items->bind_param("i", $order_id);
    $stmt_items->execute();
    $result_items = $stmt_items->get_result();
    $order_items = $result_items->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    die("Error fetching order details: " . $e->getMessage());
}
$subtotal = array_reduce($order_items, function($carry, $item) {
    return $carry + ($item['unit_price'] * $item['quantity']);
}, 0);
$shipping_fee = $order['shipping_fee'] ?? 50.00;
$tax = $order['tax_amount'] ?? round($subtotal * 0.18, 2);
$grand_total = $subtotal + $shipping_fee + $tax;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> #<?= htmlspecialchars($order_id) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>
    <style>
        body {
            font-size: 14px;
            color: #000;
            padding: 20px;
        }
        .container {
            max-width: 700px;
            margin: 0 auto;
            border: 2px solid #000;
            padding: 30px;
        }
        .invoice-header {
            border-bottom: 2px solid #000;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }
        .address-box {
            border: 1px solid #000;
            padding: 10px;
            min-height: 120px;
        }
        .table th, .table td {
            padding: 8px;
            vertical-align: top;
            border-top: 1px solid #ccc;
        }
        .table thead th {
            border-bottom: 2px solid #000;
        }
        .table-total tr:last-child {
            font-weight: bold;
            font-size: 1.1em;
        }
        .table-total td {
            border-top: none !important;
        }
        @media print {
            body {
                padding: 0;
            }
            .container {
                border: 2px solid #000 !important;
                box-shadow: none;
                padding: 20px;
                margin: 0;
                width: 100%;
                max-width: 100%;
            }
            .table-total tr:last-child, .table-success {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                background-color: #d1e7dd !important;
            }
            .table-dark {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                background-color: #343a40 !important;
                color: white !important;
            }
        }
    </style>
</head>
<body onload="window.print()">
    <div class="container">
        <header class="invoice-header row align-items-center">
            <div class="col-7">
                <h1 class="mb-0">TAX INVOICE</h1>
                <p class="text-muted">Invoice #<?= htmlspecialchars($order['order_id']) ?></p>
            </div>
            <div class="col-5 text-end">
                <h5><?= htmlspecialchars($company_info['name']) ?></h5>
                <small><?= htmlspecialchars($company_info['address']) ?></small><br>
                <small>Email: <?= htmlspecialchars($company_info['email']) ?></small><br>
                <small>GSTIN: <?= htmlspecialchars($company_info['gstin']) ?></small>
            </div>
        </header>
        <div class="row mb-4">
            <div class="col-6 d-flex">
                <div class="address-box w-100">
                    <h6>BILLING / SHIPPING ADDRESS</h6>
                    <strong><?= htmlspecialchars($customer_details['name']) ?></strong><br>
                    <?= htmlspecialchars($customer_details['address']) ?><br>
                    <?= htmlspecialchars($customer_details['city']) ?>, <?= htmlspecialchars($customer_details['state']) ?> - <?= htmlspecialchars($customer_details['zip']) ?><br>
                    Email: <?= htmlspecialchars($customer_details['email']) ?>
                </div>
            </div>
            <div class="col-6 d-flex">
                <div class="address-box w-100">
                    <h6>ORDER DETAILS</h6>
                    <p class="mb-1"><strong>Order Date:</strong> <?= date("d/M/Y", strtotime($order['created_at'])) ?></p>
                    <p class="mb-1"><strong>Order ID:</strong> <?= htmlspecialchars($order['order_id']) ?></p>
                    <p class="mb-1"><strong>Payment:</strong> <?= htmlspecialchars($order['payment_method'] ?? 'N/A') ?></p>
                    <p class="mb-0"><strong>Status:</strong> <?= htmlspecialchars($order['status']) ?></p>
                </div>
            </div>
        </div>
        <h6>PRODUCT DETAILS</h6>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr class="table-dark">
                        <th>#</th>
                        <th>Product Name</th>
                        <th class="text-end">Unit Price (₹)</th>
                        <th class="text-end">Qty</th>
                        <th class="text-end">Amount (₹)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; foreach ($order_items as $item): ?>
                    <tr>
                        <td><?= $i++ ?></td>
                        <td><?= htmlspecialchars($item['product_name']) ?></td>
                        <td class="text-end"><?= number_format($item['unit_price'], 2) ?></td>
                        <td class="text-end"><?= htmlspecialchars($item['quantity']) ?></td>
                        <td class="text-end"><?= number_format($item['unit_price'] * $item['quantity'], 2) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="row mt-3">
            <div class="col-6">
                <p class="text-muted small">Thank you for shopping with KridaArena!</p>
            </div>
            <div class="col-6">
                <table class="table table-borderless table-total">
                    <tbody>
                        <tr>
                            <td class="text-end">Subtotal:</td>
                            <td class="text-end" style="width: 30%">₹<?= number_format($subtotal, 2) ?></td>
                        </tr>
                        <tr>
                            <td class="text-end">Shipping Fee:</td>
                            <td class="text-end">₹<?= number_format($shipping_fee, 2) ?></td>
                        </tr>
                        <tr>
                            <td class="text-end">Tax (GST/VAT):</td>
                            <td class="text-end">₹<?= number_format($tax, 2) ?></td>
                        </tr>
                        <tr class="table-success">
                            <td class="text-end">GRAND TOTAL:</td>
                            <td class="text-end">₹<?= number_format($grand_total, 2) ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <footer class="text-center mt-5 pt-3 border-top">
            <p class="mb-0 small">This is a system-generated invoice and does not require a signature.</p>
        </footer>
    </div>
</body>
</html>