<?php
session_start();
require_once 'config/db.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in.']);
    exit();
}

$user_id = $_SESSION['user_id'];
$order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;

if ($order_id === 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid order ID.']);
    exit();
}

try {
    $stmt = $conn->prepare("SELECT created_at, status FROM orders WHERE order_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $order_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $order = $result->fetch_assoc();

    if (!$order) {
        echo json_encode(['status' => 'error', 'message' => 'Order not found or you do not have permission to cancel it.']);
        exit();
    }
    if ($order['status'] != 'Processing' && $order['status'] != 'Pending') {
        echo json_encode(['status' => 'error', 'message' => 'This order cannot be cancelled as its status is not "Processing" or "Pending".']);
        exit();
    }
    
    $stmt_update = $conn->prepare("UPDATE orders SET status = 'Cancelled' WHERE order_id = ? AND user_id = ?");
    $stmt_update->bind_param("ii", $order_id, $user_id);
    $stmt_update->execute();

    if ($stmt_update->affected_rows > 0) {
        echo json_encode(['status' => 'success', 'message' => 'Order cancelled successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to cancel the order.']);
    }

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'An unexpected error occurred: ' . $e->getMessage()]);
}
?>