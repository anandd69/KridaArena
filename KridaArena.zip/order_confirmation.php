<?php
session_start();
require_once 'config/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$order_id = $_GET['order_id'] ?? null;
$_SESSION['order_success_message'] = "Order #{$order_id} placed successfully!"; 
header("Location: order.php");
exit();
?>