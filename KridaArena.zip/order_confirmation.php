<?php
session_start();
require_once 'config/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$order_id = $_GET['order_id'] ?? null;
$order = null;
if ($order_id) {
    try {
        $stmt = $conn->prepare("SELECT delivery_date FROM orders WHERE order_id = ? AND user_id = ?");
        $stmt->bind_param("ii", $order_id, $_SESSION['user_id']);
        $stmt->execute();
        $result = $stmt->get_result();
        $order = $result->fetch_assoc();
    } catch (Exception $e) {
        error_log("Error fetching order details for confirmation: " . $e->getMessage());
    }
}
$delivery_date_text = $order['delivery_date'] ?? 'N/A';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmed</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>
</head>
<body class="d-flex flex-column min-vh-100">
    <div class="container d-flex justify-content-center align-items-center flex-grow-1">
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const orderId = <?= json_encode($order_id) ?>;
        const deliveryDate = <?= json_encode($delivery_date_text) ?>;
        let title = "Order Placed Successfully!";
        let text = "Your order has been placed. Order ID: #" + orderId + ".";
        if (deliveryDate !== 'N/A') {
            text += "<br>Estimated Delivery: " + deliveryDate;
        }
        Swal.fire({
            icon: 'success',
            title: title,
            html: text,
            showConfirmButton: false,
            timer: 4000
        }).then(() => {
            window.location.href = "order.php";
        });
    });
    </script>
</body>
</html>