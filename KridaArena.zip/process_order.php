<?php
session_start();
require_once 'config/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) {
    $_SESSION['order_error_msg'] = "Your cart is empty. Please add some items to place an order.";
    header("Location: checkout.php");
    exit();
}
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$address = $_POST['address'] ?? '';
$city = $_POST['city'] ?? '';
$state = $_POST['state'] ?? '';
$zip = $_POST['zip'] ?? '';
$paymentMethod = $_POST['paymentMethod'] ?? 'COD';
$selected_product_id = $_POST['product_id'] ?? '';
$conn->begin_transaction();
$shipping_address_id = null;
try {
    $stmt = $conn->prepare("SELECT id FROM saved_addresses WHERE user_id = ? AND name = ? AND email = ? AND address = ? AND city = ? AND state = ? AND zip = ?");
    $stmt->bind_param("issssss", $user_id, $name, $email, $address, $city, $state, $zip);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $shipping_address_id = $row['id'];
    } else {
        $stmt_save = $conn->prepare("INSERT INTO saved_addresses (user_id, name, email, address, city, state, zip) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt_save->bind_param("issssss", $user_id, $name, $email, $address, $city, $state, $zip);
        $stmt_save->execute();
        $shipping_address_id = $stmt_save->insert_id;
    }
    $items_to_order = [];
    if (!empty($selected_product_id)) {
        if (isset($cart[$selected_product_id])) {
            $items_to_order[$selected_product_id] = $cart[$selected_product_id];
        } else {
            throw new Exception("Selected product not found in cart.");
        }
    } else {
        $items_to_order = $cart;
    }
    $total_amount = 0;
    $product_ids_to_fetch = array_keys($items_to_order);
    if (empty($product_ids_to_fetch)) {
        throw new Exception("No items selected for order.");
    }
    $placeholders = implode(',', array_fill(0, count($product_ids_to_fetch), '?'));
    $stmt_products = $conn->prepare("SELECT id, price FROM products WHERE id IN ($placeholders)");
    $types = str_repeat('i', count($product_ids_to_fetch));
    $stmt_products->bind_param($types, ...$product_ids_to_fetch);
    $stmt_products->execute();
    $result_products = $stmt_products->get_result();
    $product_prices = [];
    while ($row = $result_products->fetch_assoc()) {
        $product_prices[$row['id']] = $row['price'];
    }
    foreach ($items_to_order as $id => $item) {
        if (!isset($product_prices[$id])) {
            throw new Exception("Product with ID " . htmlspecialchars($id) . " not found.");
        }
        $total_amount += $product_prices[$id] * $item['quantity'];
    }
    $delivery_date = date('Y-m-d', strtotime('+7 days'));
    $stmt_order = $conn->prepare("INSERT INTO orders (user_id, shipping_address_id, total_amount, status, delivery_date) VALUES (?, ?, ?, ?, ?)");
    $status = "Pending";
    $stmt_order->bind_param("iidss", $user_id, $shipping_address_id, $total_amount, $status, $delivery_date);
    $stmt_order->execute();
    $order_id = $stmt_order->insert_id;
    $stmt_item = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price_at_purchase) VALUES (?, ?, ?, ?)");
    foreach ($items_to_order as $id => $item) {
        $price_at_purchase = $product_prices[$id];
        $quantity = $item['quantity'];
        $stmt_item->bind_param("iiid", $order_id, $id, $quantity, $price_at_purchase);
        $stmt_item->execute();
    }
    foreach ($items_to_order as $id => $item) {
        unset($_SESSION['cart'][$id]);
    }
    $conn->commit();
    header("Location: order_confirmation.php?order_id=" . $order_id);
    exit();
} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['order_error_msg'] = "Failed to place order: " . $e->getMessage();
    header("Location: checkout.php");
    exit();
} finally {
    if (isset($stmt)) $stmt->close();
    if (isset($stmt_save)) $stmt_save->close();
    if (isset($stmt_products)) $stmt_products->close();
    if (isset($stmt_order)) $stmt_order->close();
    if (isset($stmt_item)) $stmt_item->close();
}
?>