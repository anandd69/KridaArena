<?php
session_start();
require_once 'config/db.php';
$page_title = "My Registered Sports | KridaArena";
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 1; 
$stmt = $conn->prepare("SELECT * FROM registrations WHERE user_id = ? ORDER BY registration_date DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$my_registrations = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>    
    <style>
        .hero {
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            padding: 70px;
            text-align: center;
            border-bottom-left-radius: 40px;
            border-bottom-right-radius: 40px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
        }
        .my-sports-card {
            background: #fff;
            color: #222;
            padding: 25px;
            border-radius: 15px;
            transition: 0.3s;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .my-sports-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 0 20px rgba(236,124,32,0.6);
        }
        .player-info p {
            margin-bottom: 0.2rem;
        }
    </style>
</head>
<body>
<?php include "includes/navbar.php"; ?>
<header class="hero">
    <h1 class="animate__animated animate__fadeInDown">My Registered Sports</h1>
    <p class="animate__animated animate__fadeInUp">View your past and current registrations.</p>
</header>
<main class="container my-5">
    <div class="row g-4">
        <?php if (!empty($my_registrations)): ?>
            <?php foreach ($my_registrations as $reg):
                $players = json_decode($reg['players_data'], true);
            ?>
            <div class="col-md-6 animate__animated animate__zoomIn">
                <div class="my-sports-card">
                    <h5>**<?= htmlspecialchars(ucfirst($reg['sport_type'])) ?>**</h5>
                    <p><b>Team Name:</b> <?= htmlspecialchars($reg['team_name']) ?></p>
                    <p><b>Registration Date:</b> <?= date("F j, Y, g:i a", strtotime($reg['registration_date'])) ?></p>
                    <hr>
                    <h6>Players:</h6>
                    <div class="player-info">
                        <?php foreach ($players as $i => $player): ?>
                            <p><b>Player <?= $i ?>:</b> <?= htmlspecialchars($player['name']) ?> (Age: <?= htmlspecialchars($player['age']) ?>)</p>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center my-5">
                <div class="alert alert-info">You have not registered for any tournaments yet. <a href="tournaments.php">Register now!</a></div>
            </div>
        <?php endif; ?>
    </div>
</main>
<?php include "includes/footer.php"; ?>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>