<?php
session_start();
require_once 'config/db.php';
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: store.php");
    exit();
}
$product_id = $_GET['id'];
$page_title = "Product Details | KridaArena";
if (!isset($conn) || $conn->connect_error) {
    die("Database connection failed: " . (isset($conn) ? $conn->connect_error : "Connection object not found."));
}
try {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    if (!$product) {
        header("Location: store.php");
        exit();
    }
} catch (Exception $e) {
    die("Error fetching product details: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($product['name']) ?> | KridaArena</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>
    <style>
        .hero.short {
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            text-align: center;
            padding: 80px 0;
            margin-bottom: 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            color: #fff;
        }

        .product-details-section {
            background: #fff;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }
        .product-details-img {
            max-height: 400px;
            object-fit: contain;
        }
        .product-details-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: #2c293d;
        }
        .product-details-price {
            font-size: 2rem;
            font-weight: bold;
            color: #ec7c20ff;
        }
        .product-details-description {
            font-size: 1.1rem;
            color: #495057;
            line-height: 1.6;
        }
        .btn-glow {
            background: linear-gradient(45deg, #f848d2ff, #ec7c20ff);
            border: none;
            color: #fff;
            padding: 12px 25px;
            border-radius: 25px;
            font-weight: bold;
            transition: 0.3s;
            box-shadow: 0 0 5px rgba(248, 72, 210, 0.5);
        }
        .btn-glow:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px rgba(248, 72, 210, 0.8);
        }
    </style>
</head>
<body>
    <?php include 'includes/navbar.php'; ?>
    <header class="hero short">
        <div class="container text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown"><?= htmlspecialchars($product['name']) ?></h1>
        </div>
    </header>
    <main class="container my-5">
        <div class="row product-details-section">
            <div class="col-lg-6 mb-4 mb-lg-0 animate__animated animate__fadeInLeft">
                <img src="images/<?= htmlspecialchars($product['image']) ?>" class="img-fluid rounded-3 product-details-img" alt="<?= htmlspecialchars($product['name']) ?>">
            </div>
            <div class="col-lg-6 animate__animated animate__fadeInRight">
                <h2 class="product-details-title"><?= htmlspecialchars($product['name']) ?></h2>
                <h4 class="product-details-price">₹<?= number_format($product['price'], 2) ?></h4>
                <p class="product-details-description"><?= nl2br(htmlspecialchars($product['description'])) ?></p>
                <div class="d-grid gap-2">
                    <a href="cart.php?action=add&id=<?= $product['id'] ?>" class="btn btn-glow mt-4">Add to Cart <i class="bi bi-cart-plus"></i></a>
                    <a href="store.php" class="btn btn-outline-dark mt-2">Back to Store</a>
                </div>
            </div>
        </div>
    </main>
    <?php include 'includes/footer.php'; ?>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>