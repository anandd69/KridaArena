<?php
session_start();
$page_title = "Tournament Archives | KridaArena";
$finished_tournaments = [
    [
        "name" => "Ahmedabad City Cricket League 2024",
        "sport" => "Cricket",
        "date" => "10-25 March, 2024",
        "description" => "A high-stakes local cricket tournament that saw top teams from across Ahmedabad battle for the championship title.",
        "winner" => "Royal Strikers",
        "mvp" => "Rohan Sharma",
        "records" => [
            "Highest Score: **Rohan Sharma** with **125** runs.",
            "Most Wickets: **Priyanka Patel** with **15** wickets.",
            "Tournament MVP: **Rohan Sharma** for his all-round performance."
        ]
    ],
    [
        "name" => "National Football Cup 2023",
        "sport" => "Football",
        "date" => "5-20 November, 2023",
        "description" => "This tournament brought together the best football clubs in the nation for a two-week-long showcase of skill and strategy.",
        "winner" => "United FC",
        "mvp" => "Vikram Singh",
        "records" => [
            "Top Scorer: **Vikram Singh** with **10** goals.",
            "Best Goalkeeper: **Akash Kumar** with **5** clean sheets.",
            "Tournament Winner: **United FC** after a thrilling final match."
        ]
    ],
    [
        "name" => "State Chess Championship 2024",
        "sport" => "Chess",
        "date" => "1-5 May, 2024",
        "description" => "A strategic showdown of the state's most brilliant minds. The event featured intense matches and surprising upsets.",
        "winner" => "Ananya Gupta",
        "mvp" => "Ananya Gupta",
        "records" => [
            "Undefeated Champion: **Ananya Gupta**, who won all her matches.",
            "Fastest Checkmate: **Rahul Verma** in **15** moves.",
            "Most Enduring Game: **4-hour** long match in the semi-finals."
        ]
    ],
    [
        "name" => "Pro Kabaddi Championship 2023",
        "sport" => "Kabaddi",
        "date" => "15-30 September, 2023",
        "description" => "The most anticipated Kabaddi event of the year, with power, speed, and agility on full display.",
        "winner" => "Gujarat Giants",
        "mvp" => "Sandeep Kumar",
        "records" => [
            "Most Raid Points: **Sandeep Kumar** with **120** points.",
            "Most Tackle Points: **Amit Yadav** with **40** points.",
            "Winner: **Gujarat Giants** in a thrilling final."
        ]
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            background-color: #f8f9fa; /* White background */
        }
        
        .hero {
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            padding: 70px;
            text-align: center;
            border-bottom-left-radius: 40px;
            border-bottom-right-radius: 40px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
            color: #fff;
        }

        .tournament-card {
            background: #fff;
            color: #222;
            padding: 30px;
            border-radius: 15px;
            text-align: left;
            margin-bottom: 30px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
            border: 1px solid #dee2e6;
        }
        
        .tournament-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .tournament-card h3 {
            font-weight: bold;
            color: #2c293d;
            font-size: 1.8rem;
        }
        .tournament-card p {
            color: #6c757d;
        }
        .tournament-card .badge-sport {
            background: linear-gradient(45deg, #f848d2ff, #ec7c20ff);
            color: #fff;
            padding: 5px 12px;
            border-radius: 20px;
            font-weight: bold;
        }
        .tournament-card ul {
            list-style-type: none;
            padding: 0;
            margin-top: 15px;
        }
        .tournament-card ul li {
            background-color: #f1f3f5;
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 8px;
            font-size: 0.95rem;
            color: #495057;
            border-left: 3px solid #ec7c20ff;
        }
        .tournament-card ul li strong {
            color: #2c293d;
        }
    </style>
</head>
<body>
    <?php include 'includes/navbar.php'; ?>

    <header class="hero">
        <div class="container text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown">Tournament Archives</h1>
            <p class="hero-subtitle animate__animated animate__fadeInUp">Explore the history, winners, and achievements of our past tournaments.</p>
        </div>
    </header>

    <main class="container my-5">
        <div class="row g-4">
            <?php foreach ($finished_tournaments as $index => $tournament): ?>
                <div class="col-lg-6 animate__animated animate__zoomIn" data-wow-delay="<?= $index * 0.2 ?>s">
                    <div class="tournament-card">
                        <span class="badge-sport"><?= htmlspecialchars($tournament['sport']) ?></span>
                        <h3 class="mt-3"><?= htmlspecialchars($tournament['name']) ?></h3>
                        <p class="text-muted"><i class="bi bi-calendar-fill me-2"></i><?= htmlspecialchars($tournament['date']) ?></p>
                        <p><?= htmlspecialchars($tournament['description']) ?></p>
                        <hr class="my-3">
                        <p><strong>Winner:</strong> <span class="text-primary"><?= htmlspecialchars($tournament['winner']) ?></span></p>
                        <p><strong>MVP:</strong> <span class="text-primary"><?= htmlspecialchars($tournament['mvp']) ?></span></p>
                        <h5 class="mt-4">Notable Achievements:</h5>
                        <ul>
                            <?php foreach ($tournament['records'] as $record): ?>
                                <li><?= $record ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script>
        new WOW().init();
    </script>
</body>
</html>