<?php
session_start();
require_once 'config/db.php';
$page_title = "Store | KridaArena";
if (!isset($conn) || $conn->connect_error) {
    die("Database connection failed: " . (isset($conn) ? $conn->connect_error : "Connection object not found."));
}
$selected_sport = isset($_GET['sport']) ? $_GET['sport'] : 'all';
$query = "SELECT * FROM products";
$params = [];
$types = "";
if ($selected_sport != 'all') {
    $query .= " WHERE description LIKE ?";
    $params[] = '%' . $selected_sport . '%';
    $types .= "s";
}
$query .= " ORDER BY id DESC";
try {
    $stmt = $conn->prepare($query);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $products = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    die("Error fetching products: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        @keyframes glowing-card {
            0% { box-shadow: 0 0 5px rgba(248, 72, 210, 0.5); }
            50% { box-shadow: 0 0 20px rgba(236, 124, 32, 0.7); }
            100% { box-shadow: 0 0 5px rgba(248, 72, 210, 0.5); }
        }

        .hero.short {
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            text-align: center;
            padding: 80px 0;
            margin-bottom: 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            color: #fff;
        }

        .product-card {
            background: #fff;
            color: #222;
            border-radius: 15px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 0 20px rgba(236,124,32,0.6);
        }
        .product-card img {
            height: 250px;
            object-fit: cover;
            border-bottom: 1px solid #eee;
        }
        .product-card .card-body {
            padding: 20px;
        }
        .product-price {
            font-size: 1.8rem;
            font-weight: bold;
            color: #2c293d;
        }
        .btn-glow {
            background: linear-gradient(45deg, #f848d2ff, #ec7c20ff);
            border: none;
            color: #fff;
            padding: 10px 20px;
            border-radius: 25px;
            font-weight: bold;
            transition: 0.3s;
            box-shadow: 0 0 5px rgba(248, 72, 210, 0.5);
        }
        .btn-glow:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px rgba(248, 72, 210, 0.8);
        }
        .filter-btn {
            background: #f1f3f5;
            color: #495057;
            margin: 5px;
            border-radius: 25px;
            padding: 8px 18px;
            transition: all 0.3s ease;
        }
        .filter-btn:hover {
            background: #e9ecef;
            transform: translateY(-2px);
        }
        .filter-btn.active {
            background: linear-gradient(45deg, #ec7c20ff, #f848d2ff);
            color: #fff;
            box-shadow: 0 0 10px rgba(236,124,32,0.6);
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <?php include 'includes/navbar.php'; ?>

    <header class="hero short">
        <div class="container text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown">KridaArena Store</h1>
            <p class="hero-subtitle animate__animated animate__fadeInUp">Find the Best Sports Gear and Equipment</p>
        </div>
    </header>

    <main class="container my-5">
        <div class="d-flex flex-wrap justify-content-center justify-content-md-center align-items-center mb-4">
            <section class="filters-section d-flex flex-wrap justify-content-center me-md-auto mb-3 mb-md-0 animate__animated animate__fadeIn">
                <a href="store.php" class="btn filter-btn <?= ($selected_sport == 'all') ? 'active' : '' ?>">All Sports</a>
                <a href="store.php?sport=cricket" class="btn filter-btn <?= ($selected_sport == 'cricket') ? 'active' : '' ?>">Cricket</a>
                <a href="store.php?sport=football" class="btn filter-btn <?= ($selected_sport == 'football') ? 'active' : '' ?>">Football</a>
                <a href="store.php?sport=basketball" class="btn filter-btn <?= ($selected_sport == 'basketball') ? 'active' : '' ?>">Basketball</a>
                <a href="store.php?sport=badminton" class="btn filter-btn <?= ($selected_sport == 'badminton') ? 'active' : '' ?>">Badminton</a>
                <a href="store.php?sport=tennis" class="btn filter-btn <?= ($selected_sport == 'tennis') ? 'active' : '' ?>">Tennis</a>
                <a href="store.php?sport=volleyball" class="btn filter-btn <?= ($selected_sport == 'volleyball') ? 'active' : '' ?>">Volleyball</a>
                <a href="store.php?sport=kabaddi" class="btn filter-btn <?= ($selected_sport == 'kabaddi') ? 'active' : '' ?>">Kabaddi</a>
                <a href="store.php?sport=chess" class="btn filter-btn <?= ($selected_sport == 'chess') ? 'active' : '' ?>">Chess</a>
            </section>
        </div>

        <section class="products-list">
            <div class="row g-4">
                <?php if ($products): ?>
                    <?php foreach ($products as $product): ?>
                        <div class="col-md-6 col-lg-4 d-flex">
                            <div class="card product-card flex-fill animate__animated animate__fadeInUp">
                                <img src="images/<?= htmlspecialchars($product['image']) ?>" class="card-img-top" alt="<?= htmlspecialchars($product['name']) ?>">
                                <div class="card-body text-center d-flex flex-column">
                                    <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                                    <p class="card-text text-muted"><?= htmlspecialchars($product['description']) ?></p>
                                    <h4 class="product-price mt-auto">₹<?= number_format($product['price'], 2) ?></h4>
                                    <a href="product.php?id=<?= $product['id'] ?>" class="btn btn-glow mt-3">View Details</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-12 text-center">
                        <p class="lead">No products available at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>