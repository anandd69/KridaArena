<?php
session_start();
require_once 'config/db.php';
$page_title = "About Us | KridaArena";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>
    <style>
        .hero.short {
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            padding: 70px 0;
            text-align: center;
            color: #fff;
            border-bottom-left-radius: 40px;
            border-bottom-right-radius: 40px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
            margin-bottom: 50px;
        }
        .about-card {
            background-color: #fff;
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.4s ease-in-out;
            height: 100%;
        }
        .card-hover-effect {
            transition: transform 0.4s ease-in-out, box-shadow 0.4s ease-in-out;
        }
        .card-hover-effect:hover {
            transform: translateY(-10px) scale(1.02);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
            cursor: pointer;
        }
        .about-card .about-icon {
            display: block;
            margin: 0 auto 15px auto;
            transition: transform 0.4s ease; 
        }
        .card-hover-effect:hover .about-icon {
            transform: scale(1.1);
        }
        .about-card h4 {
            color: #2c293d;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php include 'includes/navbar.php'; ?>
    <header class="hero short">
        <div class="container text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown">Our Story</h1>
            <p class="hero-subtitle animate__animated animate__fadeInUp">Connecting Athletes, Fostering Competition, and Building Community</p>
        </div>
    </header>
    <main class="container my-5">
        <section class="my-5">
            <div class="row align-items-center">
                <div class="col-md-6 animate__animated animate__fadeInLeft">
                    <img src="images/team.jpg" alt="Our Team" class="img-fluid rounded-3 shadow">
                </div>
                <div class="col-md-6 mt-4 mt-md-0 animate__animated animate__fadeInRight">
                    <h2 class="section-title">Our Mission</h2>
                    <p class="lead">KridaArena was born from a passion for sports and a desire to make it more accessible for everyone. Our mission is to build a vibrant community where athletes, fans, and organizers can connect effortlessly. We aim to be the go-to platform for discovering tournaments, finding the right gear, and celebrating the spirit of sportsmanship.</p>
                    <h2 class="section-title mt-4">Our Vision</h2>
                    <p class="lead">We envision a world where every person, regardless of their skill level, has the opportunity to participate in their favorite sport. By leveraging technology, we strive to simplify the journey from practice to podium, creating a seamless and rewarding experience for all.</p>
                </div>
            </div>
        </section>
        <hr>
        <section class="my-5 text-center">
            <h2 class="section-title mb-5 animate__animated animate__fadeIn">Our Core Values</h2>
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="card-hover-effect animate__animated animate__flipInX" style="animation-delay: 0.2s;">
                        <div class="about-card">
                            <img src="png/community.png" alt="Community Icon" class="about-icon" style="width: 69px; height: 64px;">
                            <h4 class="mt-3">Community</h4>
                            <p>We believe in the power of a strong community to foster growth and support.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-hover-effect animate__animated animate__flipInX" style="animation-delay: 0.4s;">
                        <div class="about-card">
                            <img src="png/fairplay.png" alt="Fair Play Icon" class="about-icon" style="width: 66px; height: 65px;">
                            <h4 class="mt-3">Fair Play</h4>
                            <p>We uphold the principles of fair competition and sportsmanship in every aspect.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="card-hover-effect animate__animated animate__flipInX" style="animation-delay: 0.6s;">
                        <div class="about-card">
                            <img src="png/integrity.png" alt="Integrity Icon" class="about-icon" style="width: 68px; height: 65px;">
                            <h4 class="mt-3">Integrity</h4>
                            <p>We operate with honesty and transparency, building trust with our users.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <hr>
        <section class="my-5 text-center">
            <h2 class="section-title mb-5 animate__animated animate__fadeIn">Meet Our Founders</h2>
            <div class="row justify-content-center g-4">
                <div class="col-md-4">
                    <div class="card-hover-effect animate__animated animate__fadeInUp" style="animation-delay: 0.8s;">
                        <div class="about-card">
                            <img src="png/m2.png" alt="Founder 2" style="width: 120px; height: 120px;">
                            <h4>Rajkumar Bhogayata</h4>
                            <p class="text-muted">Owner</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card-hover-effect animate__animated animate__fadeInUp" style="animation-delay: 1s;">
                        <div class="about-card">
                            <img src="png/m1.png" alt="Founder 1" style="width: 120px; height: 120px;">
                            <h4>Anand Nanda</h4>
                            <p class="text-muted">Owner</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <?php include 'includes/footer.php'; ?>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>