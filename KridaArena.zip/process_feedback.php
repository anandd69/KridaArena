<?php
session_start();
require_once 'config/db.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $subject = filter_input(INPUT_POST, 'subject', FILTER_SANITIZE_STRING);
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);
    $rating = filter_input(INPUT_POST, 'rating', FILTER_SANITIZE_NUMBER_INT);
    if (empty($name) || empty($email) || empty($subject) || empty($message) || empty($rating)) {
        $_SESSION['feedback_message'] = "Please fill out all required fields.";
        header("Location: feedback.php");
        exit();
    }
    if (isset($conn)) {
        $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
        if ($user_id !== null) {
            $sql = "INSERT INTO feedbacks (user_id, name, email, subject, message, rating, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())";
            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param("issssi", $user_id, $name, $email, $subject, $message, $rating);
            }
        } else {
            $sql = "INSERT INTO feedbacks (name, email, subject, message, rating, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param("ssssi", $name, $email, $subject, $message, $rating);
            }
        }
        if (isset($stmt)) {
            if ($stmt->execute()) {
                $_SESSION['feedback_message'] = "Thank you for your valuable feedback!";
            } else {
                $_SESSION['feedback_message'] = "Error submitting feedback. Please try again later.";
            }
            $stmt->close();
        } else {
             $_SESSION['feedback_message'] = "Internal error processing feedback.";
        }
        $conn->close();
    } else {
        $_SESSION['feedback_message'] = "Database connection error.";
    }
    header("Location: feedback.php");
    exit();
} else {
    header("Location: feedback.php");
    exit();
}
?>