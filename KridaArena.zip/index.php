<?php
session_start();
require_once 'config/db.php';
$page_title = "Home | KridaArena";
$featured_tournaments = [
    [
        'sport' => 'cricket',
        'name' => 'Cricket Premier League',
        'date' => 'Starts 25 Sep, 2025',
        'icon' => 'bi-bullseye' 
    ],
    [
        'sport' => 'football',
        'name' => 'Football Championship',
        'date' => 'Starts 10 Oct, 2025',
        'icon' => 'bi-dribbble' 
    ],
    [
        'sport' => 'chess',
        'name' => 'State Chess Tournament',
        'date' => 'Starts 1 Nov, 2025',
        'icon' => 'bi-puzzle-fill' 
    ]
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    
    <style>
        .section-title {
            position: relative;
            padding-bottom: 15px;
            margin-bottom: 30px;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            border-radius: 2px;
        }

        .card-hover-glow {
            transition: all 0.3s ease-in-out;
            border: 1px solid transparent;
        }
        .card-hover-glow:hover {
            transform: translateY(-10px);
            border-color: #f848d2;
            box-shadow: 0 10px 30px rgba(248, 72, 210, 0.3), 0 0 15px rgba(236, 124, 32, 0.2);
        }

        .tournament-item {
            background-color: #fff;
            padding: 25px;
            border-radius: 15px;
            text-align: center;
        }
        .tournament-item .icon {
            font-size: 3rem;
            margin-bottom: 15px;
            background: -webkit-linear-gradient(45deg, #ec7c20ff, #f848d2ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .stats-section {
            padding: 80px 0;
            background: linear-gradient(rgba(44, 41, 61, 0.9), rgba(44, 41, 61, 0.9)), url('images/stadium_bg.jpg') no-repeat center center;
            background-size: cover;
            background-attachment: fixed;
            color: #fff;
        }
        .stat-item {
            text-align: center;
        }
        .stat-item .stat-number {
            font-size: 3.5rem;
            font-weight: 700;
            color: #ec7c20;
        }
        .stat-item .stat-label {
            font-size: 1.2rem;
            color: #e0e0e0;
        }

        .testimonial-card {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            text-align: center;
            border-top: 5px solid #ec7c20;
        }
        .testimonial-card img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin: -70px auto 20px;
            border: 5px solid #fff;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .testimonial-card .stars {
            color: #ffc107;
            margin-bottom: 15px;
        }
        .testimonial-card .author {
            font-weight: bold;
            color: #2c293d;
        }

        .cta-section {
            padding: 60px 0;
            background: linear-gradient(45deg, #f848d2, #ec7c20);
            color: #fff;
            border-radius: 20px;
        }
    </style>
</head>
<body>
    <?php include 'includes/navbar.php'; ?>

    <header class="hero">
        <div class="container text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown">KridaArena</h1>
            <p class="hero-subtitle animate__animated animate__fadeInUp">Your Ultimate Destination for Sports, Tournaments & Gear</p>
            <a href="tournaments.php" class="btn btn-glow mt-4 animate__animated animate__zoomIn">Find a Tournament</a>
        </div>
    </header>

    <main class="container my-5">
        <section class="text-center my-5">
            <h2 class="section-title text-center animate__animated animate__fadeIn">Why KridaArena?</h2>
            <div class="row g-4 justify-content-center">
                <div class="col-lg-4 col-md-6"><div class="card card-hover-glow h-100 animate__animated animate__fadeInUp" style="animation-delay: 0.2s;"><i class="bi bi-trophy-fill card-icon"></i><h3 class="card-title">Join Tournaments</h3><p class="card-text">Discover and register for exciting local and national sports tournaments. Track your progress and compete with the best!</p></div></div>
                <div class="col-lg-4 col-md-6"><div class="card card-hover-glow h-100 animate__animated animate__fadeInUp" style="animation-delay: 0.4s;"><i class="bi bi-shop-window card-icon"></i><h3 class="card-title">Shop Sports Gear</h3><p class="card-text">Browse our comprehensive store for all your sports equipment and apparel needs. Quality products for every athlete.</p></div></div>
                <div class="col-lg-4 col-md-6"><div class="card card-hover-glow h-100 animate__animated animate__fadeInUp" style="animation-delay: 0.6s;"><i class="bi bi-info-circle-fill card-icon"></i><h3 class="card-title">Learn About Sports</h3><p class="card-text">Get detailed information on a wide range of sports. Learn rules, history, and pro tips to improve your game.</p></div></div>
            </div>
        </section>

        <section class="my-5 py-5 bg-light rounded-3">
            <div class="container">
                <h2 class="section-title text-center animate__animated animate__fadeIn">Upcoming Tournaments</h2>
                <div class="row g-4">
                    <?php foreach($featured_tournaments as $index => $tour): ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="tournament-item card-hover-glow h-100 animate__animated animate__fadeInUp" style="animation-delay: <?= $index * 0.2 ?>s;">
                            <div class="icon"><i class="bi <?= $tour['icon'] ?>"></i></div>
                            <h4 class="fw-bold text-dark"><?= htmlspecialchars($tour['name']) ?></h4>
                            <p class="text-muted"><?= htmlspecialchars($tour['date']) ?></p>
                            <a href="tournaments.php#regModal-<?= $tour['sport'] ?>" class="btn btn-outline-dark mt-auto">View Details</a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                 <div class="text-center mt-5">
                    <a href="tournaments.php" class="btn btn-glow animate__animated animate__pulse animate__infinite">View All Tournaments</a>
                </div>
            </div>
        </section>

        <section class="text-center my-5">
             <h2 class="section-title text-center mb-5 animate__animated animate__fadeIn">Featured Sports</h2>
             <div class="row g-4">
                 <div class="col-md-6 col-lg-3"><div class="sport-card animate__animated animate__zoomIn"><img src="images/cricket.jpg" alt="Cricket" class="img-fluid rounded-3"><div class="sport-info"><h4>Cricket</h4><p>A game of patience, power, and precision. A global passion.</p></div></div></div>
                 <div class="col-md-6 col-lg-3"><div class="sport-card animate__animated animate__zoomIn" style="animation-delay: 0.2s;"><img src="images/football.jpg" alt="Football" class="img-fluid rounded-3"><div class="sport-info"><h4>Football</h4><p>The world's most popular sport. Teamwork and skill combine.</p></div></div></div>
                 <div class="col-md-6 col-lg-3"><div class="sport-card animate__animated animate__zoomIn" style="animation-delay: 0.4s;"><img src="images/basketball.jpg" alt="Basketball" class="img-fluid rounded-3"><div class="sport-info"><h4>Basketball</h4><p>High-flying action and strategic gameplay on the court.</p></div></div></div>
                 <div class="col-md-6 col-lg-3"><div class="sport-card animate__animated animate__zoomIn" style="animation-delay: 0.6s;"><img src="images/badminton.jpg" alt="Badminton" class="img-fluid rounded-3"><div class="sport-info"><h4>Badminton</h4><p>Fast-paced and exciting, a perfect sport for all ages.</p></div></div></div>
                 <div class="col-md-6 col-lg-3"><div class="sport-card animate__animated animate__zoomIn" style="animation-delay: 0.8s;"><img src="images/volleyball.jpg" alt="Volleyball" class="img-fluid rounded-3"><div class="sport-info"><h4>Volleyball</h4><p>Team sport where players use their hands to hit a ball over a net.</p></div></div></div>
                 <div class="col-md-6 col-lg-3"><div class="sport-card animate__animated animate__zoomIn" style="animation-delay: 1s;"><img src="images/tennis.jpg" alt="Tennis" class="img-fluid rounded-3"><div class="sport-info"><h4>Tennis</h4><p>A racket sport that can be played individually against a single opponent (singles) or between two teams of two players each (doubles).</p></div></div></div>
                <div class="col-md-6 col-lg-3"><div class="sport-card animate__animated animate__zoomIn" style="animation-delay: 1.2s;"><img src="images/kabaddi.jpg" alt="Kabaddi" class="img-fluid rounded-3"><div class="sport-info"><h4>Kabaddi</h4><p>A contact team sport played between two teams of seven players.</p></div></div></div>
                <div class="col-md-6 col-lg-3"><div class="sport-card animate__animated animate__zoomIn" style="animation-delay: 1.4s;"><img src="images/chess.jpg" alt="Chess" class="img-fluid rounded-3"><div class="sport-info"><h4>Chess</h4><p>A two-player strategy board game played on a checkered board with 64 squares arranged in an 8×8 grid.</p></div></div></div>
             </div>
        </section>

    </main>
    
    <section class="stats-section my-5">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 stat-item">
                    <span class="stat-number" data-target="50">0</span>+
                    <p class="stat-label">Tournaments Hosted</p>
                </div>
                <div class="col-lg-3 col-md-6 stat-item">
                    <span class="stat-number" data-target="2500">0</span>+
                    <p class="stat-label">Registered Players</p>
                </div>
                <div class="col-lg-3 col-md-6 stat-item">
                    <span class="stat-number" data-target="8">0</span>
                    <p class="stat-label">Sports Categories</p>
                </div>
                <div class="col-lg-3 col-md-6 stat-item">
                    <span class="stat-number" data-target="500000">0</span>+
                    <p class="stat-label">Prizes Won (in Rs.)</p>
                </div>
            </div>
        </div>
    </section>

    <div class="container my-5">
        <section class="my-5 py-5">
            <h2 class="section-title text-center animate__animated animate__fadeIn">What Our Players Say</h2>
            <div class="row g-4 mt-5">
                <div class="col-lg-4 col-md-6">
                    <div class="testimonial-card card-hover-glow animate__animated animate__fadeInUp" style="animation-delay: 0.2s;">
                        <img src="images/player1.jpg" alt="Player">
                        <div class="stars"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i></div>
                        <p class="text-muted">"KridaArena made it so easy to find and join a local cricket tournament. The entire process was smooth and professional. Highly recommended!"</p>
                        <p class="author mt-3">- Rohan Sharma, Team Captain</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                     <div class="testimonial-card card-hover-glow animate__animated animate__fadeInUp" style="animation-delay: 0.4s;">
                        <img src="images/player2.jpg" alt="Player">
                        <div class="stars"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-half"></i></div>
                        <p class="text-muted">"A fantastic platform for all sports lovers. We found the perfect football championship for our team. Great management and support."</p>
                        <p class="author mt-3">- Priya Desai, Football Player</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                     <div class="testimonial-card card-hover-glow animate__animated animate__fadeInUp" style="animation-delay: 0.6s;">
                        <img src="images/player3.jpg" alt="Player">
                        <div class="stars"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i></div>
                        <p class="text-muted">"I participated in the state chess tournament through this site. Everything was well-organized. Looking forward to more events."</p>
                        <p class="author mt-3">- Ankit Mehta, Chess Enthusiast</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="cta-section text-center my-5 animate__animated animate__zoomIn">
            <div class="container">
                <h2 class="display-5 fw-bold">Ready to Compete?</h2>
                <p class="lead my-3">Your next challenge is just a click away. Browse through dozens of tournaments and find the one that's right for you.</p>
                <a href="tournaments.php" class="btn btn-light btn-lg fw-bold px-5 py-3 mt-3">Join a Tournament Now</a>
            </div>
        </section>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="../js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const counters = document.querySelectorAll('.stat-number');
            const speed = 200;

            const observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const counter = entry.target;
                        const updateCount = () => {
                            const target = +counter.getAttribute('data-target');
                            const count = +counter.innerText;
                            const inc = Math.ceil(target / speed);

                            if (count < target) {
                                counter.innerText = count + inc;
                                setTimeout(updateCount, 15);
                            } else {
                                counter.innerText = target;
                            }
                        };
                        updateCount();
                        observer.unobserve(counter); 
                    }
                });
            }, {
                threshold: 0.5 
            });
            
            counters.forEach(counter => {
                observer.observe(counter);
            });
        });
    </script>
</body>
</html>