<?php
session_start();
require_once 'config/db.php';
$page_title = "FAQs | KridaArena";

$faqs = [];
$faq_query = "SELECT question, answer FROM faqs ORDER BY id ASC";
$result = $conn->query($faq_query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $faqs[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>    
    <style>
        .section-title {
            position: relative;
            padding-bottom: 15px;
            margin-bottom: 30px;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            border-radius: 2px;
        }
        .accordion-item {
            border: 1px solid rgba(0, 0, 0, 0.125);
            margin-bottom: 10px;
            border-radius: 0.25rem;
        }
        .accordion-button {
            font-weight: bold;
            color: #333;
            background-color: #f8f9fa;
        }
        .accordion-body {
            background-color: #fff;
        }
    </style>
</head>
<body>
    <?php include 'includes/navbar.php'; ?>
    <header class="hero short">
        <div class="container text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown">Frequently Asked Questions (FAQs)</h1>
            <p class="hero-subtitle animate__animated animate__fadeIn">Find answers to the most common questions about KridaArena.</p>
        </div>
    </header>

    <main class="container my-5">
        <section class="my-5">
            <h2 class="section-title text-center animate__animated animate__fadeIn">General Questions</h2>
            <div class="accordion" id="faqAccordion">
                <?php if (!empty($faqs)): ?>
                    <?php foreach ($faqs as $index => $faq): ?>
                    <div class="accordion-item animate__animated animate__fadeInUp" style="animation-delay: <?= $index * 0.2 ?>s;">
                        <h2 class="accordion-header" id="heading<?= $index ?>">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $index ?>" aria-expanded="false" aria-controls="collapse<?= $index ?>">
                                <?= htmlspecialchars($faq['question']) ?>
                            </button>
                        </h2>
                        <div id="collapse<?= $index ?>" class="accordion-collapse collapse" aria-labelledby="heading<?= $index ?>" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                <p><?= htmlspecialchars($faq['answer']) ?></p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-center text-muted">No FAQs found.</p>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>
    <script src="js/bootstrap.bundle.min.js"></script>
    <?php
    if (isset($_SESSION['alert'])): 
        $alert = $_SESSION['alert'];
    ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: '<?= htmlspecialchars($alert['type']) ?>',
                    title: '<?= htmlspecialchars($alert['title']) ?>',
                    text: '<?= htmlspecialchars($alert['text']) ?>',
                });
            });
        </script>
    <?php 
        unset($_SESSION['alert']);
    endif; 
    ?>
</body>
</html>