<?php
session_start();
require_once 'config/db.php';
$page_title = "FAQs | KridaArena";

$faqs = [
    ['question' => 'How can I register for a tournament?', 'answer' => 'You can register by visiting the "Tournaments" page, selecting the event you want, and filling out the registration form. Make sure you are logged in to complete the process.'],
    ['question' => 'Is there a fee to join tournaments?', 'answer' => 'Most tournaments on KridaArena have a small registration fee, which contributes to the prize pool and event organization. Details are listed on each tournament\'s page.'],
    ['question' => 'What kind of gear can I find in the shop?', 'answer' => 'Our shop features a wide range of gear for various sports, including cricket bats, footballs, rackets, apparel, and protective equipment from top brands.'],
    ['question' => 'How are tournament winners decided?', 'answer' => 'Winners are determined based on the official rules of each tournament. We use a fair and transparent system, and results are updated in real-time on the tournament brackets page.'],
    ['question' => 'Can I host my own tournament on KridaArena?', 'answer' => 'Yes, we offer tools for organizers to host their own events. You can contact us through the "Contact" page for more information and to get started.'],
    ['question' => 'What payment methods are accepted for tournament fees?', 'answer' => 'We accept a variety of payment methods, including credit/debit cards, net banking, and popular digital wallets. All transactions are secure and encrypted.'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>
    
    <style>
        .section-title {
            position: relative;
            padding-bottom: 15px;
            margin-bottom: 30px;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            border-radius: 2px;
        }
        .accordion-item {
            border: none;
            border-radius: 15px;
            margin-bottom: 15px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }
        .accordion-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
        .accordion-button:not(.collapsed) {
            background-color: #f848d2;
            color: #fff;
            font-weight: bold;
            border-bottom: 1px solid rgba(0, 0, 0, 0.125);
        }
        .accordion-button {
            border-radius: 15px !important;
            padding: 1.5rem;
            font-weight: bold;
            color: #2c293d;
            background-color: #fff;
        }
        .accordion-button:not(.collapsed)::after {
            background-image: var(--bs-accordion-btn-icon);
            filter: brightness(0) invert(1);
        }
        .accordion-body {
            background-color: #f9f9f9;
            color: #555;
            padding: 1.5rem;
            border-bottom-left-radius: 15px;
            border-bottom-right-radius: 15px;
        }
        /* Consistent Hero section styling from about.php */
        .hero.short {
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            padding: 70px 0;
            text-align: center;
            color: #fff;
            border-bottom-left-radius: 40px;
            border-bottom-right-radius: 40px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
            margin-bottom: 50px;
        }
    </style>
</head>
<body>
    <?php include 'includes/navbar.php'; ?>

    <header class="hero short">
        <div class="container text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown">FAQs</h1>
            <p class="hero-subtitle animate__animated animate__fadeInUp">Find answers to the most common questions about KridaArena.</p>
        </div>
    </header>

    <main class="container my-5">
        <section class="my-5">
            <h2 class="section-title text-center animate__animated animate__fadeIn">General Questions</h2>
            <div class="accordion" id="faqAccordion">
                <?php foreach ($faqs as $index => $faq): ?>
                <div class="accordion-item animate__animated animate__fadeInUp" style="animation-delay: <?= $index * 0.2 ?>s;">
                    <h2 class="accordion-header" id="heading<?= $index ?>">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?= $index ?>" aria-expanded="false" aria-controls="collapse<?= $index ?>">
                            <?= htmlspecialchars($faq['question']) ?>
                        </button>
                    </h2>
                    <div id="collapse<?= $index ?>" class="accordion-collapse collapse" aria-labelledby="heading<?= $index ?>" data-bs-parent="#faqAccordion">
                        <div class="accordion-body">
                            <p><?= htmlspecialchars($faq['answer']) ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>