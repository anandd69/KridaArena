<?php
session_start();
require_once 'config/db.php'; 
$msg = "";
$welcomeText = "Welcome! Please Login";
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $pass  = trim($_POST['password']);
    if (empty($email) || empty($pass)) {
        $msg = "<div class='alert alert-danger mt-2'>Email and password cannot be empty.</div>";
    } else {
        $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email = ?");
        if ($stmt === false) {
            $msg = "<div class='alert alert-danger mt-2'>Database error: " . $conn->error . "</div>";
        } else {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                if (password_verify($pass, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    header("Location: index.php");
                    exit();
                } else {
                    $msg = "<div class='alert alert-danger mt-2'>Incorrect password.</div>";
                }
            } else {
                $msg = "<div class='alert alert-danger mt-2'>No account found with that email.</div>";
            }
        }
    }
}
$page_title = "Login | KridaArena";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>
    <style>
        body {
            background: linear-gradient(120deg, #ec7c20ff, #f848d2ff); 
            min-height: 100vh; 
            display: flex; 
            flex-direction: column; 
            justify-content: center;
        }
        .login-box {
            background: #fff;
            padding: 35px;
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(248,72,210,0.5), 0 0 40px rgba(236,124,32,0.4);
        }
        .login-title {
            text-align: center;
            font-size: 2rem;
            font-weight: 700;
            color: #333;
            margin-bottom: 1rem;
        }
        .login-link {
            color: #f848d2ff;
            text-decoration: none;
            font-weight: 500;
        }
        .login-link:hover {
            text-decoration: underline;
            color: #ec7c20ff;
        }
        .alert {
            font-size: 14px;
            border-radius: 10px;
            padding: 8px 12px;
        }
    </style>
</head>
<body class="d-flex flex-column justify-content-center">
    <div class="container my-5">
        <div class="login-box mx-auto" style="max-width: 500px;">
            <div class="login-title">Welcome! Please Login</div>
            <?= $msg ?>
            <form method="POST" autocomplete="off">
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" placeholder="Enter your email" required />
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Enter your password" required />
                </div>
                <button type="submit" class="btn btn-animate w-100 mt-3">Login</button>
                <div class="text-center mt-3">
                    Don't have an account? <a href="register.php" class="login-link">Register here</a>
                </div>
            </form>
        </div>
    </div>
    <?php include("includes/footer.php"); ?>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>