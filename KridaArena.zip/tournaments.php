<?php
session_start();
require_once 'config/db.php';
$page_title = "Tournaments | KridaArena";
$tournaments = [
    'cricket' => [
        'name' => 'Cricket Premier League',
        'registration_date' => '25 Sep - 15 Oct, 2025',
        'venue' => 'Ahmedabad Stadium',
        'fees' => 'Rs. 5,000 per team',
        'team_limit' => 10,
        'player_count' => 11,
        'type' => 'team',
        'status' => 'active',
        'prizes' => [
            'Winner Team: Rs. 20,000',
            'Runner-up Team: Rs. 10,000',
            'Player of the Match (Finals): Rs. 2,000'
        ]
    ],
    'football' => [
        'name' => 'Football Championship',
        'registration_date' => '10 Oct - 30 Oct, 2025',
        'venue' => 'Urban Football Ground',
        'fees' => 'Rs. 4,000 per team',
        'team_limit' => 8,
        'player_count' => 7,
        'type' => 'team',
        'status' => 'active',
        'prizes' => [
            'Winner Team: Rs. 15,000',
            'Runner-up Team: Rs. 7,500',
            'Golden Boot (Top Scorer): Rs. 1,500'
        ]
    ],
    'chess' => [
        'name' => 'State Chess Tournament',
        'registration_date' => '1 Nov - 20 Nov, 2025',
        'venue' => 'City Community Hall',
        'fees' => 'Rs. 1,000 per player',
        'team_limit' => 20, // For single player sports, this is the player limit
        'player_count' => 1,
        'type' => 'single',
        'status' => 'active',
        'prizes' => [
            '1st Place: Rs. 8,000',
            '2nd Place: Rs. 4,000',
            '3rd Place: Rs. 2,000'
        ]
    ],
    'basketball' => [
        'name' => 'Basketball Slam Fest',
        'registration_date' => '5 Nov - 25 Nov, 2025',
        'venue' => 'City Sports Complex',
        'fees' => 'Rs. 3,500 per team',
        'team_limit' => 12,
        'player_count' => 5,
        'type' => 'team',
        'status' => 'coming_soon',
        'prizes' => [
            'Winner Team: Rs. 12,000',
            'Runner-up: Rs. 6,000',
            'MVP (Most Valuable Player): Rs. 1,000'
        ]
    ],
    'volleyball' => [
        'name' => 'Volleyball League',
        'registration_date' => '1 Dec - 20 Dec, 2025',
        'venue' => 'Beach Side Court',
        'fees' => 'Rs. 2,800 per team',
        'team_limit' => 15,
        'player_count' => 6,
        'type' => 'team',
        'status' => 'coming_soon',
        'prizes' => [
            'Winner Team: Rs. 10,000',
            'Runner-up: Rs. 5,000'
        ]
    ],
    'tennis' => [
        'name' => 'City Tennis Open',
        'registration_date' => '15 Dec - 5 Jan, 2026',
        'venue' => 'Royal Tennis Club',
        'fees' => 'Rs. 1,500 per player',
        'team_limit' => 30, 
        'player_count' => 1,
        'type' => 'single',
        'status' => 'coming_soon',
        'prizes' => [
            'Winner: Rs. 10,000',
            'Runner-up: Rs. 5,000'
        ]
    ],
    'badminton' => [
        'name' => 'Badminton Championship',
        'registration_date' => '2 Jan - 20 Jan, 2026',
        'venue' => 'Indoor Sports Arena',
        'fees' => 'Rs. 1,200 per player',
        'team_limit' => 25,
        'player_count' => 1,
        'type' => 'single',
        'status' => 'active',
        'prizes' => [
            'Winner: Rs. 8,000',
            'Runner-up: Rs. 4,000'
        ]
    ],
    'kabaddi' => [
        'name' => 'Kabaddi Masters Cup',
        'registration_date' => '1 Feb - 20 Feb, 2026',
        'venue' => 'Local Sports Ground',
        'fees' => 'Rs. 4,500 per team',
        'team_limit' => 10,
        'player_count' => 7,
        'type' => 'team',
        'status' => 'coming_soon',
        'prizes' => [
            'Winner Team: Rs. 18,000',
            'Runner-up Team: Rs. 9,000',
            'Best Raider: Rs. 2,000'
        ]
    ],
];
foreach ($tournaments as $key => $tournament) {
    $tournaments[$key]['current_teams'] = 0;
    $tournaments[$key]['full'] = false;
    if ($tournament['status'] === 'active') {
        $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM registrations WHERE sport_type=?");
        $stmt->bind_param("s", $key);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $tournaments[$key]['current_teams'] = $res['total'];
        $tournaments[$key]['full'] = ($res['total'] >= $tournament['team_limit']);
    }
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $sport_type = $_POST['sport_type'];
    $response = ['status' => 'error', 'message' => ''];
    if (!isset($_SESSION['user_id'])) {
        $response['message'] = "Please log in to register for a tournament.";
        echo json_encode($response);
        exit();
    }
    $user_id = $_SESSION['user_id'];

    if (isset($tournaments[$sport_type]) && $tournaments[$sport_type]['status'] === 'active') {
        $tour = $tournaments[$sport_type];

        $stmt_check = $conn->prepare("SELECT COUNT(*) AS total FROM registrations WHERE sport_type=?");
        $stmt_check->bind_param("s", $sport_type);
        $stmt_check->execute();
        $res_check = $stmt_check->get_result()->fetch_assoc();
        
        if ($res_check['total'] >= $tour['team_limit']) {
            $response['message'] = "Sorry, registration for {$tour['name']} is now full.";
        } else {
            $stmt_already_registered = $conn->prepare("SELECT COUNT(*) FROM registrations WHERE user_id = ? AND sport_type = ?");
            $stmt_already_registered->bind_param("is", $user_id, $sport_type);
            $stmt_already_registered->execute();
            $reg_count = $stmt_already_registered->get_result()->fetch_array()[0];
            $stmt_already_registered->close();
            if ($reg_count > 0) {
                $response['message'] = "You have already registered for this tournament.";
                echo json_encode($response);
                exit();
            }
            $team_name = ($tour['type'] === "team") ? $_POST['team_name'] : $_POST['players'][1]['name'];
            $players_json = json_encode($_POST['players'], JSON_UNESCAPED_UNICODE);
            $payment_method = $_POST['payment_method'];
            $transaction_id = $_POST['transaction_id'];
            $reg_date = date("Y-m-d H:i:s");
            $stmt = $conn->prepare("INSERT INTO registrations (sport_type, team_name, players_data, payment_method, transaction_id, registration_date, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssi", $sport_type, $team_name, $players_json, $payment_method, $transaction_id, $reg_date, $user_id);

            if ($stmt->execute()) {
                $response['status'] = 'success';
                $response['message'] = "Successfully registered for {$tour['name']}! Your registration is pending payment verification.";
            } else {
                $response['message'] = "Error: " . $stmt->error;
            }
        }
    } else {
        $response['message'] = "Invalid tournament.";
    }

    echo json_encode($response);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $page_title ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        @keyframes glowing-text-dynamic {
            0% { box-shadow: 0 0 5px #f848d2, 0 0 10px #f848d2, 0 0 15px #f848d2; }
            50% { box-shadow: 0 0 20px #ec7c20, 0 0 30px #ec7c20, 0 0 40px #ec7c20; }
            100% { box-shadow: 0 0 5px #f848d2, 0 0 10px #f848d2, 0 0 15px #f848d2; }
        }

        .hero { background: linear-gradient(90deg, #ec7c20ff, #f848d2ff); padding: 70px; text-align: center; border-bottom-left-radius: 40px; border-bottom-right-radius: 40px; box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3); } .tournament-card { background: #fff; color: #222; padding: 25px; border-radius: 15px; transition: 0.3s; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; height: 100%; } .tournament-card-body { flex-grow: 1; } .tournament-card:hover { transform: translateY(-5px); box-shadow: 0 0 20px rgba(236,124,32,0.6); } .tournament-card h5 { font-size: 1.5rem; font-weight: bold; color: #2c293d; } .prize-list { list-style-type: none; padding-left: 0; font-size: 0.9rem; } .prize-list li::before { content: '🏆'; margin-right: 8px; } .register-btn { background: linear-gradient(45deg, #f848d2ff, #ec7c20ff); border: none; color: #fff; padding: 10px 20px; border-radius: 25px; font-weight: bold; transition: 0.3s; box-shadow: 0 0 5px rgba(248, 72, 210, 0.5); } .register-btn:hover { transform: scale(1.05); box-shadow: 0 0 15px rgba(248, 72, 210, 0.8); } .coming-soon-badge { background: #2c293d; color: #fff; padding: 10px 20px; border-radius: 25px; font-weight: bold; text-align: center; animation: glowing-text-dynamic 1.5s infinite ease-in-out; } .modal-content { border-radius: 20px; color: #2c293d; background-color: #f8f9fa; } .btn-submit-form { background: #2c293d; color: #fff; border: none; padding: 12px 25px; border-radius: 25px; font-weight: bold; transition: all 0.3s ease; } .btn-submit-form:hover { background: #ec7c20ff; } .player-fields { border: 1px solid #dee2e6; transition: all 0.3s ease; } .player-fields:hover { border-color: #ec7c20ff; } .payment-instructions { background-color: #e9ecef; border-left: 4px solid #ec7c20ff; padding: 15px; border-radius: 8px; font-size: 0.9rem; }
    </style>
</head>
<body>
<?php include "includes/navbar.php"; ?>

<header class="hero">
    <h1 class="animate__animated animate__fadeInDown">Join a Tournament</h1>
    <p class="animate__animated animate__fadeInUp">Register your team or as a player</p>
</header>

<main class="container my-5">
    <div class="row g-4">
        <?php foreach ($tournaments as $key => $t): ?>
        <div class="col-md-4 animate__animated animate__zoomIn">
            <div class="tournament-card">
                <div class="tournament-card-body">
                    <h5><?= $t['name'] ?></h5>
                    <p><b>Registration:</b> <?= $t['registration_date'] ?></p>
                    <p><b>Venue:</b> <?= $t['venue'] ?></p>
                    <p><b>Fees:</b> <?= $t['fees'] ?></p>

                    <?php if (isset($t['prizes']) && !empty($t['prizes'])): ?>
                        <p class="mb-1"><b>Prizes:</b></p>
                        <ul class="prize-list">
                            <?php foreach ($t['prizes'] as $prize): ?>
                                <li><?= $prize ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>

                <div class="mt-auto">
                    <?php if ($t['status'] === 'coming_soon'): ?>
                        <div class="coming-soon-badge w-100">Coming Soon</div>
                    <?php else: ?>
                        <p class="text-center mb-2">
                            <b>Slots Filled:</b> <?= $t['current_teams'] ?> / <?= $t['team_limit'] ?>
                        </p>
                        <?php if ($t['full']): ?>
                            <button class="btn btn-secondary w-100" disabled>Registration Full</button>
                        <?php else: ?>
                            <button class="register-btn w-100" data-bs-toggle="modal" data-bs-target="#regModal-<?= $key ?>">Register Now</button>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="modal fade" id="regModal-<?= $key ?>" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content p-4">
                    <div class="modal-header border-0 pb-0">
                        <h5 class="modal-title">Register for <?= $t['name'] ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body pt-2">
                        <form method="POST" id="regForm-<?= $key ?>">
                            <input type="hidden" name="sport_type" value="<?= $key ?>">
                            
                            <?php if ($t['type'] === "team"): ?>
                                <div class="mb-3"><label class="form-label">Team Name</label><input type="text" name="team_name" class="form-control" required></div><hr class="my-4">
                            <?php endif; ?>
                            <?php for ($i = 1; $i <= $t['player_count']; $i++): ?>
                                <div class="player-fields p-3 mb-3 rounded">
                                <h6 class="text-primary"><?= ($t['type'] === "team") ? "Player $i" : "Your Details" ?></h6>
                                <div class="row g-2">
                                    <div class="col-md-6"><input type="text" class="form-control mb-2" name="players[<?= $i ?>][name]" placeholder="Full Name" required></div>
                                    <div class="col-md-3"><input type="number" class="form-control mb-2" name="players[<?= $i ?>][age]" placeholder="Age" required></div>
                                    <div class="col-md-3"><select class="form-select mb-2" name="players[<?= $i ?>][gender]" required><option value="" disabled selected>Gender</option><option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option></select></div>
                                    <div class="col-md-6"><input type="email" class="form-control mb-2" name="players[<?= $i ?>][email]" placeholder="Email" required></div>
                                    <div class="col-md-6"><input type="text" class="form-control mb-2" name="players[<?= $i ?>][aadhaar]" placeholder="Aadhaar Card No." required></div>
                                    <div class="col-md-12"><input type="text" class="form-control mb-2" name="players[<?= $i ?>][from]" placeholder="Place (From)" required></div>
                                </div>
                                </div>
                            <?php endfor; ?>

                            <hr class="my-4">
                            <h5 class="mb-3">Payment Details</h5>
                            
                            <div class="payment-instructions mb-3">
                                <p class="mb-1">Please pay the registration fee of <b><?= $t['fees'] ?></b> to the UPI ID below and enter the Transaction ID.</p>
                                <p class="mb-0 fw-bold">UPI ID: <span class="text-primary">kridaarena@upi</span></p>
                            </div>

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Payment Method</label>
                                    <select name="payment_method" class="form-select" required>
                                        <option value="UPI" selected>UPI</option>
                                        <option value="Bank Transfer">Bank Transfer</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Transaction ID</label>
                                    <input type="text" name="transaction_id" class="form-control" placeholder="Enter UTR / Transaction ID" required>
                                </div>
                            </div>
                            
                            <button type="submit" class="btn btn-submit-form w-100 mt-4">Submit Registration</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</main>

<?php include "includes/footer.php"; ?>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/sweetalert2@11.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                const formData = new FormData(this);
                fetch(this.action, { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Registration Submitted!',
                            text: data.message,
                            timer: 3000,
                            showConfirmButton: false
                        }).then(() => {
                            window.location.reload(); 
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: data.message,
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'An error occurred. Please try again.',
                    });
                });
            });
        });
    });
</script>
</body>
</html>