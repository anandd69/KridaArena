<?php
session_start();
require_once 'config/db.php';
$page_title = "Tournaments | KridaArena";

$all_tournaments_db = [];
$tournament_query = "SELECT * FROM tournaments ORDER BY tournament_id DESC";
$result = $conn->query($tournament_query);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $key = $row['sport']; 
        $all_tournaments_db[$key] = $row;
    }
}

$tournaments = [];
foreach ($all_tournaments_db as $sport_key => $t) {
    $tournaments[$sport_key] = [
        'name'              => $t['name'],
        'registration_date' => date('M d', strtotime($t['registration_start_date'])) . ' - ' . date('M d, Y', strtotime($t['registration_end_date'])),
        'venue'             => $t['venue'],
        'fees'              => 'Rs. ' . number_format($t['fees'], 0) . (($t['type'] == 'team' || $t['type'] == 'solo') ? ' per ' . $t['type'] : ''), 
        'team_limit'        => (int)$t['team_limit'],
        'player_count'      => (int)$t['players_per_team'],
        'type'              => $t['type'],
        'status'            => $t['status'],
        'prizes'            => explode("\n", $t['prizes']),
        'tournament_id'     => $t['tournament_id'] 
    ];
}
foreach ($tournaments as $key => $tournament) {
    $tournaments[$key]['current_teams'] = 0;
    $tournaments[$key]['full'] = false;
    if ($tournament['status'] === 'active') {
        $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM registrations WHERE sport_type=?");
        $stmt->bind_param("s", $key); 
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $tournaments[$key]['current_teams'] = $res['total'];
        $tournaments[$key]['full'] = ($res['total'] >= $tournament['team_limit']);
        $stmt->close(); 
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $sport_type = $_POST['sport_type'];
    $response = ['status' => 'error', 'message' => ''];
    if (!isset($_SESSION['user_id'])) {
        $response['message'] = "Please log in to register for a tournament.";
        echo json_encode($response);
        exit();
    }
    $user_id = $_SESSION['user_id'];
    if (isset($tournaments[$sport_type]) && $tournaments[$sport_type]['status'] === 'active') {
        $tour = $tournaments[$sport_type];
        $stmt_check = $conn->prepare("SELECT COUNT(*) AS total FROM registrations WHERE sport_type=?");
        $stmt_check->bind_param("s", $sport_type);
        $stmt_check->execute();
        $res_check = $stmt_check->get_result()->fetch_assoc();
        $stmt_check->close(); 

        if ($res_check['total'] >= $tour['team_limit']) {
            $response['message'] = "Sorry, registration for {$tour['name']} is now full.";
        } else {
            $stmt_already_registered = $conn->prepare("SELECT COUNT(*) FROM registrations WHERE user_id = ? AND sport_type = ?");
            $stmt_already_registered->bind_param("is", $user_id, $sport_type);
            $stmt_already_registered->execute();
            $reg_count = $stmt_already_registered->get_result()->fetch_array()[0];
            $stmt_already_registered->close();
            
            if ($reg_count > 0) {
                $response['message'] = "You have already registered for this tournament.";
                echo json_encode($response);
                exit();
            }
            $team_name = ($tour['type'] === "team") ? $_POST['team_name'] : $_POST['players'][1]['name'];
            $players_json = json_encode($_POST['players'], JSON_UNESCAPED_UNICODE);
            $payment_method = $_POST['payment_method'];
            $transaction_id = ($payment_method === 'Online Payment') ? ($_POST['transaction_id'] ?? '') : '';
            $reg_date = date("Y-m-d H:i:s");
            
            $stmt = $conn->prepare("INSERT INTO registrations (sport_type, team_name, players_data, payment_method, transaction_id, registration_date, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssi", $sport_type, $team_name, $players_json, $payment_method, $transaction_id, $reg_date, $user_id);

            if ($stmt->execute()) {
                $response['status'] = 'success';
                if ($payment_method === 'COD') {
                     $response['message'] = "Successfully registered for {$tour['name']}! Payment is due upon arrival.";
                } else {
                    $response['message'] = "Successfully registered for {$tour['name']}! Your registration is pending payment verification.";
                }
            } else {
                $response['message'] = "Error: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        $response['message'] = "Invalid tournament or registration is not active.";
    }

    echo json_encode($response);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $page_title ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        @keyframes glowing-text-dynamic {
            0% { box-shadow: 0 0 5px #f848d2, 0 0 10px #f848d2, 0 0 15px #f848d2; }
            50% { box-shadow: 0 0 20px #ec7c20, 0 0 30px #ec7c20, 0 0 40px #ec7c20; }
            100% { box-shadow: 0 0 5px #f848d2, 0 0 10px #f848d2, 0 0 15px #f848d2; }
        }

        .hero { background: linear-gradient(90deg, #ec7c20ff, #f848d2ff); padding: 70px; text-align: center; border-bottom-left-radius: 40px; border-bottom-right-radius: 40px; box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3); } .tournament-card { background: #fff; color: #222; padding: 25px; border-radius: 15px; transition: 0.3s; box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1); display: flex; flex-direction: column; height: 100%; } .tournament-card-body { flex-grow: 1; } .tournament-card:hover { transform: translateY(-5px); box-shadow: 0 0 20px rgba(236,124,32,0.6); } .tournament-card h5 { font-size: 1.5rem; font-weight: bold; color: #2c293d; } .prize-list { list-style-type: none; padding-left: 0; font-size: 0.9rem; } .prize-list li::before { content: '🏆'; margin-right: 8px; } .register-btn { background: linear-gradient(45deg, #f848d2ff, #ec7c20ff); border: none; color: #fff; padding: 10px 20px; border-radius: 25px; font-weight: bold; transition: 0.3s; box-shadow: 0 0 5px rgba(248, 72, 210, 0.5); } .register-btn:hover { transform: scale(1.05); box-shadow: 0 0 15px rgba(248, 72, 210, 0.8); } .coming-soon-badge { background: #2c293d; color: #fff; padding: 10px 20px; border-radius: 25px; font-weight: bold; text-align: center; animation: glowing-text-dynamic 1.5s infinite ease-in-out; } .modal-content { border-radius: 20px; color: #2c293d; background-color: #f8f9fa; } .btn-submit-form { background: #2c293d; color: #fff; border: none; padding: 12px 25px; border-radius: 25px; font-weight: bold; transition: all 0.3s ease; } .btn-submit-form:hover { background: #ec7c20ff; } .player-fields { border: 1px solid #dee2e6; transition: all 0.3s ease; } .player-fields:hover { border-color: #ec7c20ff; } .payment-instructions { background-color: #e9ecef; border-left: 4px solid #ec7c20ff; padding: 15px; border-radius: 8px; font-size: 0.9rem; }
        .hidden { display: none; } 
    </style>
</head>
<body>
<?php include "includes/navbar.php"; ?>

<header class="hero">
    <h1 class="animate__animated animate__fadeInDown">Join a Tournament</h1>
    <p class="animate__animated animate__fadeInUp">Register your team or as a player</p>
</header>

<main class="container my-5">
    <div class="row g-4">
        <?php foreach ($tournaments as $key => $t): ?>
        <div class="col-md-4 animate__animated animate__zoomIn">
            <div class="tournament-card">
                <div class="tournament-card-body">
                    <h5><?= $t['name'] ?></h5>
                    <p><b>Registration:</b> <?= $t['registration_date'] ?></p>
                    <p><b>Venue:</b> <?= $t['venue'] ?></p>
                    <p><b>Fees:</b> <?= $t['fees'] ?></p>

                    <?php if (isset($t['prizes']) && !empty(array_filter($t['prizes']))): ?>
                        <p class="mb-1"><b>Prizes:</b></p>
                        <ul class="prize-list">
                            <?php foreach (array_filter($t['prizes']) as $prize): ?>
                                <li><?= htmlspecialchars(trim($prize)) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>

                <div class="mt-auto">
                    <?php if ($t['status'] === 'coming_soon'): ?>
                        <div class="coming-soon-badge w-100">Coming Soon</div>
                    <?php else: ?>
                        <p class="text-center mb-2">
                            <b>Slots Filled:</b> <?= $t['current_teams'] ?> / <?= $t['team_limit'] ?>
                        </p>
                        <?php if ($t['full']): ?>
                            <button class="btn btn-secondary w-100" disabled>Registration Full</button>
                        <?php else: ?>
                            <button class="register-btn w-100" data-bs-toggle="modal" data-bs-target="#regModal-<?= $key ?>">Register Now</button>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="modal fade" id="regModal-<?= $key ?>" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content p-4">
                    <div class="modal-header border-0 pb-0">
                        <h5 class="modal-title">Register for <?= $t['name'] ?></h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body pt-2">
                        <form method="POST" id="regForm-<?= $key ?>">
                            <input type="hidden" name="sport_type" value="<?= $key ?>">
                            
                            <?php if ($t['type'] === "team"): ?>
                                <div class="mb-3"><label class="form-label">Team Name</label><input type="text" name="team_name" class="form-control" required></div><hr class="my-4">
                            <?php endif; ?>
                            <?php for ($i = 1; $i <= $t['player_count']; $i++): ?>
                                <div class="player-fields p-3 mb-3 rounded">
                                <h6 class="text-primary"><?= ($t['type'] === "team") ? "Player $i" : "Your Details" ?></h6>
                                <div class="row g-2">
                                    <div class="col-md-6"><input type="text" class="form-control mb-2" name="players[<?= $i ?>][name]" placeholder="Full Name" required></div>
                                    <div class="col-md-3"><input type="number" class="form-control mb-2" name="players[<?= $i ?>][age]" placeholder="Age" required></div>
                                    <div class="col-md-3"><select class="form-select mb-2" name="players[<?= $i ?>][gender]" required><option value="" disabled selected>Gender</option><option value="Male">Male</option><option value="Female">Female</option><option value="Other">Other</option></select></div>
                                    <div class="col-md-6"><input type="email" class="form-control mb-2" name="players[<?= $i ?>][email]" placeholder="Email" required></div>
                                    <div class="col-md-6"><input type="text" class="form-control mb-2" name="players[<?= $i ?>][aadhaar]" placeholder="Aadhaar Card No." required></div>
                                    <div class="col-md-12"><input type="text" class="form-control mb-2" name="players[<?= $i ?>][from]" placeholder="Place (From)" required></div>
                                </div>
                                </div>
                            <?php endfor; ?>

                            <hr class="my-4">
                            <h5 class="mb-3">Payment Method (Registration Fee: <?= $t['fees'] ?>)</h5>
                            
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" id="cod-<?= $key ?>" value="COD" checked>
                                    <label class="form-check-label" for="cod-<?= $key ?>">
                                        Cash on Arrival (Pay at Venue)
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" id="online-<?= $key ?>" value="Online Payment">
                                    <label class="form-check-label" for="online-<?= $key ?>">
                                        Online Payment (UPI Only)
                                    </label>
                                </div>
                            </div>

                            <div id="onlinePaymentDetails-<?= $key ?>" class="hidden">
                                <hr class="my-4">
                                <h5 class="mb-3">Online Payment Method: UPI</h5>
                                <div id="upi-details" class="payment-details">
                                    <div class="alert alert-info" role="alert">
                                        Please pay the registration fee of <b><?= $t['fees'] ?></b> to the UPI ID below and enter the Transaction ID.
                                        <div class="text-center my-3">
                                            <img src="png/qr.jpeg" class="img-fluid rounded" alt="UPI QR Code" style="max-width: 150px;">
                                        </div>
                                        <div class="input-group">
                                            <span class="input-group-text">UPI ID:</span>
                                            <input type="text" class="form-control" value="kridaarena@upi" readonly>
                                            <button type="button" class="btn btn-outline-secondary" id="copyUpiBtn">
                                                <img src="png/clipboard.png" alt="Copy to Clipboard" style="width: 16px; height: 16px;">
                                                <p> Copy</p>
                                            </button>
                                        </div>

                                    </div>
                                    <div class="mb-3">
                                        <label for="upi_transaction_id-<?= $key ?>" class="form-label">Transaction ID</label>
                                        <input type="text" class="form-control upi_transaction_id_input" id="upi_transaction_id-<?= $key ?>" name="transaction_id" placeholder="Enter your UPI Transaction ID" required disabled>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-submit-form w-100 mt-4">Submit Registration</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</main>

<?php include "includes/footer.php"; ?>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/sweetalert2@11.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.copyUpiBtn').forEach(button => {
            button.addEventListener('click', () => {
                const upiId = button.getAttribute('data-upi-id');
                navigator.clipboard.writeText(upiId).then(() => {
                    Swal.fire({
                        icon: 'success',
                        title: 'Copied!',
                        text: 'UPI ID has been copied to your clipboard.',
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 2000
                    });
                }).catch(err => {
                    console.error('Failed to copy UPI ID: ', err);
                });
            });
        });

        document.querySelectorAll('form').forEach(form => {
            const formId = form.id;
            const key = formId.replace('regForm-', '');
            const codRadio = document.getElementById(`cod-${key}`);
            const onlineRadio = document.getElementById(`online-${key}`);
            const onlinePaymentDetails = document.getElementById(`onlinePaymentDetails-${key}`);
            const upiTransactionIdInput = document.getElementById(`upi_transaction_id-${key}`);

            function updateTransactionIdRequirement() {
                const isOnline = onlineRadio.checked;
                if (upiTransactionIdInput) {
                    upiTransactionIdInput.required = isOnline;
                    upiTransactionIdInput.disabled = !isOnline;
                }
            }

            if (codRadio && onlineRadio) {
                codRadio.addEventListener('change', () => {
                    onlinePaymentDetails.classList.add('hidden');
                    updateTransactionIdRequirement();
                });
                onlineRadio.addEventListener('change', () => {
                    onlinePaymentDetails.classList.remove('hidden');
                    updateTransactionIdRequirement();
                });
                updateTransactionIdRequirement();
            }
            form.addEventListener('submit', function (e) {
                e.preventDefault();
                const formData = new FormData(this);
                if (onlineRadio.checked && !upiTransactionIdInput.value.trim()) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Missing Transaction ID',
                        text: 'Please enter the UPI Transaction ID to submit your online registration.',
                    });
                    return;
                }

                fetch(this.action, { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire({
                            icon: 'success',
                            title: 'Registration Submitted!',
                            text: data.message,
                            timer: 3000,
                            showConfirmButton: false
                        }).then(() => {
                            window.location.reload(); 
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: data.message,
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'An error occurred. Please try again.',
                    });
                });
            });
        });
    });
</script>
</body>
</html>