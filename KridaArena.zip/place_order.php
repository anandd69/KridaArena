<?php
session_start();
require_once 'config/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?msg=Please login to place an order.");
    exit();
}
$user_id = $_SESSION['user_id'];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';
    $zip = $_POST['zip'] ?? '';
    $payment_method = $_POST['paymentMethod'] ?? 'COD';
    $cart_products_to_order = $_SESSION['cart'];
    $total_price = 0;
    if (empty($cart_products_to_order)) {
        header("Location: cart.php?msg=Your cart is empty.");
        exit();
    }
    $product_ids_to_fetch = array_map('intval', array_keys($cart_products_to_order));
    $products_data = [];
    if (!empty($product_ids_to_fetch)) {
        $placeholders = implode(',', array_fill(0, count($product_ids_to_fetch), '?'));
        $stmt = $conn->prepare("SELECT id, name, price FROM products WHERE id IN ($placeholders)");
        $types = str_repeat('i', count($product_ids_to_fetch));
        $stmt->bind_param($types, ...$product_ids_to_fetch);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $products_data[$row['id']] = $row;
        }
        $stmt->close();
    }
    foreach ($cart_products_to_order as $id => $item) {
        if (isset($products_data[$id])) {
            $product = $products_data[$id];
            $total_price += $product['price'] * $item['quantity'];
        }
    }
    $shipping_address_id = null;
    $stmt = $conn->prepare("SELECT id FROM saved_addresses WHERE user_id = ? AND name = ? AND email = ? AND address = ? AND city = ? AND state = ? AND zip = ?");
    $stmt->bind_param("issssss", $user_id, $name, $email, $address, $city, $state, $zip);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $shipping_address_id = $row['id'];
    } else {
        $stmt_insert_address = $conn->prepare("INSERT INTO saved_addresses (user_id, name, email, address, city, state, zip) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt_insert_address->bind_param("issssss", $user_id, $name, $email, $address, $city, $state, $zip);
        $stmt_insert_address->execute();
        $shipping_address_id = $stmt_insert_address->insert_id;
        $stmt_insert_address->close();
    }
    $stmt->close();
    $delivery_date = date('F j, Y', strtotime('+5 days'));
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount, shipping_address_id, payment_method, delivery_date) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("idisss", $user_id, $total_price, $shipping_address_id, $payment_method, $delivery_date);
        $stmt->execute();
        $order_id = $stmt->insert_id;
        $stmt->close();
        $stmt_items = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
        foreach ($cart_products_to_order as $product_id => $item) {
            $product_price = $products_data[$product_id]['price'] ?? 0;
            $stmt_items->bind_param("iiid", $order_id, $product_id, $item['quantity'], $product_price);
            $stmt_items->execute();
        }
        $stmt_items->close();
        foreach (array_keys($cart_products_to_order) as $id) {
            unset($_SESSION['cart'][$id]);
        }
        if ($payment_method == 'COD') {
            $conn->commit();
            $_SESSION['order_success_msg'] = "Your order has been placed successfully! Order ID: #`$order_id`.<br>Estimated Delivery: <strong>$delivery_date</strong>";
            header("Location: checkout.php");
            exit();
        } elseif ($payment_method == 'Online') {
            $conn->rollback();
            $_SESSION['order_error_msg'] = "Online payment is not yet integrated. Please choose Cash on Delivery.";
            header("Location: checkout.php");
            exit();
        }
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['order_error_msg'] = "Failed to place order: " . $e->getMessage();
        header("Location: checkout.php");
        exit();
    }
}
?>