<?php
session_start();
include 'config/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
if (!$user) {
    header("Location: login.php");
    exit();
}
$_SESSION['user_name'] = $user['name'];
$page_title = "My Profile | KridaArena";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <style>
        .profile-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: calc(100vh - 120px);
            padding-top: 50px;
            padding-bottom: 50px;
        }

        .profile-card {
            background-color: #fff;
            border-radius: 20px;
            padding: 35px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            position: relative;
            transition: all 0.4s ease-in-out;
            border: none;
        }

        .profile-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
        }

        .profile-header {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            margin-bottom: 1rem;
        }

        .profile-icon {
            font-size: 80px;
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .profile-name {
            font-weight: 700;
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-size: 2.5rem;
        }

        .btn-profile-edit {
            border-radius: 12px;
            padding: 12px 24px;
            font-weight: bold;
            color: #fff;
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            border: none;
            transition: all 0.3s ease;
        }

        .btn-profile-edit:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px #f848d2ff, 0 0 25px #ec7c20ff;
            color: #fff;
        }

        .profile-hr {
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            height: 2px;
            border: none;
            opacity: 1;
        }
    </style>
</head>
<body>
    <?php include("includes/navbar.php"); ?>
    <main class="profile-container">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card profile-card animate__animated animate__fadeIn">
                        <div class="card-body text-center p-5">
                            <div class="profile-header">
                                <div class="profile-icon">
                                    <i class="fas fa-user-circle"></i>
                                </div>
                                <h3 class="profile-name">
                                    <?php echo htmlspecialchars($user['name']); ?>
                                </h3>
                            </div>
                            <p class="text-muted"><?php echo htmlspecialchars($user['email']); ?></p>
                            <hr class="profile-hr">
                            <div class="row text-start profile-details">
                                <div class="col-md-6">
                                    <p><b>Gender:</b> <?php echo htmlspecialchars($user['gender']); ?></p>
                                    <p><b>State:</b> <?php echo htmlspecialchars($user['state']); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><b>City:</b> <?php echo htmlspecialchars($user['city']); ?></p>
                                    <p><b>Joined:</b> <?php echo date("d M Y", strtotime($user['created_at'])); ?></p>
                                </div>
                            </div>
                            <?php if (!empty($user['sports_interest'])): ?>
                            <div class="mt-4 text-start">
                                <p><b>Sports Interests:</b> <span class="badge bg-danger rounded-pill"><?= htmlspecialchars($user['sports_interest']) ?></span></p>
                            </div>
                            <?php endif; ?>
                            <div class="d-flex justify-content-center mt-4">
                                <a href="edit.php" class="btn btn-profile-edit me-2 px-4">
                                    Edit Profile
                                </a>
                                <a href="change_pass.php" class="btn btn-profile-edit px-4">
                                    Change Password
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <?php include("includes/footer.php"); ?>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>