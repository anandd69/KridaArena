<?php
session_start();
require_once 'config/db.php';
$page_title = "Checkout | KridaArena";
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?msg=Please login to proceed to checkout.");
    exit();
}
$user_id = $_SESSION['user_id'];
$saved_addresses = [];
try {
    $stmt = $conn->prepare("SELECT * FROM saved_addresses WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $saved_addresses = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
}
$cart_products = [];
$product_ids = [];
if (!empty($_SESSION['cart'])) {
    $product_ids = array_map('intval', array_keys($_SESSION['cart']));
    $placeholders = implode(',', array_fill(0, count($product_ids), '?'));
    if (!empty($product_ids)) {
        $stmt = $conn->prepare("SELECT * FROM products WHERE id IN ($placeholders)");
        $types = str_repeat('i', count($product_ids));
        $stmt->bind_param($types, ...$product_ids);
        $stmt->execute();
        $result = $stmt->get_result();
        $products_db = $result->fetch_all(MYSQLI_ASSOC);
        foreach ($products_db as $product_row) {
            $cart_products[$product_row['id']] = $product_row;
        }
    }
}
$total_price = 0;
foreach ($_SESSION['cart'] as $id => $item) {
    if (isset($cart_products[$id])) {
        $product = $cart_products[$id];
        $total_price += $product['price'] * $item['quantity'];
    }
}
$last_order_id = $_SESSION['last_order_id'] ?? null;
$success_msg = $_SESSION['order_success_msg'] ?? null;
if ($success_msg) {
    unset($_SESSION['order_success_msg']);
    unset($_SESSION['last_order_id']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>
    <style>
        .checkout-container {
            border-radius: 20px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }
        .form-check-input:checked {
            background-color: #ec7c20ff;
            border-color: #ec7c20ff;
        }
        .btn-glow-alt {
            background: linear-gradient(45deg, #f848d2ff, #ec7c20ff);
            border: none;
            color: #fff;
            font-weight: bold;
            transition: 0.3s;
            box-shadow: 0 0 5px rgba(248, 72, 210, 0.5);
        }
        .btn-glow-alt:hover {
            transform: scale(1.02);
            box-shadow: 0 0 15px rgba(248, 72, 210, 0.8);
        }
        .hidden {
            display: none;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <?php include 'includes/navbar.php'; ?>
    <main class="container my-5 flex-grow-1">
        <h2 class="text-center mb-4">Checkout</h2>
        <div class="row">
            <?php if (empty($_SESSION['cart'])): ?>
                <div class="alert alert-info text-center" role="alert">
                    Your cart is empty. <a href="store.php" class="alert-link">Start shopping here!</a>
                </div>
            <?php else: ?>
                <div class="col-md-8">
                    <div class="card p-4 shadow-sm checkout-container">
                        <h4 class="mb-3">Shipping Information</h4>
                        <?php if (!empty($saved_addresses)): ?>
                            <div class="mb-3">
                                <label for="saved_address" class="form-label">Use Saved Address</label>
                                <select class="form-select" id="saved_address">
                                    <option value="">Select a saved address</option>
                                    <?php foreach ($saved_addresses as $address): ?>
                                        <option value='<?= json_encode($address) ?>'>
                                            <?= htmlspecialchars($address['name']) ?> - <?= htmlspecialchars($address['address']) ?>, <?= htmlspecialchars($address['city']) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <hr class="my-4">
                        <?php endif; ?>
                        <form id="checkoutForm" action="process_order.php" method="POST">
                            <input type="hidden" id="selected_product_id" name="product_id" value="">
                            <div class="mb-3">
                                <label for="name" class="form-label">Full Name</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email Address</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="address" class="form-label">Address</label>
                                <input type="text" class="form-control" id="address" name="address" placeholder="1234 Main St" required>
                            </div>
                            <div class="row">
                                <div class="col-md-5 mb-3">
                                    <label for="state" class="form-label">State</label>
                                    <select class="form-select" id="state" name="state" required>
                                        <option value="">Select a state</option>
                                        <option value="Andhra Pradesh">Andhra Pradesh</option>
                                        <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                        <option value="Assam">Assam</option>
                                        <option value="Bihar">Bihar</option>
                                        <option value="Chhattisgarh">Chhattisgarh</option>
                                        <option value="Goa">Goa</option>
                                        <option value="Gujarat">Gujarat</option>
                                        <option value="Haryana">Haryana</option>
                                        <option value="Himachal Pradesh">Himachal Pradesh</option>
                                        <option value="Jharkhand">Jharkhand</option>
                                        <option value="Karnataka">Karnataka</option>
                                        <option value="Kerala">Kerala</option>
                                        <option value="Madhya Pradesh">Madhya Pradesh</option>
                                        <option value="Maharashtra">Maharashtra</option>
                                        <option value="Manipur">Manipur</option>
                                        <option value="Meghalaya">Meghalaya</option>
                                        <option value="Mizoram">Mizoram</option>
                                        <option value="Nagaland">Nagaland</option>
                                        <option value="Odisha">Odisha</option>
                                        <option value="Punjab">Punjab</option>
                                        <option value="Rajasthan">Rajasthan</option>
                                        <option value="Sikkim">Sikkim</option>
                                        <option value="Tamil Nadu">Tamil Nadu</option>
                                        <option value="Telangana">Telangana</option>
                                        <option value="Tripura">Tripura</option>
                                        <option value="Uttar Pradesh">Uttar Pradesh</option>
                                        <option value="Uttarakhand">Uttarakhand</option>
                                        <option value="West Bengal">West Bengal</option>
                                        <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                        <option value="Chandigarh">Chandigarh</option>
                                        <option value="Dadra and Nagar Haveli and Daman and Diu">Dadra and Nagar Haveli and Daman and Diu</option>
                                        <option value="Lakshadweep">Lakshadweep</option>
                                        <option value="Delhi">Delhi</option>
                                        <option value="Puducherry">Puducherry</option>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="city" class="form-label">City</label>
                                    <select class="form-select" id="city" name="city" required disabled>
                                        <option value="">Select a city</option>
                                    </select>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="zip" class="form-label">Zip Code</label>
                                    <input type="text" class="form-control" id="zip" name="zip" required>
                                </div>
                            </div>
                            <hr class="my-4">
                            <h4 class="mb-3">Payment Method</h4>
                            <div class="mb-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="paymentMethod" id="cod" value="COD" checked>
                                    <label class="form-check-label" for="cod">
                                        Cash on Delivery
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="paymentMethod" id="online" value="Online Payment">
                                    <label class="form-check-label" for="online">
                                        Online Payment (UPI Only)
                                    </label>
                                </div>
                            </div>
                            <div id="onlinePaymentDetails" class="hidden">
                                <hr class="my-4">
                                <h5 class="mb-3">Online Payment Method: UPI</h5>
                                <input type="hidden" name="onlinePaymentOption" value="UPI">
                                <div id="upi-details" class="payment-details">
                                    <div class="alert alert-info" role="alert">
                                        Please scan the QR code or pay to the UPI ID below.
                                        <div class="text-center my-3">
                                            <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=upi://pay?pa=kridaarena@upi&pn=KridaArena&am=<?= $total_price ?>&cu=INR" class="img-fluid rounded" alt="UPI QR Code" style="max-width: 150px;">
                                        </div>
                                        <div class="input-group">
                                            <span class="input-group-text">UPI ID:</span>
                                            <input type="text" class="form-control" value="kridaarena@upi" readonly>
                                            <button type="button" class="btn btn-outline-secondary" id="copyUpiBtn">
                                                <i class="bi bi-clipboard"></i>
                                            </button>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="upi_transaction_id" class="form-label">Transaction ID</label>
                                        <input type="text" class="form-control" id="upi_transaction_id" name="upi_transaction_id" placeholder="Enter your UPI Transaction ID" required>
                                    </div>
                                </div>
                                </div>
                            <hr class="my-4">
                            <button class="btn btn-glow-alt btn-lg w-100" type="submit">Place Order</button>
                        </form>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card p-4 shadow-sm">
                        <h4 class="d-flex justify-content-between align-items-center mb-3">
                            <span>Your cart</span>
                            <span class="badge bg-primary rounded-pill"><?= count($_SESSION['cart']) ?></span>
                        </h4>
                        <ul class="list-group mb-3">
                            <?php foreach ($_SESSION['cart'] as $id => $item): ?>
                                <?php if (isset($cart_products[$id])):
                                    $product = $cart_products[$id];
                                ?>
                                <li class="list-group-item d-flex justify-content-between lh-sm">
                                    <div>
                                        <h6 class="my-0"><?= htmlspecialchars($product['name']) ?></h6>
                                        <small class="text-muted">Quantity: <?= $item['quantity'] ?></small>
                                        <div class="form-check mt-1">
                                            <input class="form-check-input single-checkout-radio" type="radio" name="checkout_type" id="checkout-<?= $id ?>" value="<?= $id ?>">
                                            <label class="form-check-label text-primary" for="checkout-<?= $id ?>">
                                                Buy only this item
                                            </label>
                                        </div>
                                    </div>
                                    <span class="text-muted">₹<?= number_format($product['price'] * $item['quantity'], 2) ?></span>
                                </li>
                                <?php endif; ?>
                            <?php endforeach; ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <div class="form-check">
                                    <input class="form-check-input single-checkout-radio" type="radio" name="checkout_type" id="checkout-all" value="all" checked>
                                    <label class="form-check-label fw-bold" for="checkout-all">
                                        Buy all items
                                    </label>
                                </div>
                                <strong>₹<?= number_format($total_price, 2) ?></strong>
                            </li>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </main>
    <?php include 'includes/footer.php'; ?>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script>
        const citiesByState = {
            "Gujarat": ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar"],
            "Maharashtra": ["Mumbai", "Pune", "Nagpur", "Nashik", "Aurangabad"],
            "Rajasthan": ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Ajmer"],
            "Delhi": ["New Delhi", "Old Delhi", "Noida", "Gurgaon"],
            "Karnataka": ["Bengaluru", "Mysuru", "Hubli", "Mangaluru"],
            "Uttar Pradesh": ["Lucknow", "Kanpur", "Agra", "Varanasi"],
            "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli"],
        };
        const stateSelect = document.getElementById('state');
        const citySelect = document.getElementById('city');
        const savedAddressSelect = document.getElementById('saved_address');
        function populateCities(selectedState) {
            citySelect.innerHTML = '<option value="">Select a city</option>';
            citySelect.disabled = true;
            if (selectedState && citiesByState[selectedState]) {
                citiesByState[selectedState].forEach(city => {
                    const option = document.createElement('option');
                    option.value = city;
                    option.textContent = city;
                    citySelect.appendChild(option);
                });
                citySelect.disabled = false;
            }
        }
        stateSelect.addEventListener('change', (e) => {
            populateCities(e.target.value);
        });
        if (savedAddressSelect) {
            savedAddressSelect.addEventListener('change', (e) => {
                const selectedAddress = JSON.parse(e.target.value);
                if (selectedAddress) {
                    document.getElementById('name').value = selectedAddress.name || '';
                    document.getElementById('email').value = selectedAddress.email || '';
                    document.getElementById('address').value = selectedAddress.address || '';
                    document.getElementById('state').value = selectedAddress.state || '';
                    populateCities(selectedAddress.state);
                    setTimeout(() => {
                        document.getElementById('city').value = selectedAddress.city || '';
                        document.getElementById('zip').value = selectedAddress.zip || '';
                    }, 50);
                }
            });
        }
        const form = document.getElementById('checkoutForm');
        const selectedProductIdInput = document.getElementById('selected_product_id');
        const radioButtons = document.querySelectorAll('.single-checkout-radio');
        radioButtons.forEach(radio => {
            radio.addEventListener('change', (e) => {
                const selectedValue = e.target.value;
                if (selectedValue === 'all') {
                    selectedProductIdInput.value = '';
                } else {
                    selectedProductIdInput.value = selectedValue;
                }
            });
        });
        const codRadio = document.getElementById('cod');
        const onlineRadio = document.getElementById('online');
        const onlinePaymentDetails = document.getElementById('onlinePaymentDetails');
        const upiTransactionId = document.getElementById('upi_transaction_id');
        const copyUpiBtn = document.getElementById('copyUpiBtn');
        function updateTransactionIdRequirement() {
            const isOnline = onlineRadio.checked;
            if (upiTransactionId) {
                upiTransactionId.required = isOnline;
            }
        }
        codRadio.addEventListener('change', () => {
            onlinePaymentDetails.classList.add('hidden');
            updateTransactionIdRequirement();
        });
        onlineRadio.addEventListener('change', () => {
            onlinePaymentDetails.classList.remove('hidden');
            updateTransactionIdRequirement();
        });
        updateTransactionIdRequirement();
        if (copyUpiBtn) {
            copyUpiBtn.addEventListener('click', () => {
                const upiId = 'kridaarena@upi';
                navigator.clipboard.writeText(upiId).then(() => {
                    Swal.fire({
                        icon: 'success',
                        title: 'Copied!',
                        text: 'UPI ID has been copied to your clipboard.',
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 2000
                    });
                }).catch(err => {
                    console.error('Failed to copy UPI ID: ', err);
                });
            });
        }
        const lastOrderId = <?= json_encode($last_order_id) ?>;
        const successMessage = <?= json_encode($success_msg) ?>;
        if (successMessage && lastOrderId) {
            Swal.fire({
                title: 'Order Placed Successfully! 🎉',
                html: `${successMessage}<br><br>Do you want to view your invoice now?`,
                icon: 'success',
                showCancelButton: true,
                confirmButtonText: '<i class="bi bi-file-earmark-text"></i> View Invoice',
                cancelButtonText: 'Go to My Orders',
                reverseButtons: true,
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-secondary'
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    window.open(`bill.php?order_id=${lastOrderId}`, '_blank');
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    window.location.href = 'order.php';
                }
            });
        }
    </script>
</body>
</html>