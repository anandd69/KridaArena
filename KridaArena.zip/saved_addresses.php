<?php
session_start();
require_once 'config/db.php';
$page_title = "Saved Addresses | KridaArena";
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$msg = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_address'])) {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $address = $_POST['address'] ?? '';
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';
    $zip = $_POST['zip'] ?? '';
    if (empty($name) || empty($email) || empty($address) || empty($city) || empty($state) || empty($zip)) {
        $msg = "<div class='alert alert-danger'>All fields are required.</div>";
    } else {
        $stmt_count = $conn->prepare("SELECT COUNT(*) FROM saved_addresses WHERE user_id = ?");
        $stmt_count->bind_param("i", $user_id);
        $stmt_count->execute();
        $stmt_count->bind_result($address_count);
        $stmt_count->fetch();
        $stmt_count->close();
        if ($address_count >= 2) {
            $msg = "<div class='alert alert-warning'>You can save a maximum of 2 addresses. Please delete an existing one to add a new one.</div>";
        } else {
            $stmt = $conn->prepare("INSERT INTO saved_addresses (user_id, name, email, address, city, state, zip) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("issssss", $user_id, $name, $email, $address, $city, $state, $zip);
            if ($stmt->execute()) {
                $msg = "<div class='alert alert-success'>Address saved successfully!</div>";
            } else {
                $msg = "<div class='alert alert-danger'>Error saving address: " . $stmt->error . "</div>";
            }
            $stmt->close();
        }
    }
}
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $address_id = intval($_GET['id']);
    $stmt = $conn->prepare("DELETE FROM saved_addresses WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $address_id, $user_id);

    if ($stmt->execute()) {
        $msg = "<div class='alert alert-success'>Address deleted successfully!</div>";
    } else {
        $msg = "<div class='alert alert-danger'>Error deleting address.</div>";
    }
    $stmt->close();
}
$saved_addresses = [];
$stmt_fetch = $conn->prepare("SELECT * FROM saved_addresses WHERE user_id = ? ORDER BY id ASC");
$stmt_fetch->bind_param("i", $user_id);
$stmt_fetch->execute();
$result_fetch = $stmt_fetch->get_result();
while ($row = $result_fetch->fetch_assoc()) {
    $saved_addresses[] = $row;
}
$stmt_fetch->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/sweetalert2@11.js"></script>
    <style>
        .hero.short {
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            text-align: center;
            padding: 80px 0;
            margin-bottom: 0;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            color: #fff;
        }
        .address-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .address-card:hover {
            transform: translateY(-5px);
        }
        .form-section, .list-section {
            background: #fff;
            padding: 30px;
            border-radius: 20px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
        }
        .btn-glow {
            background: linear-gradient(45deg, #f848d2ff, #ec7c20ff);
            border: none;
            color: #fff;
            padding: 12px 25px;
            border-radius: 25px;
            font-weight: bold;
            transition: 0.3s;
            box-shadow: 0 0 5px rgba(248, 72, 210, 0.5);
        }
        .btn-glow:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px rgba(248, 72, 210, 0.8);
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <?php include 'includes/navbar.php'; ?>

    <header class="hero short">
        <div class="container text-center">
            <h1 class="hero-title animate__animated animate__fadeInDown">Saved Addresses</h1>
        </div>
    </header>

    <main class="container my-5 flex-grow-1">
        <?php if (!empty($msg)): ?>
            <div class="mb-4 text-center">
                <?= $msg ?>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="form-section animate__animated animate__fadeInLeft">
                    <h4 class="mb-4">Save a New Address</h4>
                    <form method="POST">
                        <input type="hidden" name="save_address" value="1">
                        <div class="mb-3">
                            <label for="name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <input type="text" class="form-control" id="address" name="address" placeholder="1234 Main St" required>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="state" class="form-label">State</label>
                                <select class="form-select" id="state" name="state" required>
                                    <option value="">Select a state</option>
                                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                                    <option value="Assam">Assam</option>
                                    <option value="Bihar">Bihar</option>
                                    <option value="Chhattisgarh">Chhattisgarh</option>
                                    <option value="Goa">Goa</option>
                                    <option value="Gujarat">Gujarat</option>
                                    <option value="Haryana">Haryana</option>
                                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                                    <option value="Jharkhand">Jharkhand</option>
                                    <option value="Karnataka">Karnataka</option>
                                    <option value="Kerala">Kerala</option>
                                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                                    <option value="Maharashtra">Maharashtra</option>
                                    <option value="Manipur">Manipur</option>
                                    <option value="Meghalaya">Meghalaya</option>
                                    <option value="Mizoram">Mizoram</option>
                                    <option value="Nagaland">Nagaland</option>
                                    <option value="Odisha">Odisha</option>
                                    <option value="Punjab">Punjab</option>
                                    <option value="Rajasthan">Rajasthan</option>
                                    <option value="Sikkim">Sikkim</option>
                                    <option value="Tamil Nadu">Tamil Nadu</option>
                                    <option value="Telangana">Telangana</option>
                                    <option value="Tripura">Tripura</option>
                                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                                    <option value="Uttarakhand">Uttarakhand</option>
                                    <option value="West Bengal">West Bengal</option>
                                    <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
                                    <option value="Chandigarh">Chandigarh</option>
                                    <option value="Dadra and Nagar Haveli and Daman and Diu">Dadra and Nagar Haveli and Daman and Diu</option>
                                    <option value="Lakshadweep">Lakshadweep</option>
                                    <option value="Delhi">Delhi</option>
                                    <option value="Puducherry">Puducherry</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="city" class="form-label">City</label>
                                <select class="form-select" id="city" name="city" required disabled>
                                    <option value="">Select a city</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="zip" class="form-label">Zip Code</label>
                            <input type="text" class="form-control" id="zip" name="zip" required>
                        </div>
                        <button type="submit" class="btn btn-glow mt-3 w-100">Save Address</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="list-section animate__animated animate__fadeInRight">
                    <h4 class="mb-4">Your Saved Addresses (<?= count($saved_addresses) ?>/2)</h4>
                    <?php if (empty($saved_addresses)): ?>
                        <div class="alert alert-info text-center">
                            You have no saved addresses.
                        </div>
                    <?php else: ?>
                        <ul class="list-group">
                            <?php foreach ($saved_addresses as $address): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-start address-card mb-3">
                                    <div class="ms-2 me-auto">
                                        <div class="fw-bold"><?= htmlspecialchars($address['name']) ?></div>
                                        <p class="mb-1"><?= htmlspecialchars($address['address']) ?>, <?= htmlspecialchars($address['city']) ?></p>
                                        <p class="mb-0"><small class="text-muted"><?= htmlspecialchars($address['state']) ?> - <?= htmlspecialchars($address['zip']) ?></small></p>
                                    </div>
                                    <a href="?action=delete&id=<?= $address['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this address?');"><i class="bi bi-trash"></i></a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script>
        const citiesByState = {
            "Gujarat": ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar"],
            "Maharashtra": ["Mumbai", "Pune", "Nagpur", "Nashik", "Aurangabad"],
            "Rajasthan": ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Ajmer"],
            "Delhi": ["New Delhi", "Old Delhi", "Noida", "Gurgaon"],
            "Karnataka": ["Bengaluru", "Mysuru", "Hubli", "Mangaluru"],
            "Uttar Pradesh": ["Lucknow", "Kanpur", "Agra", "Varanasi"],
            "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli"],
            "Andhra Pradesh": ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore"],
            "Arunachal Pradesh": ["Itanagar", "Naharlagun", "Pasighat"],
            "Assam": ["Guwahati", "Dibrugarh", "Silchar", "Jorhat"],
            "Bihar": ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur"],
            "Chhattisgarh": ["Raipur", "Bhilai", "Bilaspur"],
            "Goa": ["Panaji", "Margao", "Vasco da Gama"],
            "Haryana": ["Faridabad", "Gurgaon", "Panipat", "Ambala"],
            "Himachal Pradesh": ["Shimla", "Mandi", "Dharamshala", "Solan"],
            "Jharkhand": ["Ranchi", "Jamshedpur", "Dhanbad", "Bokaro"],
            "Kerala": ["Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur"],
            "Madhya Pradesh": ["Bhopal", "Indore", "Jabalpur", "Gwalior"],
            "Manipur": ["Imphal", "Thoubal", "Churachandpur"],
            "Meghalaya": ["Shillong", "Tura", "Jowai"],
            "Mizoram": ["Aizawl", "Lunglei", "Saiha"],
            "Nagaland": ["Kohima", "Dimapur", "Wokha"],
            "Odisha": ["Bhubaneswar", "Cuttack", "Rourkela", "Berhampur"],
            "Punjab": ["Ludhiana", "Amritsar", "Jalandhar", "Patiala"],
            "Sikkim": ["Gangtok", "Namchi", "Geyzing"],
            "Telangana": ["Hyderabad", "Warangal", "Nizamabad"],
            "Tripura": ["Agartala", "Udaipur", "Dharmanagar"],
            "Uttarakhand": ["Dehradun", "Haridwar", "Roorkee", "Haldwani"],
            "West Bengal": ["Kolkata", "Howrah", "Asansol", "Durgapur"],
            "Andaman and Nicobar Islands": ["Port Blair"],
            "Chandigarh": ["Chandigarh"],
            "Dadra and Nagar Haveli and Daman and Diu": ["Silvassa", "Daman", "Diu"],
            "Lakshadweep": ["Kavaratti"],
            "Puducherry": ["Puducherry", "Karaikal", "Mahé", "Yanam"],
        };

        const stateSelect = document.getElementById('state');
        const citySelect = document.getElementById('city');

        function populateCities(selectedState) {
            citySelect.innerHTML = '<option value="">Select a city</option>'; // Clear previous options
            citySelect.disabled = true;

            if (selectedState && citiesByState[selectedState]) {
                citiesByState[selectedState].forEach(city => {
                    const option = document.createElement('option');
                    option.value = city;
                    option.textContent = city;
                    citySelect.appendChild(option);
                });
                citySelect.disabled = false;
            }
        }

        stateSelect.addEventListener('change', (e) => {
            populateCities(e.target.value);
        });
    </script>
</body>
</html>