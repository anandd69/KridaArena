-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2025 at 01:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kridaarena`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `login_attempts` int(11) NOT NULL DEFAULT 0,
  `lockout_until` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `name`, `email`, `password`, `login_attempts`, `lockout_until`, `last_login_at`, `created_at`) VALUES
(5, 'Rajkumar', 'rajkumar@gmail.com', '$2y$10$OAEeb4rGFwBQurtFQHEfh.QezOX.hMJn.J0iwq9OuzbN2OvnagMP.', 0, NULL, '2025-11-02 11:32:39', '2025-09-25 20:48:36'),
(6, 'Anand', 'anand@gmail.com', '$2y$10$ByUCAjDIGPcOqxMKFncppO6gd3HABVcpvCYfdAbC0hp9YtbO.JrtG', 0, NULL, '2025-11-15 17:25:40', '2025-09-25 20:48:36');

-- --------------------------------------------------------

--
-- Table structure for table `admin_activity_logs`
--

CREATE TABLE `admin_activity_logs` (
  `log_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `action` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

CREATE TABLE `faqs` (
  `id` int(11) NOT NULL,
  `question` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `question`, `answer`, `created_at`) VALUES
(1, 'How can I register for a tournament?', 'You can register by visiting the \"Tournaments\" page, selecting the event you want, and filling out the registration form. Make sure you are logged in to complete the process.', '2025-10-31 17:07:53'),
(2, 'Is there a fee to join tournaments?', 'Most tournaments on KridaArena have a small registration fee, which contributes to the prize pool and event organization. Details are listed on each tournament\'s page.', '2025-10-31 17:07:53'),
(3, 'What kind of gear can I find in the shop?', 'Our shop features a wide range of gear for various sports, including cricket bats, footballs, rackets, apparel, and protective equipment from top brands.', '2025-10-31 17:07:53'),
(4, 'How are tournament winners decided?', 'Winners are determined based on the official rules of each tournament. We use a fair and transparent system, and results are updated in real-time on the tournament brackets page.', '2025-10-31 17:07:53'),
(5, 'Can I host my own tournament on KridaArena?', 'Yes, we offer tools for organizers to host their own events. You can contact us through the \"Contact\" page for more information and to get started.', '2025-10-31 17:07:53'),
(6, 'What payment methods are accepted for tournament fees?', 'We accept a variety of payment methods, including credit/debit cards, net banking, and popular mobile payment gateways.', '2025-10-31 17:07:53');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`id`, `user_id`, `name`, `email`, `subject`, `message`, `rating`, `created_at`) VALUES
(1, NULL, 'a', 'banana@gmail.com', 'c', 'd', 4, '2025-09-28 19:01:57'),
(2, 4, 'manan', 'mana@gmail.com', 'amam', '1', 2, '2025-09-28 21:13:36'),
(3, 4, 'men', 'women@gmail.com', 'testing', 'q', 1, '2025-09-28 21:17:53'),
(4, NULL, 'tet', 't1@gmail.com', 'User Submission', 'qq', 3, '2025-10-31 17:01:21'),
(7, 11, 'full name', 'vita@gmail.com', 'User Submission', 'QWE', 2, '2025-11-15 16:09:01');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `attempts` int(11) NOT NULL DEFAULT 1,
  `last_attempt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`id`, `ip_address`, `attempts`, `last_attempt`) VALUES
(1, '::1', 2, '2025-09-24 14:17:34');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shipping_address_id` int(11) DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `shipping_fee` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(10,2) NOT NULL,
  `tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('Pending','Processing','Shipped','Delivered','Cancelled') NOT NULL DEFAULT 'Pending',
  `payment_method` varchar(255) DEFAULT 'Cash on Delivery',
  `delivery_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `shipping_address_id`, `subtotal`, `shipping_fee`, `tax`, `total_amount`, `tax_amount`, `status`, `payment_method`, `delivery_date`, `created_at`) VALUES
(1, 2, 2, 0.00, 0.00, 0.00, 5248.00, 0.00, 'Delivered', 'Cash on Delivery', NULL, '2025-09-19 11:13:32'),
(2, 2, 2, 0.00, 0.00, 0.00, 1650.00, 0.00, 'Delivered', 'Cash on Delivery', '2025-09-26', '2025-09-19 11:40:08'),
(3, 2, 2, 0.00, 0.00, 0.00, 850.00, 0.00, 'Cancelled', 'Cash on Delivery', '2025-09-26', '2025-09-19 11:44:46'),
(4, 2, 2, 0.00, 0.00, 0.00, 1800.00, 0.00, 'Delivered', 'Cash on Delivery', '2025-09-26', '2025-09-19 11:45:22'),
(5, 2, 2, 0.00, 0.00, 0.00, 999.00, 0.00, 'Shipped', 'Cash on Delivery', '2025-09-26', '2025-09-19 11:52:49'),
(6, 2, 2, 0.00, 0.00, 0.00, 1650.00, 0.00, 'Processing', 'Cash on Delivery', '2025-10-02', '2025-09-25 20:44:25'),
(9, 4, 4, 0.00, 0.00, 0.00, 799.00, 0.00, 'Cancelled', 'Cash on Delivery', '2025-10-05', '2025-09-28 18:28:30'),
(10, 4, 4, 0.00, 0.00, 0.00, 2750.00, 0.00, 'Processing', 'Cash on Delivery', '2025-10-05', '2025-09-28 18:57:35'),
(13, 4, 4, 0.00, 0.00, 0.00, 1599.00, 0.00, 'Pending', 'Cash on Delivery', '2025-11-01', '2025-10-25 12:34:44'),
(14, 4, 4, 0.00, 0.00, 0.00, 1799.00, 0.00, 'Pending', 'Cash on Delivery', '2025-11-01', '2025-10-25 12:37:25'),
(15, 4, 4, 0.00, 0.00, 0.00, 1800.00, 0.00, 'Pending', 'Cash on Delivery', '2025-11-01', '2025-10-25 12:40:14'),
(16, 4, 6, 0.00, 0.00, 0.00, 7297.00, 0.00, 'Shipped', 'Cash on Delivery', '2025-11-02', '2025-10-26 20:51:52'),
(20, 9, 9, 0.00, 0.00, 0.00, 1799.00, 0.00, 'Shipped', 'Cash on Delivery', '2025-11-07', '2025-10-31 17:45:06'),
(21, 9, 9, 0.00, 0.00, 0.00, 1650.00, 0.00, 'Cancelled', 'Cash on Delivery', '2025-11-08', '2025-11-01 17:28:34'),
(25, 9, 9, 0.00, 0.00, 0.00, 1299.00, 0.00, 'Cancelled', 'Cash on Delivery', '2025-11-08', '2025-11-01 18:10:36'),
(26, 9, 9, 0.00, 0.00, 0.00, 2750.00, 0.00, 'Processing', 'Cash on Delivery', '2025-11-08', '2025-11-01 18:13:10'),
(27, 9, 9, 0.00, 0.00, 0.00, 1800.00, 0.00, 'Cancelled', 'Cash on Delivery', '2025-11-08', '2025-11-01 18:28:02'),
(30, 11, 11, 0.00, 0.00, 0.00, 1599.00, 0.00, 'Delivered', 'Cash on Delivery', '2025-11-22', '2025-11-15 16:06:43');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price_at_purchase` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`item_id`, `order_id`, `product_id`, `quantity`, `price_at_purchase`) VALUES
(1, 1, 15, 1, 1999.00),
(2, 1, 17, 1, 1599.00),
(3, 1, 18, 1, 1650.00),
(4, 2, 18, 1, 1650.00),
(5, 3, 4, 1, 850.00),
(6, 4, 11, 1, 1800.00),
(7, 5, 5, 1, 999.00),
(8, 6, 18, 1, 1650.00),
(11, 9, 1, 1, 799.00),
(12, 10, 14, 1, 2750.00),
(15, 13, 17, 1, 1599.00),
(16, 14, 16, 1, 1799.00),
(17, 15, 11, 1, 1800.00),
(18, 16, 2, 1, 2500.00),
(19, 16, 17, 3, 1599.00),
(23, 20, 16, 1, 1799.00),
(24, 21, 18, 1, 1650.00),
(28, 25, 13, 1, 1299.00),
(29, 26, 14, 1, 2750.00),
(30, 27, 11, 1, 1800.00),
(33, 30, 17, 1, 1599.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `image`, `stock`, `created_at`) VALUES
(1, 'Football', 'Official size 5 football. Perfect for training and matches.', 799.00, 'football_product.jpg', 100, '2025-09-14 11:35:17'),
(2, 'Cricket Bat', 'High-quality cricket bat made from premium willow for powerful shots.', 2500.00, 'cricket_bat.jpg', 50, '2025-09-14 11:35:17'),
(3, 'Running Shoes', 'Lightweight running shoes with a breathable mesh upper for superior comfort.', 1499.00, 'running_shoes.jpg', 150, '2025-09-14 11:35:17'),
(4, 'Badminton Racket', 'Durable badminton racket with a comfortable grip for quick and precise shots.', 850.00, 'badminton_racket.jpg', 75, '2025-09-14 11:35:17'),
(5, 'Basketball', 'Official size 7 basketball with a textured surface for improved grip.', 999.00, 'basketball.jpg', 80, '2025-09-14 11:35:17'),
(6, 'Tennis Racket', 'Professional-grade tennis racket for powerful serves and accurate returns.', 2999.00, 'tennis_racket.jpg', 40, '2025-09-14 11:35:17'),
(7, 'Yoga Mat', 'Non-slip yoga mat with extra cushioning for a comfortable workout.', 550.00, 'yoga_mat.jpg', 200, '2025-09-14 11:35:17'),
(8, 'Skipping Rope', 'Adjustable skipping rope with ergonomic handles for a smooth workout.', 250.00, 'skipping_rope.jpg', 300, '2025-09-14 11:35:17'),
(9, 'Resistance Bands', 'Set of 5 resistance bands with varying resistance levels for strength training.', 699.00, 'resistance_bands.jpg', 120, '2025-09-14 11:35:17'),
(10, 'Gym Gloves', 'Padded gym gloves for a firm grip and to protect your hands during workouts.', 350.00, 'gym_gloves.jpg', 250, '2025-09-14 11:35:17'),
(11, 'Cricket Helmet', 'A durable cricket helmet providing maximum protection with an adjustable fit.', 1800.00, 'cricket_helmet.jpg', 60, '2025-09-14 11:35:17'),
(12, 'Football Shin Guards', 'Lightweight and durable shin guards for enhanced protection on the field.', 450.00, 'football_shin_guards.jpg', 90, '2025-09-14 11:35:17'),
(13, 'Nike Cricket T-shirt', 'A classic Nike cricket t-shirt with Dri-FIT technology for moisture-wicking comfort.', 1299.00, 'nike_cricket_tshirt.jpg', 110, '2025-09-14 11:35:17'),
(14, 'Puma Football Cleats', 'Puma cleats with a lightweight design and superior traction for fast-paced football games.', 2750.00, 'puma_football_cleats.jpg', 70, '2025-09-14 11:35:17'),
(15, 'Team India Cricket Jersey', 'Official replica of the Indian Cricket Team jersey. Made with breathable fabric for comfort.', 1999.00, 'indian_cricket_jersey.jpg', 85, '2025-09-14 11:35:17'),
(16, 'Team India Football Jersey', 'Official football jersey for the Indian national team. Lightweight and sweat-wicking.', 1799.00, 'indian_football_jersey.jpg', 95, '2025-09-14 11:35:17'),
(17, 'Team India Kabaddi Jersey', 'Official jersey for the Indian Kabaddi Team. Designed for durability and freedom of movement.', 1599.00, 'indian_kabbadi_jersey.jpg', 65, '2025-09-14 11:35:17'),
(18, 'Team India Hockey Jersey', 'Official jersey for the Indian Hockey Team. Features national colors and team logo.', 1650.00, 'indian_hockey_jersey.jpg', 55, '2025-09-14 11:35:17');

-- --------------------------------------------------------

--
-- Table structure for table `registrations`
--

CREATE TABLE `registrations` (
  `registration_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `sport_type` varchar(255) NOT NULL,
  `team_name` varchar(255) NOT NULL,
  `players_data` text NOT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `registration_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registrations`
--

INSERT INTO `registrations` (`registration_id`, `user_id`, `sport_type`, `team_name`, `players_data`, `payment_method`, `transaction_id`, `registration_date`) VALUES
(1, 2, 'chess', 'villain', '{\"1\":{\"name\":\"villain\",\"age\":\"20\",\"gender\":\"Male\",\"email\":\"raj@gmail.com\",\"aadhaar\":\"10\",\"from\":\"gujrat\"}}', 'UPI', '1', '2025-09-25 18:15:36'),
(2, 2, 'badminton', 'villain', '{\"1\":{\"name\":\"villain\",\"age\":\"20\",\"gender\":\"Male\",\"email\":\"raj@gmail.com\",\"aadhaar\":\"10\",\"from\":\"gujrat\"}}', 'UPI', '1', '2025-09-25 18:47:40'),
(3, 2, 'football', 'gangster', '{\"1\":{\"name\":\"surya\",\"age\":\"20\",\"gender\":\"Male\",\"email\":\"surya@gmail.com\",\"aadhaar\":\"2\",\"from\":\"gujrat\"},\"2\":{\"name\":\"vikram\",\"age\":\"20\",\"gender\":\"Male\",\"email\":\"vikram@gmail.com\",\"aadhaar\":\"3\",\"from\":\"gujrat\"},\"3\":{\"name\":\"kaithi\",\"age\":\"21\",\"gender\":\"Male\",\"email\":\"kaithi@gmail.com\",\"aadhaar\":\"4\",\"from\":\"gujrat\"},\"4\":{\"name\":\"leo\",\"age\":\"20\",\"gender\":\"Male\",\"email\":\"leo@gmail.com\",\"aadhaar\":\"5\",\"from\":\"gujrat\"},\"5\":{\"name\":\"raja\",\"age\":\"21\",\"gender\":\"Male\",\"email\":\"raja@gmail.com\",\"aadhaar\":\"6\",\"from\":\"gujrat\"},\"6\":{\"name\":\"krunal\",\"age\":\"20\",\"gender\":\"Male\",\"email\":\"krunal@gmail.com\",\"aadhaar\":\"7\",\"from\":\"gujrat\"},\"7\":{\"name\":\"thala\",\"age\":\"19\",\"gender\":\"Male\",\"email\":\"thala@gmail.com\",\"aadhaar\":\"8\",\"from\":\"gujrat\"}}', 'UPI', '9', '2025-09-26 07:49:24'),
(5, 4, 'chess', 'anand', '{\"1\":{\"name\":\"anand\",\"age\":\"19\",\"gender\":\"Male\",\"email\":\"anand@gmail.com\",\"aadhaar\":\"1234 5678 90\",\"from\":\"Jamnagar\"}}', 'UPI', '1', '2025-09-28 14:50:50'),
(6, 4, 'badminton', 'anand', '{\"1\":{\"name\":\"anand\",\"age\":\"19\",\"gender\":\"Male\",\"email\":\"anand@gmail.com\",\"aadhaar\":\"1234 5678 90\",\"from\":\"Jamnagar\"}}', 'UPI', '1', '2025-09-28 15:18:20'),
(15, 9, 'chess', 'tet', '{\"1\":{\"name\":\"tet\",\"age\":\"22\",\"gender\":\"Female\",\"email\":\"t1@gmail.com\",\"aadhaar\":\"1234 5678 90\",\"from\":\"12\"}}', 'UPI', '12', '2025-10-31 13:09:30'),
(16, 9, 'badminton', 'op', '{\"1\":{\"name\":\"op\",\"age\":\"22\",\"gender\":\"Male\",\"email\":\"email@address.com\",\"aadhaar\":\"22\",\"from\":\"jamna\"}}', 'UPI', '1', '2025-10-31 13:10:11'),
(18, 11, 'badminton', 'anand', '{\"1\":{\"name\":\"anand\",\"age\":\"1\",\"gender\":\"Male\",\"email\":\"email@address.com\",\"aadhaar\":\"3214141\",\"from\":\"Jamnaa\"}}', 'UPI', '1332442', '2025-11-15 11:33:41'),
(19, 11, 'chess', 'anand', '{\"1\":{\"name\":\"anand\",\"age\":\"1\",\"gender\":\"Male\",\"email\":\"email@address.com\",\"aadhaar\":\"3214141\",\"from\":\"Jamnaa\"}}', 'UPI', '898', '2025-11-15 12:07:45'),
(20, 12, 'tennis', 'anand', '{\"1\":{\"name\":\"anand\",\"age\":\"1\",\"gender\":\"Male\",\"email\":\"email@address.com\",\"aadhaar\":\"3214141\",\"from\":\"Jamnaa\"}}', 'Online Payment', '12345', '2025-11-15 12:47:47');

-- --------------------------------------------------------

--
-- Table structure for table `saved_addresses`
--

CREATE TABLE `saved_addresses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `saved_addresses`
--

INSERT INTO `saved_addresses` (`id`, `user_id`, `name`, `email`, `address`, `city`, `state`, `zip`, `created_at`) VALUES
(2, 2, 'v', 'villainguru333@gmail.com', 'v', 'Rajkot', 'Gujarat', '361004', '2025-09-19 04:53:07'),
(4, 4, 'full name', 'email@address.com', '1234 main st', '', 'Madhya Pradesh', '1234', '2025-09-28 12:58:30'),
(6, 4, 'full name', 'email@address.com', '1234 main st', 'Ahmedabad', 'Gujarat', '1234', '2025-10-26 15:21:52'),
(9, 9, 'full name', 'email@address.com', '1234 main st', 'Ahmedabad', 'Gujarat', '1234', '2025-10-31 12:15:06'),
(11, 11, 'full name', 'email@address.com', '1234 main st', 'Ahmedabad', 'Gujarat', '1234', '2025-11-15 10:36:43');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `setting_key` varchar(255) NOT NULL,
  `setting_value` text NOT NULL,
  `last_updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`setting_key`, `setting_value`, `last_updated_at`) VALUES
('contact_email', 'contact@kridaarena.com', '2025-09-24 14:03:25'),
('footer_text', 'KridaArena © 2025. All Rights Reserved.', '2025-09-24 14:03:25'),
('social_media_links', '{\"facebook\": \"#\", \"twitter\": \"#\", \"instagram\": \"#\"}', '2025-09-24 14:03:25');

-- --------------------------------------------------------

--
-- Table structure for table `tournaments`
--

CREATE TABLE `tournaments` (
  `tournament_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sport` varchar(100) NOT NULL,
  `venue` varchar(255) NOT NULL,
  `fees` decimal(10,2) NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT 'team',
  `description` text NOT NULL,
  `status` enum('upcoming','active','completed') NOT NULL DEFAULT 'upcoming',
  `players_per_team` int(11) NOT NULL,
  `team_limit` int(11) NOT NULL,
  `prizes` text DEFAULT NULL,
  `registration_start_date` date NOT NULL,
  `registration_end_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tournaments`
--

INSERT INTO `tournaments` (`tournament_id`, `name`, `sport`, `venue`, `fees`, `type`, `description`, `status`, `players_per_team`, `team_limit`, `prizes`, `registration_start_date`, `registration_end_date`, `created_at`) VALUES
(1, 'Cricket Premier League', 'cricket', 'Ahmedabad Stadium', 5000.00, 'team', 'A high-stakes local cricket tournament.', 'active', 11, 8, 'Winner: Rs. 20,000, Runner-up: Rs. 10,000', '2025-09-25', '2025-10-15', '2025-09-14 06:05:17'),
(2, 'Football Championship', 'football', 'Urban Football Ground', 4000.00, 'team', 'The best football clubs battle for the trophy.', 'upcoming', 7, 10, 'Winner: Rs. 15,000, Runner-up: Rs. 8,000', '2025-10-10', '2025-10-30', '2025-09-14 06:05:17'),
(3, 'State Chess Tournament', 'chess', 'City Community Hall', 1000.00, 'solo', 'A city-wide chess tournament for all skill levels.', 'active', 1, 32, '1st Place: Rs. 8,000, 2nd Place: Rs. 4,000, 3rd Place: Rs. 2,000', '2025-11-01', '2025-11-20', '2025-09-25 16:45:55'),
(4, 'Basketball Slam Fest', 'basketball', 'City Sports Complex', 3500.00, 'team', 'An exciting basketball tournament for amateur teams.', 'completed', 5, 10, 'Winner Team: Rs. 12,000, Runner-up: Rs. 6,000, MVP (Most Valuable Player): Rs. 1,000', '2025-11-05', '2025-11-25', '2025-09-25 16:45:55'),
(5, 'Volleyball League', 'volleyball', 'Beach Side Court', 2800.00, 'team', 'A fun and competitive volleyball league.', 'active', 6, 12, 'Winner Team: Rs. 10,000, Runner-up: Rs. 5,000', '2025-12-01', '2025-12-20', '2025-09-25 16:45:55'),
(6, 'City Tennis Open', 'tennis', 'Royal Tennis Club', 1500.00, 'solo', 'A prestigious tennis tournament for singles players.', 'active', 1, 32, 'Winner: Rs. 10,000, Runner-up: Rs. 5,000', '2025-12-15', '2026-01-05', '2025-09-25 16:45:55'),
(7, 'Badminton Championship', 'badminton', 'Indoor Sports Arena', 1200.00, 'solo', 'An intense badminton tournament for singles players.', 'active', 1, 32, 'Winner: Rs. 8,000, Runner-up: Rs. 4,000', '2026-01-02', '2026-01-20', '2025-09-25 16:45:55'),
(8, 'Kabaddi Masters Cup', 'kabaddi', 'Local Sports Ground', 4500.00, 'team', 'A high-energy kabaddi tournament for the best teams.', 'active', 7, 10, 'Winner Team: Rs. 18,000, Runner-up Team: Rs. 9,000, Best Raider: Rs. 2,000', '2026-02-01', '2026-02-20', '2025-09-25 16:45:55');

-- --------------------------------------------------------

--
-- Table structure for table `tournament_registrations`
--

CREATE TABLE `tournament_registrations` (
  `registration_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tournament_id` int(11) NOT NULL,
  `team_name` varchar(255) NOT NULL,
  `registered_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `sports_interest` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `gender`, `state`, `city`, `sports_interest`, `created_at`) VALUES
(2, 'v', 'v@gmail.com', '$2y$10$WmVWa38cUJnhOkfnssZXPufLybm2o8UfpEh25vccATVNojExJU506', 'Male', 'Gujarat', 'Jamnagar', '', '2025-09-19 05:48:18'),
(4, 'anand', 'anand@gmail.com', '$2y$10$HGTtI.95vFrGtYCrNuTUbOc0NrjQ0muKW/qUp4.GsywynExLFf5BG', 'Male', 'Gujarat', 'Jamnagar', '', '2025-09-28 14:49:15'),
(9, 'full name', 'email@address.com', '$2y$10$Vx.ziFuZQuhdrS/APlBh9ealHkclLBM9A57GR73W9Kp259fqtMIFu', 'Male', 'Gujarat', 'Ahmedabad', '', '2025-10-31 13:08:54'),
(11, 'born', 'vita@gmail.com', '$2y$10$aWMkyX9Ho1Q9Ku/eat7VD.dPhefdK0Se.3DUUNIp/xatCi9yiyx.q', 'Male', 'Gujarat', 'Ahmedabad', 'GILLU FENNK', '2025-11-15 11:33:05'),
(12, 'born', 'vit@gmail.com', '$2y$10$B0Wm5jWEIQaOEnt6fpZiF.I4jMXMi1RmPHiw55iHm529W3shBLJiu', 'Female', 'Gujarat', 'Ahmedabad', '', '2025-11-15 12:47:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `admin_activity_logs`
--
ALTER TABLE `admin_activity_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `faqs`
--
ALTER TABLE `faqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `shipping_address_id` (`shipping_address_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registrations`
--
ALTER TABLE `registrations`
  ADD PRIMARY KEY (`registration_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `saved_addresses`
--
ALTER TABLE `saved_addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Indexes for table `tournaments`
--
ALTER TABLE `tournaments`
  ADD PRIMARY KEY (`tournament_id`);

--
-- Indexes for table `tournament_registrations`
--
ALTER TABLE `tournament_registrations`
  ADD PRIMARY KEY (`registration_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `tournament_id` (`tournament_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `admin_activity_logs`
--
ALTER TABLE `admin_activity_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faqs`
--
ALTER TABLE `faqs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `registrations`
--
ALTER TABLE `registrations`
  MODIFY `registration_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `saved_addresses`
--
ALTER TABLE `saved_addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tournaments`
--
ALTER TABLE `tournaments`
  MODIFY `tournament_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tournament_registrations`
--
ALTER TABLE `tournament_registrations`
  MODIFY `registration_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_activity_logs`
--
ALTER TABLE `admin_activity_logs`
  ADD CONSTRAINT `admin_activity_logs_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`admin_id`) ON DELETE CASCADE;

--
-- Constraints for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD CONSTRAINT `feedbacks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`shipping_address_id`) REFERENCES `saved_addresses` (`id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `registrations`
--
ALTER TABLE `registrations`
  ADD CONSTRAINT `registrations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `saved_addresses`
--
ALTER TABLE `saved_addresses`
  ADD CONSTRAINT `saved_addresses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tournament_registrations`
--
ALTER TABLE `tournament_registrations`
  ADD CONSTRAINT `tournament_registrations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tournament_registrations_ibfk_2` FOREIGN KEY (`tournament_id`) REFERENCES `tournaments` (`tournament_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
