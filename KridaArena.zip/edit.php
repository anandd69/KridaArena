<?php
session_start();
include 'config/db.php';
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $sports_interest = $_POST['sports_interest'] ?? '';
    $update = "UPDATE users SET name=?, gender=?, state=?, city=?, sports_interest=? WHERE id=?";
    $stmt = $conn->prepare($update);
    $stmt->bind_param("sssssi", $name, $gender, $state, $city, $sports_interest, $user_id);
    $stmt->execute();
    $_SESSION['user_name'] = $name;
    header("Location: profile.php");
    exit();
}
$page_title = "Edit Profile | KridaArena";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>
    <style>
        .edit-box {
            background: #fff;
            padding: 35px;
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .form-label {
            color: #333;
            font-size: 0.95rem;
        }
        .btn-profile-edit {
            background: linear-gradient(45deg, #ec7c20ff, #f848d2ff);
            border: none;
            color: #fff;
            font-weight: bold;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(248, 72, 210, 0.5);
            border-radius: 50px;
        }
        .btn-profile-edit:hover {
            box-shadow: 0 6px 15px rgba(236, 124, 32, 0.7);
            transform: translateY(-2px);
            background: linear-gradient(45deg, #f848d2ff, #ec7c20ff);
            color: #fff;
        }
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
    <?php include 'includes/navbar.php'; ?>
    <main class="container my-5 flex-grow-1">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-xl-7">
                <div class="edit-box animate__animated animate__fadeIn">
                    <h2 class="text-center mb-4 fw-bold">Edit Profile</h2>
                    <div class="row justify-content-center">
                        <div class="col-lg-10">
                            <form method="POST" autocomplete="off">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Full Name</label>
                                    <input type="text" name="name" class="form-control rounded-3" 
                                           value="<?php echo htmlspecialchars($user['name']); ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Email (Cannot be changed)</label>
                                    <input type="email" name="email" class="form-control rounded-3" 
                                           value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Gender</label>
                                    <select name="gender" class="form-select rounded-3" required>
                                        <option value="">Select Gender</option>
                                        <option value="Male" <?= $user['gender'] == 'Male' ? 'selected' : '' ?>>Male</option>
                                        <option value="Female" <?= $user['gender'] == 'Female' ? 'selected' : '' ?>>Female</option>
                                        <option value="Other" <?= $user['gender'] == 'Other' ? 'selected' : '' ?>>Other</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">State</label>
                                    <input type="text" name="state" class="form-control rounded-3" 
                                           value="<?php echo htmlspecialchars($user['state']); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">City</label>
                                    <input type="text" name="city" class="form-control rounded-3" 
                                           value="<?php echo htmlspecialchars($user['city']); ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Sports Interests</label>
                                    <input type="text" name="sports_interest" class="form-control rounded-3" 
                                           value="<?php echo htmlspecialchars($user['sports_interest']); ?>">
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-profile-edit px-4">
                                        Save Changes
                                    </button>
                                    <a href="profile.php" class="btn btn-secondary px-4 ms-2 rounded-3">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <?php include 'includes/footer.php'; ?>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>