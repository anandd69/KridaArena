<?php
session_start();
include 'config/db.php'; 
$page_title = "My Registrations | KridaArena";
if (!isset($_SESSION['user_id'])) {
    $is_logged_in = false;
    $registrations = []; 
} else {
    $is_logged_in = true;
    $user_id = $_SESSION['user_id'];
    $registrations = [];
    $query = "SELECT t.name AS tournament_name, t.sport, t.tournament_id, r.team_name, r.registration_date
              FROM registrations r
              JOIN tournaments t ON r.sport_type = t.sport
              WHERE r.user_id = ?
              ORDER BY r.registration_date DESC";
    try {
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $registrations[] = $row;
            }
        }
        $stmt->close();
    } catch (Exception $e) {
        error_log("Error fetching user registrations: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>
</head>
<body class="d-flex flex-column min-vh-100">
    <?php include 'includes/navbar.php'; ?>
    <main class="container my-5 flex-grow-1">
        <section class="my-registrations">
            <h2 class="text-center mb-5 fw-bold">My Registered Tournaments</h2>
            <?php if (!$is_logged_in): ?>
                <div class="alert alert-warning text-center" role="alert">
                    Please <a href="login.php" class="alert-link">log in</a> to view your registrations.
                </div>
            <?php elseif (empty($registrations)): ?>
                <div class="alert alert-info text-center" role="alert">
                    You have not registered for any tournaments yet. <a href="tournaments.php" class="alert-link">Browse tournaments here!</a>
                </div>
            <?php else: ?>
                <div class="row g-4 justify-content-center">
                    <?php foreach ($registrations as $reg) : ?>
                        <div class="col-md-6 col-lg-5">
                            <div class="tournament-card">
                                <h3><?= htmlspecialchars($reg['tournament_name']) ?></h3>
                                <p>Sport: <b><?= htmlspecialchars($reg['sport']) ?></b></p>
                                <p>Your Team: <b><?= htmlspecialchars($reg['team_name']) ?></b></p>
                                <p class="text-muted">
                                    <small>
                                        Registered on: <?= date("M d, Y", strtotime($reg['registration_date'])) ?>
                                    </small>
                                </p>
                                <a href="reg_tm.php?id=<?= htmlspecialchars($reg['tournament_id']) ?>" class="btn-register mt-3">View Details</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>
    <?php include("includes/footer.php"); ?>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>