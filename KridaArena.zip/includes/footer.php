<footer class="footer-glow text-white py-4 mt-5">
    <div class="container">
        <div class="row text-center text-md-start align-items-center">
            <div class="col-md-4 mb-3 mb-md-0">
                <h4 class="footer-title">KridaArena</h4>
                <p class="footer-text">
                    KridaArena is your ultimate sports destination, bringing you tournaments, updates, and gadgets with a modern experience.
                </p>
            </div>
            <div class="col-md-4 mb-3 mb-md-0 text-center">
                <p><img src="png/email.png" alt="Email Icon" class="footer-icon" width="25" height="25">
                    <a href="mailto:kridaarena@gmail.com" class="footer-link">kridaarena@gmail.com</a>
                </p>
                <p><img src="png/location.png" alt="Location Icon" class="footer-icon" width="23" height="23"> Jamnagar, Gujarat, INDIA</p>
            </div>
            <div class="col-md-4 text-center text-md-end">
                <a href="#" class="social-icon"><img src="png/facebook.png" alt="Facebook Icon" class="social-media-icon" width="30" height="30"></a>
                <a href="#" class="social-icon"><img src="png/twitter.png" alt="Twitter Icon" class="social-media-icon" width="30" height="30"></a>
                <a href="#" class="social-icon"><img src="png/instagram.png" alt="Instagram Icon" class="social-media-icon" width="30" height="30"></a>
                <a href="#" class="social-icon"><img src="png/linkedin.png" alt="LinkedIn Icon" class="social-media-icon" width="30" height="30"></a>
            </div>
        </div>
        <hr class="bg-white mt-3">
        <p class="text-center mb-0">&copy; 2025 KridaArena. All Rights Reserved.</p>
    </div>
</footer>