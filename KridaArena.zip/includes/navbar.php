<?php
$current_page = basename($_SERVER['PHP_SELF']);
$is_logged_in = isset($_SESSION['user_id']);
?>

<nav class="navbar navbar-expand-lg navbar-dark nav-glow">
    <div class="container-fluid">
        <a class="navbar-brand text-glow" href="index.php">KridaArena</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'index.php') ? 'active' : '' ?>" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'about.php') ? 'active' : '' ?>" href="about.php">About</a>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= in_array($current_page, ['tournaments.php', 'my_reg.php']) ? 'active' : '' ?>" href="#" id="tournamentDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Tournaments
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="tournamentDropdown">
                        <li><a class="dropdown-item <?= ($current_page == 'tournaments.php') ? 'active' : '' ?>" href="tournaments.php"><img src="png/2trophy.png" alt="All Tournaments" style="width: 16px; height: 16px; margin-right: 5px;"> All Tournaments</a></li>
                        <li><a class="dropdown-item <?= ($current_page == 'my_reg.php') ? 'active' : '' ?>" href="my_reg.php"><img src="png/2reg.png" alt="My Register" style="width: 16px; height: 16px; margin-right: 5px;"> My Register</a></li>
                    </ul>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= in_array($current_page, ['store.php', 'cart.php', 'checkout.php', 'orders.php', 'saved_addresses.php', 'place_order.php']) ? 'active' : '' ?>" href="#" id="storeDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Store
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="storeDropdown">
                        <li><a class="dropdown-item <?= ($current_page == 'store.php') ? 'active' : '' ?>" href="store.php"><img src="png/products.png" alt="All Products" style="width: 16px; height: 16px; margin-right: 5px;"> All Products</a></li>
                        <li><a class="dropdown-item <?= ($current_page == 'cart.php') ? 'active' : '' ?>" href="cart.php"><img src="png/cart.png" alt="Cart" style="width: 16px; height: 16px; margin-right: 5px;"> Cart</a></li>
                        <li><a class="dropdown-item <?= ($current_page == 'checkout.php') ? 'active' : '' ?>" href="checkout.php"><img src="png/checkout.png" alt="Checkout" style="width: 16px; height: 16px; margin-right: 5px;"> Checkout</a></li>
                        <li><a class="dropdown-item <?= ($current_page == 'orders.php' || $current_page == 'place_order.php') ? 'active' : '' ?>" href="order.php"><img src="png/myorders.png" alt="My Orders" style="width: 16px; height: 16px; margin-right: 5px;"> My Orders</a></li>
                        <li><a class="dropdown-item <?= ($current_page == 'saved_addresses.php') ? 'active' : '' ?>" href="saved_addresses.php"><img src="png/address.png" alt="Saved Addresses" style="width: 16px; height: 16px; margin-right: 5px;"> Saved Addresses</a></li>
                    </ul>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'sinfo.php') ? 'active' : '' ?>" href="sinfo.php">Sports Info</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= in_array($current_page, ['feedback.php', 'faqs.php']) ? 'active' : '' ?>" href="#" id="moreDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        More
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="moreDropdown">
                        <li><a class="dropdown-item <?= ($current_page == 'feedback.php') ? 'active' : '' ?>" href="feedback.php"><img src="png/feedback.png" alt="Feedback" style="width: 16px; height: 16px; margin-right: 5px;"> Feedback</a></li>
                        <li><a class="dropdown-item <?= ($current_page == 'faqs.php') ? 'active' : '' ?>" href="faqs.php"><img src="png/faqs.png" alt="FAQs" style="width: 16px; height: 16px; margin-right: 5px;"> FAQs</a></li>
                    </ul>
                </li>
            </ul>
            
            <ul class="navbar-nav ms-auto">
                <?php if ($is_logged_in) : ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="png/profile.png" alt="Profile" style="width: 24px; height: 24px; margin-right: 5px;">
                            <span class="d-lg-none">Profile</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark dropdown-menu-end" aria-labelledby="profileDropdown">
                            <li><a class="dropdown-item" href="profile.php"><img src="png/myprofile.png" alt="My Profile" style="width: 16px; height: 16px; margin-right: 5px;"> My Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><img src="png/logout.png" alt="Logout" style="width: 16px; height: 16px; margin-right: 5px;"> Logout</a></li>
                        </ul>
                    </li>
                <?php else : ?>
                    <li class="nav-item">
                        <a class="nav-link btn btn-outline-light" href="login.php">Login</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>