<?php
$current_page = basename($_SERVER['PHP_SELF']);
$is_logged_in = isset($_SESSION['user_id']);
?>

<nav class="navbar navbar-expand-lg navbar-dark nav-glow">
    <div class="container-fluid">
        <a class="navbar-brand text-glow" href="index.php">KridaArena</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'index.php') ? 'active' : '' ?>" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'about.php') ? 'active' : '' ?>" href="about.php">About</a>
                </li>
                
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= in_array($current_page, ['tournaments.php', 'my_reg.php']) ? 'active' : '' ?>" href="#" id="tournamentDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Tournaments
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="tournamentDropdown">
                        <li><a class="dropdown-item <?= ($current_page == 'tournaments.php') ? 'active' : '' ?>" href="tournaments.php"><i class="bi bi-trophy"></i> All Tournaments</a></li>
                        <li><a class="dropdown-item <?= ($current_page == 'my_reg.php') ? 'active' : '' ?>" href="my_reg.php"><i class="bi bi-pencil-square"></i> My Register</a></li>
                    </ul>
                </li>

                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= in_array($current_page, ['store.php', 'cart.php', 'checkout.php', 'orders.php', 'saved_addresses.php', 'place_order.php']) ? 'active' : '' ?>" href="#" id="storeDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        Store
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="storeDropdown">
                        <li><a class="dropdown-item <?= ($current_page == 'store.php') ? 'active' : '' ?>" href="store.php"><i class="bi bi-bag-fill"></i> All Products</a></li>
                        <li><a class="dropdown-item <?= ($current_page == 'cart.php') ? 'active' : '' ?>" href="cart.php"><i class="bi bi-cart-fill"></i> Cart</a></li>
                        <li><a class="dropdown-item <?= ($current_page == 'checkout.php') ? 'active' : '' ?>" href="checkout.php"><i class="bi bi-credit-card-fill"></i> Checkout</a></li>
                        <li><a class="dropdown-item <?= ($current_page == 'orders.php' || $current_page == 'place_order.php') ? 'active' : '' ?>" href="order.php"><i class="bi bi-box-seam-fill"></i> My Orders</a></li>
                        <li><a class="dropdown-item <?= ($current_page == 'saved_addresses.php') ? 'active' : '' ?>" href="saved_addresses.php"><i class="bi bi-geo-alt-fill"></i> Saved Addresses</a></li>
                    </ul>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'sinfo.php') ? 'active' : '' ?>" href="sinfo.php">Sports Info</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle <?= in_array($current_page, ['feedback.php', 'faqs.php']) ? 'active' : '' ?>" href="#" id="moreDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        More
                    </a>
                    <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="moreDropdown">
                        <li><a class="dropdown-item <?= ($current_page == 'feedback.php') ? 'active' : '' ?>" href="feedback.php"><i class="bi bi-chat-left-text-fill"></i> Feedback</a></li>
                        <li><a class="dropdown-item <?= ($current_page == 'faqs.php') ? 'active' : '' ?>" href="faqs.php"><i class="bi bi-question-circle-fill"></i> FAQs</a></li>
                    </ul>
                </li>
            </ul>
            
            <ul class="navbar-nav ms-auto">
                <?php if ($is_logged_in) : ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle me-1 profile-icon"></i>
                            <span class="d-lg-none">Profile</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark dropdown-menu-end" aria-labelledby="profileDropdown">
                            <li><a class="dropdown-item" href="profile.php"><i class="bi bi-person-badge"></i> My Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
                        </ul>
                    </li>
                <?php else : ?>
                    <li class="nav-item">
                        <a class="nav-link btn btn-outline-light" href="login.php">Login</a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>          