<?php
session_start();
include 'config/db.php'; 

$page_title = "Tournament Details | KridaArena";
$msg = "";
$tournament_data = null;
$registration_data = null;
$is_logged_in = isset($_SESSION['user_id']);
$user_id = $is_logged_in ? $_SESSION['user_id'] : 0;
$is_registered = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    header('Content-Type: application/json');

    if (!$is_logged_in) {
        echo json_encode(['status' => 'error', 'message' => 'Please login to register for a tournament.']);
        exit();
    }

    $tournament_id = isset($_POST['tournament_id']) ? intval($_POST['tournament_id']) : 0;
    $team_name = trim($_POST['team_name'] ?? '');

    if ($tournament_id == 0) {
        echo json_encode(['status' => 'error', 'message' => 'Tournament ID is missing.']);
        exit();
    }

    if (empty($team_name)) {
        echo json_encode(['status' => 'error', 'message' => 'Team name cannot be empty.']);
        exit();
    }

    try {
        $get_sport_query = "SELECT sport FROM tournaments WHERE tournament_id = ?";
        $get_sport_stmt = $conn->prepare($get_sport_query);
        $get_sport_stmt->bind_param("i", $tournament_id);
        $get_sport_stmt->execute();
        $get_sport_result = $get_sport_stmt->get_result();
        $sport_type = $get_sport_result->fetch_assoc()['sport'] ?? null;
        $get_sport_stmt->close();

        if (is_null($sport_type)) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid tournament.']);
            exit();
        }

        $check_query = "SELECT COUNT(*) FROM registrations WHERE user_id = ? AND sport_type = ?";
        $check_stmt = $conn->prepare($check_query);
        $check_stmt->bind_param("is", $user_id, $sport_type);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $row = $check_result->fetch_array();
        
        if ($row[0] > 0) {
            echo json_encode(['status' => 'error', 'message' => 'You are already registered for a ' . htmlspecialchars($sport_type) . ' tournament.']);
            exit();
        }
        $check_stmt->close();

        $insert_query = "INSERT INTO registrations (user_id, team_name, sport_type, registration_date) VALUES (?, ?, ?, NOW())";
        $insert_stmt = $conn->prepare($insert_query);
        $insert_stmt->bind_param("iss", $user_id, $team_name, $sport_type);
        
        if ($insert_stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Registration submitted successfully!']);
        } else {
            error_log("Database Error on registration: " . $insert_stmt->error); 
            echo json_encode(['status' => 'error', 'message' => 'Registration failed due to a database error. Please try again later.']);
        }
        $insert_stmt->close();

    } catch (Exception $e) {
        error_log("General Registration Error: " . $e->getMessage()); 
        echo json_encode(['status' => 'error', 'message' => 'An unexpected error occurred. Please try again.']);
    }
    exit();
}

$tournament_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($tournament_id == 0) {
    $msg = "<div class='alert alert-danger'>Tournament ID missing.</div>";
} else {
    $query = "SELECT * FROM tournaments WHERE tournament_id = ?"; 
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $tournament_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $tournament_data = $result->fetch_assoc();
    } else {
        $msg = "<div class='alert alert-danger'>Tournament not found!</div>";
    }
    $stmt->close();
    
    if ($is_logged_in && $tournament_data) {
        $sport_type_to_check = $tournament_data['sport'];
        $check_reg_query = "SELECT * FROM registrations WHERE user_id = ? AND sport_type = ?";
        $check_reg_stmt = $conn->prepare($check_reg_query);
        $check_reg_stmt->bind_param("is", $user_id, $sport_type_to_check);
        $check_reg_stmt->execute();
        $reg_result = $check_reg_stmt->get_result();
        
        if ($reg_result->num_rows > 0) {
            $is_registered = true;
            $registration_data = $reg_result->fetch_assoc();
        }
        $check_reg_stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/sweetalert2@11.js"></script>
</head>
<body class="d-flex flex-column min-vh-100">

<?php include 'includes/navbar.php'; ?>

<main class="container my-5 flex-grow-1">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-5">
            <div class="tournament-details-card">
                <?php if ($tournament_data) : ?>
                    <div class="text-center mb-4">
                        <h3 class="fw-bold"><?= htmlspecialchars($tournament_data['name'] ?? 'Tournament') ?></h3>
                        <p class="text-muted"><?= htmlspecialchars($tournament_data['sport'] ?? 'Sport') ?></p>
                        <hr>
                    </div>

                    <div class="tournament-details-content">
                        <h4>Tournament Info</h4>
                        <p><strong>Description:</strong> <?= nl2br(htmlspecialchars($tournament_data['description'] ?? 'No description provided.')) ?></p>
                        <p><strong>Venue:</strong> <?= htmlspecialchars($tournament_data['venue'] ?? 'TBD') ?></p>
                        <p><strong>Fees:</strong> Rs. <?= number_format($tournament_data['fees'] ?? 0, 2) ?></p>
                        <p><strong>Registration Period:</strong> <?= htmlspecialchars($tournament_data['registration_start_date'] ?? 'N/A') ?> to <?= htmlspecialchars($tournament_data['registration_end_date'] ?? 'N/A') ?></p>
                        
                        <p><strong>Players per team:</strong> <b><?= htmlspecialchars($tournament_data['player_count'] ?? 'N/A') ?></b></p>
                        
                        <p><strong>Prizes:</strong> <?= nl2br(htmlspecialchars($tournament_data['prizes'] ?? 'Check event page for details.')) ?></p>
                    </div>
                    
                    <?php if ($is_registered): ?>
                        <hr class="my-4">
                        <div class="alert alert-success text-center">
                            You are already registered for this tournament.
                        </div>
                        <div class="my-3">
                            <h4>Your Registration Details</h4>
                            <p><strong>Your Team Name:</strong> <?= htmlspecialchars($registration_data['team_name'] ?? 'N/A') ?></p>
                            <p><strong>Registered on:</strong> <?= htmlspecialchars($registration_data['registration_date'] ?? 'N/A') ?></p>
                        </div>
                    <?php else: ?>
                        <hr class="my-4">
                        <?php if ($is_logged_in) : ?>
                            <form id="registrationForm" action="reg_tm.php" method="POST">
                                <input type="hidden" name="tournament_id" value="<?= htmlspecialchars($tournament_id) ?>">
                                <div class="mb-3">
                                    <label for="team_name" class="form-label">Team Name</label>
                                    <input type="text" name="team_name" id="team_name" class="form-control" placeholder="Enter your team name" required>
                                </div>
                                <button type="submit" class="btn btn-profile-edit w-100 mt-3">Confirm Registration</button>
                            </form>
                        <?php else : ?>
                            <div class="alert alert-warning text-center">
                                Please <a href="login.php" class="alert-link">log in</a> to register for this tournament.
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                <?php else : ?>
                    <div class="alert alert-danger text-center" role="alert">
                        <?= $msg ?: "We're sorry, this tournament is not available." ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</main>
<?php include("includes/footer.php"); ?>
<script src="js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('registrationForm');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(this);
            fetch(this.action, { method: 'POST', body: formData })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Registration Submitted!',
                        text: data.message,
                        timer: 3000,
                        showConfirmButton: false
                    }).then(() => {
                        window.location.reload(); 
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: data.message,
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An error occurred. Please try again.',
                });
            });
        });
    }
});
</script>
</body>
</html>