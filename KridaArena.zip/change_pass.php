<?php
session_start();
include 'config/db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$msg = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
        $msg = "<div class='alert alert-danger'>All fields are required.</div>";
    } elseif ($new_password !== $confirm_password) {
        $msg = "<div class='alert alert-danger'>New password and confirm password do not match.</div>";
    } elseif (strlen($new_password) < 6) {
        $msg = "<div class='alert alert-danger'>New password must be at least 6 characters long.</div>";
    } else {
        $query = "SELECT password FROM users WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        if ($user && password_verify($old_password, $user['password'])) {
            $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);
            $update_query = "UPDATE users SET password = ? WHERE id = ?";
            $update_stmt = $conn->prepare($update_query);
            $update_stmt->bind_param("si", $hashed_new_password, $user_id);
            if ($update_stmt->execute()) {
                $msg = "<div class='alert alert-success'>Password changed successfully!</div>";
            } else {
                $msg = "<div class='alert alert-danger'>Error changing password. Please try again.</div>";
            }
        } else {
            $msg = "<div class='alert alert-danger'>Incorrect old password.</div>";
        }
    }
}
$page_title = "Change Password | KridaArena";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?></title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/style.css">    
    <link rel="stylesheet" href="css/all.min.css">
    <script src="js/sweetalert2@11.js"></script>
    <style>
        .change-pass-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: calc(100vh - 120px);
            padding-top: 50px;
            padding-bottom: 50px;
        }
        .change-pass-card {
            background-color: #fff;
            border-radius: 20px;
            padding: 35px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            position: relative;
            transition: all 0.4s ease-in-out;
            border: none;
        }
        .change-pass-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
        }
        .profile-name {
            font-weight: 700;
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .btn-profile-edit {
            border-radius: 12px;
            padding: 12px 24px;
            font-weight: bold;
            color: #fff;
            background: linear-gradient(90deg, #ec7c20ff, #f848d2ff);
            border: none;
            transition: all 0.3s ease;
        }
        .btn-profile-edit:hover {
            transform: scale(1.05);
            box-shadow: 0 0 15px #f848d2ff, 0 0 25px #ec7c20ff;
        }
        .form-control {
            border-radius: 12px;
            padding: 12px;
            background-color: #f9f9f9;
            border: 2px solid #eee;
        }
        .form-control:focus {
            border-color: #f848d2ff;
            box-shadow: 0 0 10px #f848d2ff;
        }
        .login-link {
            color: #f848d2ff;
            text-decoration: none;
            font-weight: 500;
        }
        .login-link:hover {
            text-decoration: underline;
            color: #ec7c20ff;
        }
    </style>
</head>
<body>
    <?php include("includes/navbar.php"); ?>
    <main class="change-pass-container">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6">
                    <div class="card change-pass-card animate__animated animate__fadeIn">
                        <div class="card-body p-4">
                            <h2 class="text-center profile-name mb-4">Change Password</h2>
                            <?= $msg ?>
                            <form method="POST">
                                <div class="mb-3">
                                    <label class="form-label">Old Password</label>
                                    <input type="password" name="old_password" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">New Password</label>
                                    <input type="password" name="new_password" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Confirm New Password</label>
                                    <input type="password" name="confirm_password" class="form-control" required>
                                </div>
                                <button type="submit" class="btn btn-profile-edit w-100 mt-3">Update Password</button>
                                <div class="text-center mt-3">
                                    <a href="profile.php" class="login-link">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <?php include("includes/footer.php"); ?>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>